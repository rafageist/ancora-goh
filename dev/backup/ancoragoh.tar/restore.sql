create temporary table pgdump_restore_path(p text);
--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
-- Edit the following to match the path where the
-- tar archive has been extracted.
--
insert into pgdump_restore_path values('/tmp');

--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = seguridad, pg_catalog;

ALTER TABLE ONLY seguridad.traza DROP CONSTRAINT traza_usuario_fkey;
ALTER TABLE ONLY seguridad.rol_de_usuario DROP CONSTRAINT rol_de_usuario_usuario_fkey;
ALTER TABLE ONLY seguridad.rol_de_usuario DROP CONSTRAINT rol_de_usuario_rol_fkey;
ALTER TABLE ONLY seguridad.permiso DROP CONSTRAINT permiso_rol_fkey;
ALTER TABLE ONLY seguridad.host DROP CONSTRAINT host_usuario_fkey;
SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.zpriori DROP CONSTRAINT zpriori_periodo_fkey;
ALTER TABLE ONLY public.zpriori DROP CONSTRAINT zpriori_clasificacion_fkey;
ALTER TABLE ONLY public.restriccion_real_de_profesor DROP CONSTRAINT restriccion_real_de_profesor_restriccion_nominal_fkey;
ALTER TABLE ONLY public.restriccion_real_de_profesor DROP CONSTRAINT restriccion_real_de_profesor_periodicidad_fkey;
ALTER TABLE ONLY public.restriccion_real_de_profesor DROP CONSTRAINT restriccion_real_de_profesor_objeto_fkey;
ALTER TABLE ONLY public.restriccion_real_de_periodo DROP CONSTRAINT restriccion_real_de_periodo_restriccion_nominal_fkey;
ALTER TABLE ONLY public.restriccion_real_de_periodo DROP CONSTRAINT restriccion_real_de_periodo_periodicidad_fkey;
ALTER TABLE ONLY public.restriccion_real_de_periodo DROP CONSTRAINT restriccion_real_de_periodo_objeto_fkey;
ALTER TABLE ONLY public.restriccion_real_de_otro_recurso DROP CONSTRAINT restriccion_real_de_otro_recurso_restriccion_nominal_fkey;
ALTER TABLE ONLY public.restriccion_real_de_otro_recurso DROP CONSTRAINT restriccion_real_de_otro_recurso_periodicidad_fkey;
ALTER TABLE ONLY public.restriccion_real_de_otro_recurso DROP CONSTRAINT restriccion_real_de_otro_recurso_objeto_fkey;
ALTER TABLE ONLY public.restriccion_real_de_lugar DROP CONSTRAINT restriccion_real_de_lugar_restriccion_nominal_fkey;
ALTER TABLE ONLY public.restriccion_real_de_lugar DROP CONSTRAINT restriccion_real_de_lugar_periodicidad_fkey;
ALTER TABLE ONLY public.restriccion_real_de_lugar DROP CONSTRAINT restriccion_real_de_lugar_objeto_fkey;
ALTER TABLE ONLY public.restriccion_real_de_especialidad DROP CONSTRAINT restriccion_real_de_especialidad_restriccion_nominal_fkey;
ALTER TABLE ONLY public.restriccion_real_de_especialidad DROP CONSTRAINT restriccion_real_de_especialidad_periodicidad_fkey;
ALTER TABLE ONLY public.restriccion_real_de_especialidad DROP CONSTRAINT restriccion_real_de_especialidad_objeto_fkey;
ALTER TABLE ONLY public.restriccion_real_de_clasif_act DROP CONSTRAINT restriccion_real_de_clasif_act_restriccion_nominal_fkey;
ALTER TABLE ONLY public.restriccion_real_de_clasif_act DROP CONSTRAINT restriccion_real_de_clasif_act_periodicidad_fkey;
ALTER TABLE ONLY public.restriccion_real_de_clasif_act DROP CONSTRAINT restriccion_real_de_clasif_act_objeto_fkey;
ALTER TABLE ONLY public.restriccion_real_de_brigada DROP CONSTRAINT restriccion_real_de_brigada_restriccion_nominal_fkey;
ALTER TABLE ONLY public.restriccion_real_de_brigada DROP CONSTRAINT restriccion_real_de_brigada_periodicidad_fkey;
ALTER TABLE ONLY public.restriccion_real_de_brigada DROP CONSTRAINT restriccion_real_de_brigada_objeto_fkey;
ALTER TABLE ONLY public.restriccion_real_de_brigada DROP CONSTRAINT restriccion_real_de_brigada_actividad_fkey;
ALTER TABLE ONLY public.restriccion_real_de_asignatura DROP CONSTRAINT restriccion_real_de_asignatura_restriccion_nominal_fkey;
ALTER TABLE ONLY public.restriccion_real_de_asignatura DROP CONSTRAINT restriccion_real_de_asignatura_periodicidad_fkey;
ALTER TABLE ONLY public.restriccion_real_de_asignatura DROP CONSTRAINT restriccion_real_de_asignatura_objeto_fkey;
ALTER TABLE ONLY public.restriccion_por_actividad_de_profesor DROP CONSTRAINT restriccion_por_actividad_de_profesor_restriccion_nominal_fkey;
ALTER TABLE ONLY public.restriccion_por_actividad_de_profesor DROP CONSTRAINT restriccion_por_actividad_de_profesor_actividad_fkey;
ALTER TABLE ONLY public.restriccion_por_actividad_de_otro_recurso DROP CONSTRAINT restriccion_por_actividad_de_otro_recurso_actividad_fkey;
ALTER TABLE ONLY public.restriccion_por_actividad_de_otro_recurso DROP CONSTRAINT restriccion_por_actividad_de_otro_recu_restriccion_nominal_fkey;
ALTER TABLE ONLY public.restriccion_por_actividad_de_lugar DROP CONSTRAINT restriccion_por_actividad_de_lugar_restriccion_nominal_fkey;
ALTER TABLE ONLY public.restriccion_por_actividad_de_lugar DROP CONSTRAINT restriccion_por_actividad_de_lugar_actividad_fkey;
ALTER TABLE ONLY public.restriccion_por_actividad_de_brigada DROP CONSTRAINT restriccion_por_actividad_de_brigada_restriccion_nominal_fkey;
ALTER TABLE ONLY public.restriccion_por_actividad_de_brigada DROP CONSTRAINT restriccion_por_actividad_de_brigada_actividad_fkey;
ALTER TABLE ONLY public.restriccion_de_profesor DROP CONSTRAINT restriccion_de_profesor_profesor_fkey;
ALTER TABLE ONLY public.restriccion_de_profesor DROP CONSTRAINT restriccion_de_profesor_periodo_fkey;
ALTER TABLE ONLY public.restriccion_de_profesor DROP CONSTRAINT restriccion_de_profesor_actividad_fkey;
ALTER TABLE ONLY public.restriccion_de_periodo DROP CONSTRAINT restriccion_de_periodo_periodo_fkey;
ALTER TABLE ONLY public.restriccion_de_otro_recurso DROP CONSTRAINT restriccion_de_otro_recurso_periodo_fkey;
ALTER TABLE ONLY public.restriccion_de_otro_recurso DROP CONSTRAINT restriccion_de_otro_recurso_otro_recurso_fkey;
ALTER TABLE ONLY public.restriccion_de_otro_recurso DROP CONSTRAINT restriccion_de_otro_recurso_actividad_fkey;
ALTER TABLE ONLY public.restriccion_de_lugar DROP CONSTRAINT restriccion_de_lugar_periodo_fkey;
ALTER TABLE ONLY public.restriccion_de_lugar DROP CONSTRAINT restriccion_de_lugar_lugar_fkey;
ALTER TABLE ONLY public.restriccion_de_lugar DROP CONSTRAINT restriccion_de_lugar_actividad_fkey;
ALTER TABLE ONLY public.restriccion_de_especialidad DROP CONSTRAINT restriccion_de_especialidad_periodo_fkey;
ALTER TABLE ONLY public.restriccion_de_especialidad DROP CONSTRAINT restriccion_de_especialidad_especialidad_fkey;
ALTER TABLE ONLY public.restriccion_de_clasif_act DROP CONSTRAINT restriccion_de_clasif_act_periodo_fkey;
ALTER TABLE ONLY public.restriccion_de_clasif_act DROP CONSTRAINT restriccion_de_clasif_act_clasificacion_fkey;
ALTER TABLE ONLY public.restriccion_de_brigada DROP CONSTRAINT restriccion_de_brigada_periodo_fkey;
ALTER TABLE ONLY public.restriccion_de_brigada DROP CONSTRAINT restriccion_de_brigada_brigada_fkey;
ALTER TABLE ONLY public.restriccion_de_brigada DROP CONSTRAINT restriccion_de_brigada_actividad_fkey;
ALTER TABLE ONLY public.restriccion_de_asignatura DROP CONSTRAINT restriccion_de_asignatura_periodo_fkey;
ALTER TABLE ONLY public.restriccion_de_asignatura DROP CONSTRAINT restriccion_de_asignatura_asignatura_fkey;
ALTER TABLE ONLY public.restriccion_condicional DROP CONSTRAINT restriccion_condicional_profesor_fkey;
ALTER TABLE ONLY public.restriccion_condicional DROP CONSTRAINT restriccion_condicional_planificacion_fkey;
ALTER TABLE ONLY public.restriccion_condicional DROP CONSTRAINT restriccion_condicional_periodo_fkey;
ALTER TABLE ONLY public.restriccion_condicional DROP CONSTRAINT restriccion_condicional_otro_recurso_fkey;
ALTER TABLE ONLY public.restriccion_condicional DROP CONSTRAINT restriccion_condicional_nivel_fkey;
ALTER TABLE ONLY public.restriccion_condicional DROP CONSTRAINT restriccion_condicional_lugar_fkey;
ALTER TABLE ONLY public.restriccion_condicional DROP CONSTRAINT restriccion_condicional_especialidad_fkey;
ALTER TABLE ONLY public.restriccion_condicional DROP CONSTRAINT restriccion_condicional_consec_profesor_fkey;
ALTER TABLE ONLY public.restriccion_condicional DROP CONSTRAINT restriccion_condicional_consec_periodo_fkey;
ALTER TABLE ONLY public.restriccion_condicional DROP CONSTRAINT restriccion_condicional_consec_otro_recurso_fkey;
ALTER TABLE ONLY public.restriccion_condicional DROP CONSTRAINT restriccion_condicional_consec_lugar_fkey;
ALTER TABLE ONLY public.restriccion_condicional DROP CONSTRAINT restriccion_condicional_consec_brigada_fkey;
ALTER TABLE ONLY public.restriccion_condicional DROP CONSTRAINT restriccion_condicional_clasif_act_fkey;
ALTER TABLE ONLY public.restriccion_condicional DROP CONSTRAINT restriccion_condicional_brigada_fkey;
ALTER TABLE ONLY public.restriccion_condicional DROP CONSTRAINT restriccion_condicional_asig_fkey;
ALTER TABLE ONLY public.receso DROP CONSTRAINT receso_periodo_fkey;
ALTER TABLE ONLY public.profesor_para_grupo DROP CONSTRAINT profesor_para_grupo_profesor_para_actividad_fkey;
ALTER TABLE ONLY public.profesor_para_grupo DROP CONSTRAINT profesor_para_grupo_grupo_fkey;
ALTER TABLE ONLY public.profesor_para_actividad DROP CONSTRAINT profesor_para_actividad_profesor_fkey;
ALTER TABLE ONLY public.profesor_para_actividad DROP CONSTRAINT profesor_para_actividad_plantilla_fkey;
ALTER TABLE ONLY public.profesor DROP CONSTRAINT profesor_creador_fkey;
ALTER TABLE ONLY public.plantilla_de_actividad DROP CONSTRAINT plantilla_de_actividad_desglose_fkey;
ALTER TABLE ONLY public.plantilla_de_actividad DROP CONSTRAINT plantilla_de_actividad_clasificacion_fkey;
ALTER TABLE ONLY public.planificacion DROP CONSTRAINT planificacion_creador_fkey;
ALTER TABLE ONLY public.periodo DROP CONSTRAINT periodo_planificacion_fkey;
ALTER TABLE ONLY public.periodicidad DROP CONSTRAINT periodicidad_periodo_fkey;
ALTER TABLE ONLY public.otros_recursos_usados DROP CONSTRAINT otros_recursos_usados_otro_recurso_fkey;
ALTER TABLE ONLY public.otros_recursos_usados DROP CONSTRAINT otros_recursos_usados_creador_fkey;
ALTER TABLE ONLY public.otros_recursos_usados DROP CONSTRAINT otros_recursos_usados_actividad_fkey;
ALTER TABLE ONLY public.otro_recurso_para_actividad DROP CONSTRAINT otro_recurso_para_actividad_otro_recurso_fkey;
ALTER TABLE ONLY public.otro_recurso_para_actividad DROP CONSTRAINT otro_recurso_para_actividad_grupo_de_recursos_fkey;
ALTER TABLE ONLY public.otro_recurso DROP CONSTRAINT otro_recurso_creador_fkey;
ALTER TABLE ONLY public.otro_grupo_de_recursos_para_actividad DROP CONSTRAINT otro_grupo_de_recursos_para_actividad_plantilla_fkey;
ALTER TABLE ONLY public.otro_grupo_de_recursos_para_actividad DROP CONSTRAINT otro_grupo_de_recursos_para_actividad_creador_fkey;
ALTER TABLE ONLY public.nivel DROP CONSTRAINT nivel_creador_fkey;
ALTER TABLE ONLY public.lugar_para_actividad DROP CONSTRAINT lugar_para_actividad_plantilla_fkey;
ALTER TABLE ONLY public.lugar_para_actividad DROP CONSTRAINT lugar_para_actividad_lugar_fkey;
ALTER TABLE ONLY public.lugar_fijo DROP CONSTRAINT lugar_fijo_lugar_fkey;
ALTER TABLE ONLY public.lugar_fijo DROP CONSTRAINT lugar_fijo_grupo_fkey;
ALTER TABLE ONLY public.lugar DROP CONSTRAINT lugar_creador_fkey;
ALTER TABLE ONLY public.higiene_para_profesor DROP CONSTRAINT higiene_para_profesor_profesor_fkey;
ALTER TABLE ONLY public.higiene_para_profesor DROP CONSTRAINT higiene_para_profesor_periodo_fkey;
ALTER TABLE ONLY public.higiene_para_brigada DROP CONSTRAINT higiene_para_brigada_periodo_fkey;
ALTER TABLE ONLY public.higiene_para_brigada DROP CONSTRAINT higiene_para_brigada_brigada_fkey;
ALTER TABLE ONLY public.herencia_de_restricciones DROP CONSTRAINT herencia_de_restricciones_planificacion_fkey;
ALTER TABLE ONLY public.herencia_de_restricciones DROP CONSTRAINT herencia_de_restricciones_padre_profesor_fkey;
ALTER TABLE ONLY public.herencia_de_restricciones DROP CONSTRAINT herencia_de_restricciones_padre_otro_recurso_fkey;
ALTER TABLE ONLY public.herencia_de_restricciones DROP CONSTRAINT herencia_de_restricciones_padre_lugar_fkey;
ALTER TABLE ONLY public.herencia_de_restricciones DROP CONSTRAINT herencia_de_restricciones_padre_brigada_fkey;
ALTER TABLE ONLY public.herencia_de_restricciones DROP CONSTRAINT herencia_de_restricciones_hijo_profesor_fkey;
ALTER TABLE ONLY public.herencia_de_restricciones DROP CONSTRAINT herencia_de_restricciones_hijo_otro_recurso_fkey;
ALTER TABLE ONLY public.herencia_de_restricciones DROP CONSTRAINT herencia_de_restricciones_hijo_lugar_fkey;
ALTER TABLE ONLY public.herencia_de_restricciones DROP CONSTRAINT herencia_de_restricciones_hijo_brigada_fkey;
ALTER TABLE ONLY public.grupo DROP CONSTRAINT grupo_planificacion_fkey;
ALTER TABLE ONLY public.grupo DROP CONSTRAINT grupo_nivel_fkey;
ALTER TABLE ONLY public.grupo DROP CONSTRAINT grupo_especialidad_fkey;
ALTER TABLE ONLY public.grupo DROP CONSTRAINT grupo_clasificacion_fkey;
ALTER TABLE ONLY public.excepcion_de_hrt DROP CONSTRAINT excepcion_de_hrt_periodo_fkey;
ALTER TABLE ONLY public.excepcion_de_hrt DROP CONSTRAINT excepcion_de_hrt_herencia_fkey;
ALTER TABLE ONLY public.especialidad DROP CONSTRAINT especialidad_creador_fkey;
ALTER TABLE ONLY public.desglose DROP CONSTRAINT desglose_periodo_fkey;
ALTER TABLE ONLY public.desglose DROP CONSTRAINT desglose_asignatura_fkey;
ALTER TABLE ONLY public.costo_de_traslado DROP CONSTRAINT costo_de_traslado_origen_fkey;
ALTER TABLE ONLY public.costo_de_traslado DROP CONSTRAINT costo_de_traslado_destino_fkey;
ALTER TABLE ONLY public.clasificacion_de_actividad DROP CONSTRAINT clasificacion_de_actividad_creador_fkey;
ALTER TABLE ONLY public.brigada DROP CONSTRAINT brigada_nivel_fkey;
ALTER TABLE ONLY public.brigada DROP CONSTRAINT brigada_especialidad_fkey;
ALTER TABLE ONLY public.brigada_de_grupo DROP CONSTRAINT brigada_de_grupo_grupo_fkey;
ALTER TABLE ONLY public.brigada_de_grupo DROP CONSTRAINT brigada_de_grupo_brigada_fkey;
ALTER TABLE ONLY public.brigada DROP CONSTRAINT brigada_creador_fkey;
ALTER TABLE ONLY public.asignatura DROP CONSTRAINT asignatura_nivel_fkey;
ALTER TABLE ONLY public.asignatura DROP CONSTRAINT asignatura_especialidad_fkey;
ALTER TABLE ONLY public.asignatura DROP CONSTRAINT asignatura_creador_fkey;
ALTER TABLE ONLY public.actividad DROP CONSTRAINT actividad_profesor_fkey;
ALTER TABLE ONLY public.actividad DROP CONSTRAINT actividad_plantilla_fkey;
ALTER TABLE ONLY public.actividad DROP CONSTRAINT actividad_lugar_fkey;
ALTER TABLE ONLY public.actividad DROP CONSTRAINT actividad_grupo_fkey;
ALTER TABLE ONLY public.actividad DROP CONSTRAINT actividad_creador_fkey;
ALTER TABLE ONLY public.acceso_prohibido DROP CONSTRAINT acceso_prohibido_lugar_fkey;
ALTER TABLE ONLY public.acceso_prohibido DROP CONSTRAINT acceso_prohibido_grupo_fkey;
DROP TRIGGER trigger_nivela_prioridad_rxact_after_delete ON public.otro_grupo_de_recursos_para_actividad;
DROP TRIGGER trigger_nivela_prioridad_lxact_after_update ON public.lugar_para_actividad;
DROP TRIGGER trigger_nivela_prioridad_lxact_after_delete ON public.lugar_para_actividad;
DROP TRIGGER trigger_arregla_prioridades_clasif_after_delete ON public.clasificacion_de_actividad;
DROP TRIGGER trigger_actualiza_profesor_para_grupo ON public.profesor_para_grupo;
DROP TRIGGER trigger_actualiza_orden_act_before_update ON public.plantilla_de_actividad;
DROP TRIGGER trigger_actualiza_orden_act_before_insert ON public.plantilla_de_actividad;
DROP TRIGGER trigger_actualiza_orden_act_after_update ON public.plantilla_de_actividad;
DROP TRIGGER trigger_actualiza_orden_act_after_insert ON public.plantilla_de_actividad;
DROP TRIGGER trigger_actualiza_orden_act_after_delete ON public.plantilla_de_actividad;
DROP TRIGGER nuevo_desglose_si_nuevo_periodo ON public.periodo;
DROP TRIGGER nuevo_desglose_si_nueva_asignatura ON public.asignatura;
DROP RULE crea_restriccion_real_de_profesor ON public.restriccion_de_profesor;
DROP RULE crea_restriccion_real_de_periodo ON public.restriccion_de_periodo;
DROP RULE crea_restriccion_real_de_otro_recurso ON public.restriccion_de_otro_recurso;
DROP RULE crea_restriccion_real_de_lugar ON public.restriccion_de_lugar;
DROP RULE crea_restriccion_real_de_especialidad ON public.restriccion_de_especialidad;
DROP RULE crea_restriccion_real_de_clasif_act ON public.restriccion_de_clasif_act;
DROP RULE crea_restriccion_real_de_brigada ON public.restriccion_de_brigada;
DROP RULE crea_restriccion_real_de_asignatura ON public.restriccion_de_asignatura;
DROP RULE actualiza_restricciones_por_uso_de_otro_recurso ON public.otros_recursos_usados;
DROP RULE actualiza_restricciones_por_actividad ON public.actividad;
DROP RULE actualiza_restriccion_real_de_profesor ON public.restriccion_de_profesor;
DROP RULE actualiza_restriccion_real_de_periodo ON public.restriccion_de_periodo;
DROP RULE actualiza_restriccion_real_de_otro_recurso ON public.restriccion_de_otro_recurso;
DROP RULE actualiza_restriccion_real_de_lugar ON public.restriccion_de_lugar;
DROP RULE actualiza_restriccion_real_de_especialidad ON public.restriccion_de_especialidad;
DROP RULE actualiza_restriccion_real_de_clasif_act ON public.restriccion_de_clasif_act;
DROP RULE actualiza_restriccion_real_de_brigada ON public.restriccion_de_brigada;
DROP RULE actualiza_restriccion_real_de_asignatura ON public.restriccion_de_asignatura;
DROP RULE actualiza_por_actividad_en_restriccion_de_profesor ON public.restriccion_por_actividad_de_profesor;
DROP RULE actualiza_por_actividad_en_restriccion_de_otro_recurso ON public.restriccion_por_actividad_de_otro_recurso;
DROP RULE actualiza_por_actividad_en_restriccion_de_lugar ON public.restriccion_por_actividad_de_lugar;
DROP RULE actualiza_por_actividad_en_restriccion_de_brigada ON public.restriccion_por_actividad_de_brigada;
DROP RULE actualiza_por_actividad_en_nueva_restriccion_de_profesor ON public.restriccion_por_actividad_de_profesor;
DROP RULE actualiza_por_actividad_en_nueva_restriccion_de_otro_recurso ON public.restriccion_por_actividad_de_otro_recurso;
DROP RULE actualiza_por_actividad_en_nueva_restriccion_de_lugar ON public.restriccion_por_actividad_de_lugar;
DROP RULE actualiza_por_actividad_en_nueva_restriccion_de_brigada ON public.restriccion_por_actividad_de_brigada;
SET search_path = seguridad, pg_catalog;

ALTER TABLE ONLY seguridad.usuario DROP CONSTRAINT usuario_pkey;
ALTER TABLE ONLY seguridad.usuario DROP CONSTRAINT usuario_nick_key;
ALTER TABLE ONLY seguridad.rol DROP CONSTRAINT rol_pkey;
ALTER TABLE ONLY seguridad.rol_de_usuario DROP CONSTRAINT rol_de_usuario_pkey;
ALTER TABLE ONLY seguridad.permiso DROP CONSTRAINT permiso_pkey;
ALTER TABLE ONLY seguridad.host DROP CONSTRAINT host_pkey;
SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.zpriori DROP CONSTRAINT zpriori_pkey;
ALTER TABLE ONLY public.restriccion_real DROP CONSTRAINT restriccion_real_pkey;
ALTER TABLE ONLY public.restriccion_real_de_profesor DROP CONSTRAINT restriccion_real_de_profesor_pkey;
ALTER TABLE ONLY public.restriccion_real_de_periodo DROP CONSTRAINT restriccion_real_de_periodo_pkey;
ALTER TABLE ONLY public.restriccion_real_de_otro_recurso DROP CONSTRAINT restriccion_real_de_otro_recurso_pkey;
ALTER TABLE ONLY public.restriccion_real_de_lugar DROP CONSTRAINT restriccion_real_de_lugar_pkey;
ALTER TABLE ONLY public.restriccion_real_de_especialidad DROP CONSTRAINT restriccion_real_de_especialidad_pkey;
ALTER TABLE ONLY public.restriccion_real_de_clasif_act DROP CONSTRAINT restriccion_real_de_clasif_act_pkey;
ALTER TABLE ONLY public.restriccion_real_de_brigada DROP CONSTRAINT restriccion_real_de_brigada_pkey;
ALTER TABLE ONLY public.restriccion_real_de_asignatura DROP CONSTRAINT restriccion_real_de_asignatura_pkey;
ALTER TABLE ONLY public.restriccion_por_actividad DROP CONSTRAINT restriccion_por_actividad_pkey;
ALTER TABLE ONLY public.restriccion_por_actividad_de_profesor DROP CONSTRAINT restriccion_por_actividad_de_profesor_pkey;
ALTER TABLE ONLY public.restriccion_por_actividad_de_otro_recurso DROP CONSTRAINT restriccion_por_actividad_de_otro_recurso_pkey;
ALTER TABLE ONLY public.restriccion_por_actividad_de_lugar DROP CONSTRAINT restriccion_por_actividad_de_lugar_pkey;
ALTER TABLE ONLY public.restriccion_por_actividad_de_brigada DROP CONSTRAINT restriccion_por_actividad_de_brigada_pkey;
ALTER TABLE ONLY public.restriccion_de_profesor DROP CONSTRAINT restriccion_de_profesor_profesor_key;
ALTER TABLE ONLY public.restriccion_de_profesor DROP CONSTRAINT restriccion_de_profesor_pkey;
ALTER TABLE ONLY public.restriccion_de_periodo DROP CONSTRAINT restriccion_de_periodo_pkey;
ALTER TABLE ONLY public.restriccion_de_periodo DROP CONSTRAINT restriccion_de_periodo_periodo_key;
ALTER TABLE ONLY public.restriccion_de_otro_recurso DROP CONSTRAINT restriccion_de_otro_recurso_pkey;
ALTER TABLE ONLY public.restriccion_de_otro_recurso DROP CONSTRAINT restriccion_de_otro_recurso_otro_recurso_key;
ALTER TABLE ONLY public.restriccion_de_lugar DROP CONSTRAINT restriccion_de_lugar_pkey;
ALTER TABLE ONLY public.restriccion_de_lugar DROP CONSTRAINT restriccion_de_lugar_lugar_key;
ALTER TABLE ONLY public.restriccion_de_especialidad DROP CONSTRAINT restriccion_de_especialidad_pkey;
ALTER TABLE ONLY public.restriccion_de_especialidad DROP CONSTRAINT restriccion_de_especialidad_especialidad_key;
ALTER TABLE ONLY public.restriccion_de_clasif_act DROP CONSTRAINT restriccion_de_clasif_act_pkey;
ALTER TABLE ONLY public.restriccion_de_clasif_act DROP CONSTRAINT restriccion_de_clasif_act_clasificacion_key;
ALTER TABLE ONLY public.restriccion_de_brigada DROP CONSTRAINT restriccion_de_brigada_pkey;
ALTER TABLE ONLY public.restriccion_de_brigada DROP CONSTRAINT restriccion_de_brigada_brigada_key;
ALTER TABLE ONLY public.restriccion_de_asignatura DROP CONSTRAINT restriccion_de_asignatura_pkey;
ALTER TABLE ONLY public.restriccion_de_asignatura DROP CONSTRAINT restriccion_de_asignatura_asignatura_key;
ALTER TABLE ONLY public.restriccion_condicional DROP CONSTRAINT restriccion_condicional_pkey;
ALTER TABLE ONLY public.receso DROP CONSTRAINT receso_pkey;
ALTER TABLE ONLY public.profesor DROP CONSTRAINT profesor_pkey;
ALTER TABLE ONLY public.profesor_para_grupo DROP CONSTRAINT profesor_para_grupo_pkey;
ALTER TABLE ONLY public.profesor_para_actividad DROP CONSTRAINT profesor_para_actividad_plantilla_key;
ALTER TABLE ONLY public.profesor_para_actividad DROP CONSTRAINT profesor_para_actividad_pkey;
ALTER TABLE ONLY public.plantilla_de_actividad DROP CONSTRAINT plantilla_de_actividad_pkey;
ALTER TABLE ONLY public.plantilla_de_actividad DROP CONSTRAINT plantilla_de_actividad_desglose_key;
ALTER TABLE ONLY public.planificacion DROP CONSTRAINT planificacion_pkey;
ALTER TABLE ONLY public.periodo DROP CONSTRAINT periodo_pkey;
ALTER TABLE ONLY public.periodicidad DROP CONSTRAINT periodicidad_pkey;
ALTER TABLE ONLY public.periodicidad DROP CONSTRAINT periodicidad_periodo_key;
ALTER TABLE ONLY public.otros_recursos_usados DROP CONSTRAINT otros_recursos_usados_pkey;
ALTER TABLE ONLY public.otro_recurso DROP CONSTRAINT otro_recurso_pkey;
ALTER TABLE ONLY public.otro_recurso_para_actividad DROP CONSTRAINT otro_recurso_para_actividad_pkey;
ALTER TABLE ONLY public.otro_grupo_de_recursos_para_actividad DROP CONSTRAINT otro_grupo_de_recursos_para_actividad_pkey;
ALTER TABLE ONLY public.nivel DROP CONSTRAINT nivel_pkey;
ALTER TABLE ONLY public.lugar DROP CONSTRAINT lugar_pkey;
ALTER TABLE ONLY public.lugar_para_actividad DROP CONSTRAINT lugar_para_actividad_pkey;
ALTER TABLE ONLY public.lugar_fijo DROP CONSTRAINT lugar_fijo_pkey;
ALTER TABLE ONLY public.higiene_para_profesor DROP CONSTRAINT higiene_para_profesor_pkey;
ALTER TABLE ONLY public.higiene_para_brigada DROP CONSTRAINT higiene_para_brigada_pkey;
ALTER TABLE ONLY public.herencia_de_restricciones DROP CONSTRAINT herencia_de_restricciones_pkey;
ALTER TABLE ONLY public.herencia_de_restricciones DROP CONSTRAINT herencia_de_restricciones_hijo_brigada_key;
ALTER TABLE ONLY public.grupo DROP CONSTRAINT grupo_pkey;
ALTER TABLE ONLY public.excepcion_de_hrt DROP CONSTRAINT excepcion_de_hrt_pkey;
ALTER TABLE ONLY public.especialidad DROP CONSTRAINT especialidad_pkey;
ALTER TABLE ONLY public.desglose DROP CONSTRAINT desglose_pkey;
ALTER TABLE ONLY public.desglose DROP CONSTRAINT desglose_asignatura_key;
ALTER TABLE ONLY public.costo_de_traslado DROP CONSTRAINT costo_de_traslado_pkey;
ALTER TABLE ONLY public.clasificacion_de_actividad DROP CONSTRAINT clasificacion_de_actividad_pkey;
ALTER TABLE ONLY public.brigada DROP CONSTRAINT brigada_pkey;
ALTER TABLE ONLY public.brigada_de_grupo DROP CONSTRAINT brigada_de_grupo_pkey;
ALTER TABLE ONLY public.asignatura DROP CONSTRAINT asignatura_pkey;
ALTER TABLE ONLY public.actividad DROP CONSTRAINT actividad_plantilla_key;
ALTER TABLE ONLY public.actividad DROP CONSTRAINT actividad_pkey;
ALTER TABLE ONLY public.acceso_prohibido DROP CONSTRAINT acceso_prohibido_pkey;
SET search_path = generador, pg_catalog;

ALTER TABLE ONLY generador.cancelar DROP CONSTRAINT cancelar_pkey;
SET search_path = seguridad, pg_catalog;

DROP TABLE seguridad.usuario;
DROP TABLE seguridad.traza;
DROP TABLE seguridad.rol_de_usuario;
DROP TABLE seguridad.rol;
DROP TABLE seguridad.permiso;
DROP TABLE seguridad.host;
SET search_path = public, pg_catalog;

DROP TABLE public.zpriori;
DROP VIEW public.uso_de_otros_recursos;
DROP TABLE public.restriccion_real_de_profesor;
DROP TABLE public.restriccion_real_de_periodo;
DROP TABLE public.restriccion_real_de_otro_recurso;
DROP TABLE public.restriccion_real_de_lugar;
DROP TABLE public.restriccion_real_de_especialidad;
DROP TABLE public.restriccion_real_de_clasif_act;
DROP TABLE public.restriccion_real_de_brigada;
DROP TABLE public.restriccion_real_de_asignatura;
DROP TABLE public.restriccion_real;
DROP TABLE public.restriccion_por_actividad_de_profesor;
DROP TABLE public.restriccion_por_actividad_de_otro_recurso;
DROP TABLE public.restriccion_por_actividad_de_lugar;
DROP TABLE public.restriccion_por_actividad_de_brigada;
DROP TABLE public.restriccion_por_actividad;
DROP TABLE public.restriccion_de_profesor;
DROP TABLE public.restriccion_de_periodo;
DROP TABLE public.restriccion_de_otro_recurso;
DROP TABLE public.restriccion_de_lugar;
DROP TABLE public.restriccion_de_especialidad;
DROP TABLE public.restriccion_de_clasif_act;
DROP TABLE public.restriccion_de_brigada;
DROP TABLE public.restriccion_de_asignatura;
DROP TABLE public.receso;
DROP TABLE public.profesor_para_grupo;
DROP TABLE public.profesor_para_actividad;
DROP TABLE public.profesor;
DROP TABLE public.plantilla_de_actividad;
DROP TABLE public.planificacion;
DROP TABLE public.periodicidad;
DROP TABLE public.otros_recursos_usados;
DROP TABLE public.otro_recurso_para_actividad;
DROP TABLE public.otro_grupo_de_recursos_para_actividad;
DROP TABLE public.nivel;
DROP TABLE public.lugar_para_actividad;
DROP TABLE public.lugar_fijo;
DROP TABLE public.higiene_para_profesor;
DROP TABLE public.higiene_para_brigada;
DROP TABLE public.herencia_de_restricciones;
DROP TABLE public.excepcion_de_hrt;
DROP TABLE public.especialidad;
DROP TABLE public.costo_de_traslado;
DROP TABLE public.clasificacion_de_actividad;
DROP TABLE public.brigada_de_grupo;
DROP VIEW public.asignaturas_cant_act;
DROP TABLE public.desglose;
DROP TABLE public.asignatura;
DROP TABLE public.acceso_prohibido;
SET search_path = generador, pg_catalog;

DROP TABLE generador.cancelar;
SET search_path = public, pg_catalog;

DROP AGGREGATE public.first(anyelement);
SET search_path = tiempo, pg_catalog;

DROP FUNCTION tiempo.today_number();
DROP FUNCTION tiempo.number_to_hour(n double precision);
DROP FUNCTION tiempo.number_to_date(n bigint);
DROP FUNCTION tiempo.month_from_day_number(n integer, a integer);
DROP FUNCTION tiempo.moment_number(fecha bigint, hora double precision);
DROP FUNCTION tiempo.moment_now();
DROP FUNCTION tiempo.is_leap_year(pyear integer);
DROP FUNCTION tiempo.hour_to_number(h integer, m integer, s integer);
DROP FUNCTION tiempo.hour_number_from_date_number(m double precision);
DROP FUNCTION tiempo.day_number(d integer, m integer, a integer);
DROP FUNCTION tiempo.date_to_number(d integer, m integer, a integer);
DROP FUNCTION tiempo.date_number_from_moment_number(m double precision);
DROP FUNCTION tiempo.current_hour_number();
DROP FUNCTION tiempo.countdays_of_month(m integer);
SET search_path = seguridad, pg_catalog;

DROP FUNCTION seguridad.tiene_permiso(pusuario character varying, ppermiso character varying);
DROP FUNCTION seguridad.check_host(pusuario character varying, pip character varying);
SET search_path = public, pg_catalog;

DROP FUNCTION public.valor_zpriori(clasif character varying, periodo character varying, dia integer, turno integer);
DROP FUNCTION public.valor_restriccion_profesor(id character varying, idperiodo character varying, pdia integer, pturno integer);
DROP FUNCTION public.valor_restriccion_periodo(idperiodo character varying, pdia integer, pturno integer);
DROP FUNCTION public.valor_restriccion_lugar(id character varying, idperiodo character varying, pdia integer, pturno integer);
DROP FUNCTION public.valor_restriccion_heredada(tipo_hijo character varying, id_hijo character varying, idperiodo character varying, pdia integer, pturno integer);
DROP FUNCTION public.valor_restriccion_generica(ptipo character varying, id character varying, idperiodo character varying, pdia integer, pturno integer, tipo_restricc character varying);
DROP FUNCTION public.valor_restriccion_especialidad(id character varying, idperiodo character varying, pdia integer, pturno integer);
DROP FUNCTION public.valor_restriccion_condicional(tipo_consec character varying, id_consec character varying, idperiodo character varying, pdia integer, pturno integer);
DROP FUNCTION public.valor_restriccion_clasif_act(id character varying, idperiodo character varying, pdia integer, pturno integer);
DROP FUNCTION public.valor_restriccion_brigada(id character varying, idperiodo character varying, pdia integer, pturno integer);
DROP FUNCTION public.valor_restriccion_asignatura(id character varying, idperiodo character varying, pdia integer, pturno integer);
DROP FUNCTION public.valor_rest_entre_config_distintas(rests integer[], per1 periodo, per2 periodo, dia integer, turno integer);
DROP TABLE public.periodo;
DROP FUNCTION public.turnos_se_solapan(idperiodo1 character varying, dia1 integer, turno1 integer, duracion1 integer, idperiodo2 character varying, dia2 integer, turno2 integer, duracion2 integer);
DROP FUNCTION public.sube_prioridad_clasif(idclasif character varying);
DROP FUNCTION public.sube_orden_de_plantilla(idplantilla character varying);
DROP FUNCTION public.restringe_segun_actividad(idactividad character varying, idplantilla character varying, idprofesor character varying, idlugar character varying, pdia integer, pturno integer, idgrupo character varying);
DROP FUNCTION public.restringe_por_uso_de_otro_recurso(idactividad character varying, idrecurso character varying);
DROP FUNCTION public.rango(idplantilla character varying, idgrupo character varying, minimo integer, maximo integer);
DROP FUNCTION public.rand();
DROP FUNCTION public.quita_segun_prohibidos(grupos character varying[], lugares character varying[]);
DROP FUNCTION public.quita_segun_capacidad(brigadas character varying[], lugares character varying[]);
DROP FUNCTION public.posible_inicio(idplantilla character varying, dia integer, turno integer, idbrigada character varying, plugares character varying[], pprofesores character varying[]);
DROP FUNCTION public.plpgsql_oid_debug(functionoid oid);
DROP FUNCTION public.pldbg_wait_for_target(session integer);
DROP FUNCTION public.pldbg_wait_for_breakpoint(session integer);
DROP FUNCTION public.pldbg_step_over(session integer);
DROP FUNCTION public.pldbg_step_into(session integer);
DROP FUNCTION public.pldbg_set_global_breakpoint(session integer, func oid, linenumber integer, targetpid integer);
DROP FUNCTION public.pldbg_set_breakpoint(session integer, func oid, linenumber integer);
DROP FUNCTION public.pldbg_select_frame(session integer, frame integer);
DROP FUNCTION public.pldbg_get_variables(session integer);
DROP FUNCTION public.pldbg_get_target_info(signature text, targettype "char");
DROP FUNCTION public.pldbg_get_stack(session integer);
DROP FUNCTION public.pldbg_get_source(session integer, func oid);
DROP FUNCTION public.pldbg_get_proxy_info();
DROP FUNCTION public.pldbg_get_breakpoints(session integer);
DROP FUNCTION public.pldbg_drop_breakpoint(session integer, func oid, linenumber integer);
DROP FUNCTION public.pldbg_deposit_value(session integer, varname text, linenumber integer, value text);
DROP FUNCTION public.pldbg_create_listener();
DROP FUNCTION public.pldbg_continue(session integer);
DROP FUNCTION public.pldbg_attach_to_port(portnumber integer);
DROP FUNCTION public.pldbg_abort_target(session integer);
DROP FUNCTION public.ocurre_causa_rest_cond(rc restriccion_condicional, act actividad, idperiodo character varying, pdia integer, pturno integer, analiza_completo boolean);
DROP TABLE public.restriccion_condicional;
DROP TABLE public.actividad;
DROP FUNCTION public.plantilla_exige_profesor(id character varying);
DROP FUNCTION public.plantilla_exige_lugar(id character varying);
DROP FUNCTION public.nuevo_desglose_cuando_nuevo_periodo();
DROP FUNCTION public.nuevo_desglose_cuando_nueva_asignatura();
DROP FUNCTION public.nivela_prioridad_rxact_after_delete();
DROP FUNCTION public.nivela_prioridad_lxact_after_update();
DROP FUNCTION public.nivela_prioridad_lxact_after_delete();
DROP FUNCTION public.mueve_o_crea_brigada_de_grupo(idbrg character varying, idgrupo character varying);
DROP FUNCTION public.max_cant_act(especialidad character varying, nivel character varying, periodo character varying);
DROP FUNCTION public.lugar_permanece_en(plugar character varying, pperiodo character varying, pdia integer, pturno integer, duracion integer);
DROP FUNCTION public.iif(expresion boolean, dato1 anyelement, dato2 anyelement);
DROP FUNCTION public.if(boolean, integer, integer);
DROP FUNCTION public.if(boolean, text, text);
DROP FUNCTION public."greatest"(numeric, numeric, numeric);
DROP FUNCTION public."greatest"(numeric, numeric);
DROP FUNCTION public.get_max_colocation(arr boolean[], duracion integer);
DROP FUNCTION public.generar(idesp character varying, idnivel character varying, idperiodo character varying, forma bigint, parche boolean, compactar bigint, parche1 boolean, buscalugar boolean);
DROP FUNCTION public.first(anyelement, anyelement);
DROP FUNCTION public.extraer_lugares_que_no_permanecen(lugares character varying[], periodo character varying, dia integer, turno integer, duracion integer);
DROP FUNCTION public.existe_grupo_de_profesor(profe_para_act character varying, pgrupo character varying);
DROP FUNCTION public.esta_otro_recurso_asignado(idrecurso character varying, idplantilla character varying);
DROP FUNCTION public.esta_dia_en_rango_planificacion(pdia integer, idperiodo character varying, dia_ini integer, dia_fin integer);
DROP FUNCTION public.es_lugar_prohibido(pgrupo character varying, plugar character varying);
DROP FUNCTION public.es_higienico_profesor(idprofesor character varying, idplantilla character varying, pdia integer);
DROP FUNCTION public.es_higienico_brigada(idbrigada character varying, idplantilla character varying, pdia integer);
DROP FUNCTION public.dias_se_solapan(idperiodo1 character varying, dia1 integer, idperiodo2 character varying, dia2 integer);
DROP FUNCTION public.dia_minimo_impacto(idclasif character varying, idesp character varying, idnivel character varying, idperiodo character varying, dia_ini integer, dia_fin integer);
DROP FUNCTION public.dame_zpriori(clasif character varying, idperiodo character varying);
DROP FUNCTION public.dame_uso_de_otro_recurso(id character varying);
DROP FUNCTION public.dame_total_otros_recursos_asignados(idplantilla character varying);
DROP FUNCTION public.dame_tipo_padre_hrt(pid character varying);
DROP FUNCTION public.dame_tipo_hijo_hrt(pid character varying);
DROP FUNCTION public.dame_tipo_consec_rest_cond(pid character varying);
DROP FUNCTION public.dame_profesores_no_asignados_a(idplantilla character varying);
DROP FUNCTION public.dame_plantilla_de_grupo_de_recursos(idgrupo character varying);
DROP FUNCTION public.dame_planificacion_de_periodo(pid character varying);
DROP FUNCTION public.dame_planificacion_de_grupo(idgrupo character varying);
DROP FUNCTION public.dame_periodo_plantilla_de_actividad(character varying);
DROP FUNCTION public.dame_periodo_desglose(character varying);
DROP FUNCTION public.dame_otros_recursos_sin_asignar(idplantilla character varying);
DROP TABLE public.otro_recurso;
DROP FUNCTION public.dame_nivel_de_grupo(idgrupo character varying);
DROP FUNCTION public.dame_nivel_de_brigada(idbrigada character varying);
DROP FUNCTION public.dame_nivel_de_asignatura(idasig character varying);
DROP FUNCTION public.dame_max_prioridad_rxact(idplantilla character varying);
DROP FUNCTION public.dame_max_prioridad_lxact(idplantilla character varying);
DROP FUNCTION public.dame_max_prioridad_de_pxact(idplantilla character varying);
DROP FUNCTION public.dame_max_priori_otro_recurso(idgr character varying);
DROP FUNCTION public.dame_max_priori_clasif_act(pcreador character varying);
DROP FUNCTION public.dame_max_orden_act(iddesglose character varying);
DROP FUNCTION public.dame_matricula_total(brigadas character varying[]);
DROP FUNCTION public.dame_matricula(brg character varying);
DROP FUNCTION public.dame_lugares_utilizados_en_el_dia(pgrupo character varying, periodo character varying, pdia integer);
DROP FUNCTION public.dame_lugares_usados_alrededor_de(brigadas character varying[], idperiodo character varying, pdia integer, pturno integer);
DROP FUNCTION public.dame_lugares_no_asignados_a(idplantilla character varying);
DROP TABLE public.lugar;
DROP FUNCTION public.dame_lista_id_profes_asignados_al_grupo(idplantilla character varying, idgrupo character varying);
DROP FUNCTION public.dame_lista_id_profes_asignados(idplantilla character varying);
DROP FUNCTION public.dame_lista_id_otros_recursos_usados(idactividad character varying);
DROP FUNCTION public.dame_lista_id_otros_recursos_asignados(idgrupo character varying);
DROP FUNCTION public.dame_lista_id_lugares_asignados(idplantilla character varying);
DROP FUNCTION public.dame_lista_id_grupos_de_recursos_asignados(idplantilla character varying);
DROP FUNCTION public.dame_lista_id_clasif();
DROP FUNCTION public.dame_lista_id_brigadas_de_grupo(pgrupo character varying);
DROP FUNCTION public.dame_lista_id_brigadas_de_esp(esp character varying, niv character varying);
DROP FUNCTION public.dame_idobjeto_de_restriccion_de_periodo(pid character varying);
DROP FUNCTION public.dame_idobjeto_de_restriccion_de_especialidad(pid character varying);
DROP FUNCTION public.dame_idobjeto_de_restriccion_de_brigada(pid character varying);
DROP FUNCTION public.dame_id_plantilla(idasig character varying, idperiodo character varying, orden bigint);
DROP FUNCTION public.dame_hora_inicial_turno(idperiodo character varying, pturno integer);
DROP FUNCTION public.dame_grupos_de_plantilla(idplantilla character varying);
DROP TABLE public.grupo;
DROP FUNCTION public.dame_grupos_de_brigadas(brigadas character varying[], idplantilla character varying);
DROP FUNCTION public.dame_grupos(idesp character varying, idnivel character varying, idclasif character varying);
DROP FUNCTION public.dame_grupo(brg character varying, clasif character varying);
DROP FUNCTION public.dame_gasto_lugares_en_el_dia(lugares character varying[], periodo character varying, pdia integer);
DROP FUNCTION public.dame_gasto_de_plantilla(idplantilla character varying);
DROP FUNCTION public.dame_especialidad_de_grupo(idgrupo character varying);
DROP FUNCTION public.dame_especialidad_de_brigada(idbrigada character varying);
DROP FUNCTION public.dame_especialidad_de_asignatura(idasig character varying);
DROP FUNCTION public.dame_duracion_turno_periodo(pid character varying);
DROP FUNCTION public.dame_duracion_plantilla_de_actividad(character varying);
DROP FUNCTION public.dame_duracion_clasif_de_actividad(character varying);
DROP FUNCTION public.dame_duracion_actividad(id character varying);
DROP FUNCTION public.dame_dia_real_planificacion(pid character varying, dia integer);
DROP FUNCTION public.dame_desglose_de_plantilla(idplantilla character varying);
DROP FUNCTION public.dame_creador_de_plantilla(idplantilla character varying);
DROP FUNCTION public.dame_creador_de_planificacion(id character varying);
DROP FUNCTION public.dame_creador_de_especialidad(esp character varying);
DROP FUNCTION public.dame_creador_de_clasifact(idclasif character varying);
DROP FUNCTION public.dame_creador_de_asignatura(idasig character varying);
DROP FUNCTION public.dame_costo_trasladar_recurso(idrecurso character varying, idlugar character varying, idperiodo character varying, pdia integer, pturno integer);
DROP FUNCTION public.dame_clasificacion_de_grupo(idgrupo character varying);
DROP FUNCTION public.dame_clasif_plantilla_de_actividad(character varying);
DROP FUNCTION public.dame_clasif_de_asignaturas(asignatura character varying, periodo character varying);
DROP FUNCTION public.dame_capacidad(lug character varying);
DROP FUNCTION public.dame_cant_turnos(idperiodo character varying);
DROP FUNCTION public.dame_cant_rest_profe(idprofe character varying, idperiodo character varying);
DROP FUNCTION public.dame_cant_rest_asignatura(idasig character varying, idperiodo character varying);
DROP FUNCTION public.dame_cant_profes_asignados(idplantilla character varying);
DROP FUNCTION public.dame_cant_otros_recursos_imprescindibles(idplantilla character varying);
DROP FUNCTION public.dame_cant_otros_recursos_asignados(idgrupo character varying);
DROP FUNCTION public.dame_cant_lugares_asignados(idplantilla character varying);
DROP FUNCTION public.dame_cant_grupos_de_recursos_asignados(idplantilla character varying);
DROP FUNCTION public.dame_cant_dias(idperiodo character varying);
DROP FUNCTION public.dame_cant_clasif();
DROP FUNCTION public.dame_cant_asig_de_esp_anno(idesp character varying, idnivel character varying);
DROP FUNCTION public.dame_cant_act_desglose(desglose character varying);
DROP FUNCTION public.dame_cant_act(asig character varying, periodo character varying);
DROP FUNCTION public.dame_cant_accesos_prohibidos_al_grupo(character varying);
DROP FUNCTION public.dame_brigadas_sin_grupo(idesp character varying, idnivel character varying, idclasif character varying, idplanificacion character varying);
DROP FUNCTION public.dame_brigadas_de_grupo(idgrupo character varying);
DROP TABLE public.brigada;
DROP FUNCTION public.dame_asignatura_plantilla_de_actividad(id character varying);
DROP FUNCTION public.dame_asignatura_desglose(character varying);
DROP FUNCTION public.dame_asig_segun_esp_anno_per(idesp character varying, idnivel character varying, idperiodo character varying);
DROP FUNCTION public.dame_asig_segun_esp_anno(idesp character varying, idnivel character varying);
DROP FUNCTION public.crear_id_de_replica(prefijo character varying, tabla character varying, campoid character varying, sufijo character varying);
DROP FUNCTION public.crear_cadena_aleatoria(caracteres character varying, longitud integer);
DROP FUNCTION public.concat(text, text);
DROP FUNCTION public.check_hrt(hijo_brigada character varying, hijo_profesor character varying, hijo_lugar character varying, hijo_otro_recurso character varying, padre_brigada character varying, padre_profesor character varying, padre_lugar character varying, padre_otro_recurso character varying);
DROP FUNCTION public.busca_lugar_menos_utilizado_por(lugares character varying[], idgrupo character varying, los_demas boolean);
DROP FUNCTION public.busca_lugar_menos_costoso(origenes character varying[], destinos character varying[]);
DROP FUNCTION public.busca_lugar_mas_utilizado_por(lugares character varying[], idgrupo character varying, los_demas boolean);
DROP FUNCTION public.bool_to_str(valor boolean);
DROP FUNCTION public.bool_to_int(valor boolean);
DROP FUNCTION public.baja_prioridad_clasif(idclasif character varying);
DROP FUNCTION public.baja_orden_de_plantilla(idplantilla character varying);
DROP FUNCTION public.arregla_prioridades_clasif_after_delete();
DROP FUNCTION public.arregla_prioridades_clasif(pcreador character varying);
DROP FUNCTION public.and_mpi(listaidbrg character varying[], cd integer, ct integer, idplantilla character varying, zona bigint, excepto boolean);
DROP FUNCTION public.agrega_actividad(idplantilla character varying, idprofesor character varying, idlugar character varying, pdia integer, pturno integer, idgrupo character varying, idrecursos character varying[], momento double precision, pcreador character varying);
DROP FUNCTION public.actualiza_restriccion_real(idobjeto character varying, idactividad character varying, idnominal character varying, idperiodo character varying, pdia integer, pturno integer, por_actividad boolean, tabla_real character varying);
DROP FUNCTION public.actualiza_profesor_para_grupo();
DROP FUNCTION public.actualiza_orden_plantillas(iddesglose character varying);
DROP FUNCTION public.actualiza_orden_actividades();
DROP FUNCTION public.actualiza_orden_act_before_update();
DROP FUNCTION public.actualiza_orden_act_before_insert();
DROP FUNCTION public.actualiza_orden_act_after_update();
DROP FUNCTION public.actualiza_orden_act_after_insert();
DROP FUNCTION public.actualiza_orden_act_after_delete();
SET search_path = prioriza, pg_catalog;

DROP FUNCTION prioriza.nivelar_matrix(tabla numeric[], criterios boolean[]);
DROP FUNCTION prioriza.nivelar(arr numeric[], criterio boolean);
SET search_path = matrix, pg_catalog;

DROP FUNCTION matrix.set_matrix_in_cube(OUT pcube anyarray, pmatrix anyarray, pos bigint);
DROP FUNCTION matrix.get_pos_of(arr anyarray, v anyelement);
DROP FUNCTION matrix.get_min_pos(arr anyarray);
DROP FUNCTION matrix.get_min(arr anyarray);
DROP FUNCTION matrix.get_max_pos(arr anyarray);
DROP FUNCTION matrix.get_max(arr anyarray);
DROP FUNCTION matrix.get_length_of(arr anyelement, dimension integer);
DROP FUNCTION matrix.get_count_of_value_in(arr anyarray, valor anyelement);
DROP FUNCTION matrix.get_count_of_dims(arr anyelement);
DROP FUNCTION matrix.extract_string_column(arr anyelement, c bigint);
DROP FUNCTION matrix.extract_numeric_column(arr anyelement, c bigint);
DROP FUNCTION matrix.extract_boolean_column(arr anyelement, c bigint);
DROP FUNCTION matrix.echo(arr anyarray);
DROP FUNCTION matrix.create_string_matrix(filas bigint, columnas bigint);
DROP FUNCTION matrix.create_string_list(filas bigint);
DROP FUNCTION matrix.create_numeric_matrix(filas bigint, columnas bigint);
DROP FUNCTION matrix.create_numeric_list(filas bigint);
DROP FUNCTION matrix.create_boolean_matrix(filas bigint, columnas bigint);
DROP FUNCTION matrix.create_boolean_list(filas bigint);
DROP FUNCTION matrix.create_boolean_cube(x bigint, y bigint, z bigint);
SET search_path = generador, pg_catalog;

DROP FUNCTION generador.fue_cancelado(idesp character varying, idnivel character varying, idperiodo character varying);
SET search_path = tiempo, pg_catalog;

DROP TYPE tiempo.ancora_hour;
DROP TYPE tiempo.ancora_date;
SET search_path = public, pg_catalog;

DROP TYPE public.var;
DROP TYPE public.trango;
DROP TYPE public.targetinfo;
DROP DOMAIN public.smallint_unsigned;
DROP TYPE public.proxyinfo;
DROP DOMAIN public.int_unsigned;
DROP TYPE public.frame;
DROP TYPE public.breakpoint;
DROP DOMAIN public.bigint_unsigned;
DROP PROCEDURAL LANGUAGE plpgsql;
DROP SCHEMA tiempo;
DROP SCHEMA seguridad;
DROP SCHEMA public;
DROP SCHEMA prioriza;
DROP SCHEMA matrix;
DROP SCHEMA generador;
--
-- Name: generador; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA generador;


ALTER SCHEMA generador OWNER TO postgres;

--
-- Name: matrix; Type: SCHEMA; Schema: -; Owner: rafa
--

CREATE SCHEMA matrix;


ALTER SCHEMA matrix OWNER TO rafa;

--
-- Name: prioriza; Type: SCHEMA; Schema: -; Owner: rafa
--

CREATE SCHEMA prioriza;


ALTER SCHEMA prioriza OWNER TO rafa;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: seguridad; Type: SCHEMA; Schema: -; Owner: rafa
--

CREATE SCHEMA seguridad;


ALTER SCHEMA seguridad OWNER TO rafa;

--
-- Name: tiempo; Type: SCHEMA; Schema: -; Owner: rafa
--

CREATE SCHEMA tiempo;


ALTER SCHEMA tiempo OWNER TO rafa;

--
-- Name: plpgsql; Type: PROCEDURAL LANGUAGE; Schema: -; Owner: rafa
--

CREATE PROCEDURAL LANGUAGE plpgsql;


ALTER PROCEDURAL LANGUAGE plpgsql OWNER TO rafa;

SET search_path = public, pg_catalog;

--
-- Name: bigint_unsigned; Type: DOMAIN; Schema: public; Owner: rafa
--

CREATE DOMAIN bigint_unsigned AS bigint
	CONSTRAINT bigint_unsigned_check CHECK ((VALUE >= 0));


ALTER DOMAIN public.bigint_unsigned OWNER TO rafa;

--
-- Name: breakpoint; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE breakpoint AS (
	func oid,
	linenumber integer,
	targetname text
);


ALTER TYPE public.breakpoint OWNER TO postgres;

--
-- Name: frame; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE frame AS (
	level integer,
	targetname text,
	func oid,
	linenumber integer,
	args text
);


ALTER TYPE public.frame OWNER TO postgres;

--
-- Name: int_unsigned; Type: DOMAIN; Schema: public; Owner: rafa
--

CREATE DOMAIN int_unsigned AS integer
	CONSTRAINT int_unsigned_check CHECK ((VALUE >= 0));


ALTER DOMAIN public.int_unsigned OWNER TO rafa;

--
-- Name: proxyinfo; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE proxyinfo AS (
	serverversionstr text,
	serverversionnum integer,
	proxyapiver integer,
	serverprocessid integer
);


ALTER TYPE public.proxyinfo OWNER TO postgres;

--
-- Name: smallint_unsigned; Type: DOMAIN; Schema: public; Owner: rafa
--

CREATE DOMAIN smallint_unsigned AS smallint
	CONSTRAINT smallint_unsigned_check CHECK ((VALUE >= 0));


ALTER DOMAIN public.smallint_unsigned OWNER TO rafa;

--
-- Name: targetinfo; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE targetinfo AS (
	target oid,
	schema oid,
	nargs integer,
	argtypes oidvector,
	targetname name,
	argmodes "char"[],
	argnames text[],
	targetlang oid,
	fqname text,
	returnsset boolean,
	returntype oid
);


ALTER TYPE public.targetinfo OWNER TO postgres;

--
-- Name: trango; Type: TYPE; Schema: public; Owner: rafa
--

CREATE TYPE trango AS (
	ini integer,
	fin integer
);


ALTER TYPE public.trango OWNER TO rafa;

--
-- Name: var; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE var AS (
	name text,
	varclass character(1),
	linenumber integer,
	isunique boolean,
	isconst boolean,
	isnotnull boolean,
	dtype oid,
	value text
);


ALTER TYPE public.var OWNER TO postgres;

SET search_path = tiempo, pg_catalog;

--
-- Name: ancora_date; Type: TYPE; Schema: tiempo; Owner: rafa
--

CREATE TYPE ancora_date AS (
	d integer,
	m integer,
	a integer
);


ALTER TYPE tiempo.ancora_date OWNER TO rafa;

--
-- Name: ancora_hour; Type: TYPE; Schema: tiempo; Owner: rafa
--

CREATE TYPE ancora_hour AS (
	h integer,
	m integer,
	s integer
);


ALTER TYPE tiempo.ancora_hour OWNER TO rafa;

SET search_path = generador, pg_catalog;

--
-- Name: fue_cancelado(character varying, character varying, character varying); Type: FUNCTION; Schema: generador; Owner: postgres
--

CREATE FUNCTION fue_cancelado(idesp character varying, idnivel character varying, idperiodo character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
	declare
		r record;
	begin
		select * into r from generador.cancelar where especialidad = idesp and nivel = idnivel and periodo = idperiodo;

		if found then
			delete from generador.cancelar where especialidad = idesp and nivel = idnivel and periodo = idperiodo;
			return true;
		end if;

		return false;
	end;
$$;


ALTER FUNCTION generador.fue_cancelado(idesp character varying, idnivel character varying, idperiodo character varying) OWNER TO postgres;

SET search_path = matrix, pg_catalog;

--
-- Name: create_boolean_cube(bigint, bigint, bigint); Type: FUNCTION; Schema: matrix; Owner: rafa
--

CREATE FUNCTION create_boolean_cube(x bigint, y bigint, z bigint) RETURNS boolean[]
    LANGUAGE plpgsql
    AS $$
    DECLARE
        xs VARCHAR;
        ys VARCHAR;
        zs VARCHAR;
        matrix BOOLEAN[][][];
        i BIGINT;
        j BIGINT;
        k BIGINT;
    BEGIN
        IF x IS NULL OR y is NULL OR z IS NULL OR x = 0 OR y = 0 OR z = 0 THEN
            RETURN '{}'::BOOLEAN[][][];
        END IF;
        
        xs := '{';
        i := 1;
        LOOP
            j := 1;
            ys := '{';
            
            LOOP
                k := 1;
                
                zs := '{';

                LOOP
                    zs := zs || 'FALSE';

                    IF k <> z THEN
                        zs := zs || ',';
                    END IF;
                    
                    EXIT WHEN k >= z;
                    k := k + 1;
                END LOOP;
                
                zs := zs || '}';

                ys := ys || zs;

                IF j <> y THEN
                    ys := ys || ',';
                END IF;
                
                EXIT WHEN j >= y;
                j := j + 1;
            END LOOP;
            
            ys := ys || '}';

            xs := xs || ys;
            
            IF i <> x THEN
                xs := xs || ',';
            END IF;

            
            EXIT WHEN i >= x;
            i := i + 1;
        END LOOP;
        
        xs := xs || '}';

        matrix := xs::BOOLEAN[][][];
        RETURN matrix;
    END;
$$;


ALTER FUNCTION matrix.create_boolean_cube(x bigint, y bigint, z bigint) OWNER TO rafa;

--
-- Name: create_boolean_list(bigint); Type: FUNCTION; Schema: matrix; Owner: rafa
--

CREATE FUNCTION create_boolean_list(filas bigint) RETURNS boolean[]
    LANGUAGE plpgsql
    AS $$
DECLARE
    fila VARCHAR;
    s VARCHAR;
    matrix BOOLEAN[];
    i BIGINT;
BEGIN
    
    s := '{';
    i := 1;

    IF filas IS NULL or filas = 0 THEN
        RETURN '{}'::BOOLEAN[];
    END IF;
    
    LOOP
        s := s || 'FALSE';

        IF i <> filas THEN
            s := s || ',';
        END IF;
        
        EXIT WHEN i >= filas;
        i := i + 1;
    END LOOP;
    
    s := s || '}';

    matrix := s::BOOLEAN[];
    RETURN matrix;
END;
$$;


ALTER FUNCTION matrix.create_boolean_list(filas bigint) OWNER TO rafa;

--
-- Name: create_boolean_matrix(bigint, bigint); Type: FUNCTION; Schema: matrix; Owner: rafa
--

CREATE FUNCTION create_boolean_matrix(filas bigint, columnas bigint) RETURNS boolean[]
    LANGUAGE plpgsql
    AS $$
    DECLARE
        fila VARCHAR;
        s VARCHAR;
        matrix BOOLEAN[][];
        i BIGINT;
        j BIGINT;
    BEGIN
        IF filas IS NULL OR columnas is NULL OR filas = 0 OR columnas = 0 THEN
            RETURN '{}'::BOOLEAN[][];
        END IF;
        
        s := '{';
        i := 1;
        LOOP
            j := 1;
            fila := '{';
            LOOP
                fila := fila || 'FALSE';

                IF j <> columnas THEN
                    fila := fila || ',';
                END IF;
                
                EXIT WHEN j >= columnas;
                j := j + 1;
            END LOOP;
            
            fila := fila || '}';

            s := s || fila;
            IF i <> filas THEN
                s := s || ',';
            END IF;

            
            EXIT WHEN i >= filas;
            i := i + 1;
        END LOOP;
        
        s := s || '}';

        matrix := s::BOOLEAN[][];
        RETURN matrix;
    END;
$$;


ALTER FUNCTION matrix.create_boolean_matrix(filas bigint, columnas bigint) OWNER TO rafa;

--
-- Name: create_numeric_list(bigint); Type: FUNCTION; Schema: matrix; Owner: rafa
--

CREATE FUNCTION create_numeric_list(filas bigint) RETURNS numeric[]
    LANGUAGE plpgsql
    AS $$
DECLARE
    fila VARCHAR;
    s VARCHAR;
    matrix NUMERIC[];
    i BIGINT;
BEGIN
    IF filas IS NULL OR filas = 0 THEN
        RETURN '{}'::NUMERIC[];
    END IF;
    
    s := '{';
    i := 1;
    
    LOOP
        s := s || '0';

        IF i <> filas THEN
            s := s || ',';
        END IF;
        
        EXIT WHEN i >= filas;
        i := i + 1;
    END LOOP;
    
    s := s || '}';

    matrix := s::NUMERIC[];
    
    RETURN matrix;
END;
$$;


ALTER FUNCTION matrix.create_numeric_list(filas bigint) OWNER TO rafa;

--
-- Name: FUNCTION create_numeric_list(filas bigint); Type: COMMENT; Schema: matrix; Owner: rafa
--

COMMENT ON FUNCTION create_numeric_list(filas bigint) IS 'Construye un arreglo de booleanos';


--
-- Name: create_numeric_matrix(bigint, bigint); Type: FUNCTION; Schema: matrix; Owner: rafa
--

CREATE FUNCTION create_numeric_matrix(filas bigint, columnas bigint) RETURNS numeric[]
    LANGUAGE plpgsql
    AS $$
    DECLARE
        fila VARCHAR;
        s VARCHAR;
        matrix NUMERIC[][];
        i BIGINT;
        j BIGINT;
    BEGIN
        IF filas IS NULL OR columnas is NULL or filas = 0 or columnas = 0 THEN
            RETURN '{}'::NUMERIC[][];
        END IF;
        s := '{';
        i := 1;
        LOOP
            j := 1;
            fila := '{';
            LOOP
                fila := fila || '0';

                IF j <> columnas THEN
                    fila := fila || ',';
                END IF;
                
                EXIT WHEN j >= columnas;
                j := j + 1;
            END LOOP;
            
            fila := fila || '}';

            s := s || fila;
            IF i <> filas THEN
                s := s || ',';
            END IF;

            
            EXIT WHEN i >= filas;
            i := i + 1;
        END LOOP;
        
        s := s || '}';

        matrix := s::NUMERIC[][];
        RETURN matrix;
    END;
$$;


ALTER FUNCTION matrix.create_numeric_matrix(filas bigint, columnas bigint) OWNER TO rafa;

--
-- Name: create_string_list(bigint); Type: FUNCTION; Schema: matrix; Owner: rafa
--

CREATE FUNCTION create_string_list(filas bigint) RETURNS character varying[]
    LANGUAGE plpgsql
    AS $$
DECLARE
    fila VARCHAR;
    s VARCHAR;
    matrix VARCHAR[];
    i BIGINT;
BEGIN
    
    s := '{';
    i := 1;

    IF filas IS NULL or filas = 0THEN
        RETURN '{}'::VARCHAR[];
    END IF;
    
    LOOP
        s := s || quote_literal('');

        IF i <> filas THEN
            s := s || ',';
        END IF;
        
        EXIT WHEN i >= filas;
        i := i + 1;
    END LOOP;
    
    s := s || '}';

    matrix := s::VARCHAR[];
    RETURN matrix;
END;
$$;


ALTER FUNCTION matrix.create_string_list(filas bigint) OWNER TO rafa;

--
-- Name: create_string_matrix(bigint, bigint); Type: FUNCTION; Schema: matrix; Owner: rafa
--

CREATE FUNCTION create_string_matrix(filas bigint, columnas bigint) RETURNS character varying[]
    LANGUAGE plpgsql
    AS $$
    DECLARE
        fila VARCHAR;
        s VARCHAR;
        matrix VARCHAR[][];
        i BIGINT;
        j BIGINT;
    BEGIN
        IF filas IS NULL OR columnas is NULL or filas = 0 or columnas = 0 THEN
            RETURN '{}'::VARCHAR[][];
        END IF;
        
        s := '{';
        i := 1;
        LOOP
            j := 1;
            fila := '{';
            LOOP
                fila := fila || quote_literal('');

                IF j <> columnas THEN
                    fila := fila || ',';
                END IF;
                
                EXIT WHEN j >= columnas;
                j := j + 1;
            END LOOP;
            
            fila := fila || '}';

            s := s || fila;

            IF i <> filas THEN
                s := s || ',';
            END IF;

            
            EXIT WHEN i >= filas;

            i := i + 1;
        END LOOP;
        
        s := s || '}';

        matrix := s::VARCHAR[][];
        RETURN matrix;
    END;
$$;


ALTER FUNCTION matrix.create_string_matrix(filas bigint, columnas bigint) OWNER TO rafa;

--
-- Name: echo(anyarray); Type: FUNCTION; Schema: matrix; Owner: rafa
--

CREATE FUNCTION echo(arr anyarray) RETURNS void
    LANGUAGE plpgsql
    AS $$
    BEGIN
        RAISE NOTICE '[INFO] array = %', array_to_string(arr,',');
    END;
$$;


ALTER FUNCTION matrix.echo(arr anyarray) OWNER TO rafa;

--
-- Name: extract_boolean_column(anyelement, bigint); Type: FUNCTION; Schema: matrix; Owner: rafa
--

CREATE FUNCTION extract_boolean_column(arr anyelement, c bigint) RETURNS boolean[]
    LANGUAGE plpgsql
    AS $$
    DECLARE narr BOOLEAN[];
        i BIGINT;
        crows BIGINT;
    BEGIN
        i := 1;
        crows := matrix.get_length_of(arr,2);
        IF crows > 0 THEN
            LOOP
                narr := array_append(narr, arr[i][c]);
                EXIT WHEN i >= crows;
                i := i + 1;
            END LOOP;
        END IF;
        RETURN narr;
    END;
$$;


ALTER FUNCTION matrix.extract_boolean_column(arr anyelement, c bigint) OWNER TO rafa;

--
-- Name: extract_numeric_column(anyelement, bigint); Type: FUNCTION; Schema: matrix; Owner: rafa
--

CREATE FUNCTION extract_numeric_column(arr anyelement, c bigint) RETURNS numeric[]
    LANGUAGE plpgsql
    AS $$
    DECLARE narr NUMERIC[];
        i BIGINT;
        crows BIGINT;
    BEGIN
        i := 1;
        crows := matrix.get_length_of(arr,2);
        IF crows > 0 THEN
            LOOP
                narr := array_append(narr, arr[i][c]);
                EXIT WHEN i >= crows;
                i := i + 1;
            END LOOP;
        END IF;
        RETURN narr;
    END;
$$;


ALTER FUNCTION matrix.extract_numeric_column(arr anyelement, c bigint) OWNER TO rafa;

--
-- Name: extract_string_column(anyelement, bigint); Type: FUNCTION; Schema: matrix; Owner: rafa
--

CREATE FUNCTION extract_string_column(arr anyelement, c bigint) RETURNS text[]
    LANGUAGE plpgsql
    AS $$
    DECLARE narr text[];
        i BIGINT;
        crows BIGINT;
    BEGIN
        i := 1;
        crows := matrix.get_length_of(arr,2);
        IF crows > 0 THEN
            LOOP
                narr := array_append(narr, arr[i][c]);
                EXIT WHEN i >= crows;
                i := i + 1;
            END LOOP;
        END IF;
        RETURN narr;
    END;
$$;


ALTER FUNCTION matrix.extract_string_column(arr anyelement, c bigint) OWNER TO rafa;

--
-- Name: get_count_of_dims(anyelement); Type: FUNCTION; Schema: matrix; Owner: rafa
--

CREATE FUNCTION get_count_of_dims(arr anyelement) RETURNS integer
    LANGUAGE plpgsql
    AS $$
    DECLARE c INTEGER;
    BEGIN
        c := 0;
        LOOP
            IF split_part(array_dims(arr),'][',c + 1) <> '' THEN
                c:= c + 1;
            ELSE 
                EXIT;
            END IF;
            EXIT WHEN c = 36000;
        END LOOP;
        
        RETURN c;
    END;
$$;


ALTER FUNCTION matrix.get_count_of_dims(arr anyelement) OWNER TO rafa;

--
-- Name: get_count_of_value_in(anyarray, anyelement); Type: FUNCTION; Schema: matrix; Owner: rafa
--

CREATE FUNCTION get_count_of_value_in(arr anyarray, valor anyelement) RETURNS integer
    LANGUAGE plpgsql
    AS $$
    DECLARE c BIGINT;
        i INTEGER;
        j INTEGER;
        k INTEGER;
        dims INTEGER;    
        x INTEGER; 
        y INTEGER; 
        z INTEGER;
        narr text;
        nvalor text;
    BEGIN
        c := 0;
        
        dims := matrix.get_count_of_dims(arr);

        -- m?de 3 es un caso excepcional:
        --   se convierte el arreglo a texto y luego arreglo unidimensional
        --   y se duevuelve se trata como tal, puede que el tamano de text no cubra
        --   todos los elementos del arreglo
        
        IF dims > 3 THEN
        
            x := matrix.get_length_of(string_to_array(array_to_string(arr,'~*~'), '~*~'), 1);
            IF x > 0 THEN
                narr := array_to_string(arr,'~*~') || '';

                nvalor := valor || '';

                i := 1;
                
                LOOP
                    IF nvalor = split_part(narr,'~*~',i) THEN
                        c := c + 1;
                    END IF;
                    
                    EXIT WHEN i >= x;
                    i := i + 1;
                END LOOP;
            END IF;
            
        END IF;
        
        
        -- Es una lista
        IF dims = 1 THEN
            
            x := matrix.get_length_of(arr, 1);
            IF x > 0 THEN
                i := 0;

                LOOP
                    IF arr[i] = valor THEN
                        c := c + 1;
                    END IF;
                    EXIT WHEN i >= x;
                    i := i + 1;
                END LOOP;
            END IF;
        END IF;

        -- Es una tabla
        IF dims = 2 THEN
        
            x := matrix.get_length_of(arr,1);
            
            y := matrix.get_length_of(arr,2);

            IF x > 0 AND y > 0 THEN
                i := 0;
                
                LOOP
                    j := 0;
                    LOOP
                        IF arr[i][j] = valor THEN
                            c := c + 1;
                        END IF;
                        EXIT WHEN j >= y;
                        
                        j := j + 1;
                    END LOOP;
                    EXIT WHEN i >= x;
                    
                    i := i + 1;
                END LOOP;
            END IF;
        END IF;
        
        -- Es un cubo
        IF dims = 3 THEN
        
            x := matrix.get_length_of(arr,1);
            
            y := matrix.get_length_of(arr,2);
            
            z := matrix.get_length_of(arr,3);

            IF x > 0 AND y > 0 AND z > 0 THEN
                i := 0;
                
                LOOP
                    j := 0;
                    LOOP
                        k := 0;
                        LOOP
                            IF arr[i][j][k] = valor THEN                        
                                c := c + 1;
                            END IF;
                            
                            EXIT WHEN k >= z;
                            
                            k := k + 1;
                            
                        END LOOP;
                        EXIT WHEN j >= y;
                        j := j + 1;
                    END LOOP;
                    EXIT WHEN i >= x;
                    i := i + 1;
                END LOOP;
            END IF;
        END IF;

        RETURN c;

    END;
$$;


ALTER FUNCTION matrix.get_count_of_value_in(arr anyarray, valor anyelement) OWNER TO rafa;

--
-- Name: get_length_of(anyelement, integer); Type: FUNCTION; Schema: matrix; Owner: rafa
--

CREATE FUNCTION get_length_of(arr anyelement, dimension integer) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
    BEGIN
	IF arr IS NULL THEN
		return 0;
	END IF;
	
        RETURN to_number(split_part(split_part(array_dims(arr),'][',dimension),':',2),'9999999999');
    END;
$$;


ALTER FUNCTION matrix.get_length_of(arr anyelement, dimension integer) OWNER TO rafa;

--
-- Name: get_max(anyarray); Type: FUNCTION; Schema: matrix; Owner: rafa
--

CREATE FUNCTION get_max(arr anyarray) RETURNS anyelement
    LANGUAGE plpgsql
    AS $$
    BEGIN
        RETURN arr[matrix.get_max_pos(arr)];
    END;
$$;


ALTER FUNCTION matrix.get_max(arr anyarray) OWNER TO rafa;

--
-- Name: get_max_pos(anyarray); Type: FUNCTION; Schema: matrix; Owner: rafa
--

CREATE FUNCTION get_max_pos(arr anyarray) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
    DECLARE 
        pos bigint;
        i bigint;
        cant bigint;
    BEGIN

        cant := matrix.get_length_of(arr, 1);
        
        IF cant < 1 THEN
            RETURN -1;
        END IF;
        
        pos := 1;
        i := 1;
        LOOP
            EXIT WHEN i > cant;
            
            IF arr[pos] < arr[i]  THEN 
                pos := i;
            END IF;

            EXIT WHEN i = cant;
            i := i + 1;
            
        END LOOP;

        RETURN pos;
    END;
$$;


ALTER FUNCTION matrix.get_max_pos(arr anyarray) OWNER TO rafa;

--
-- Name: get_min(anyarray); Type: FUNCTION; Schema: matrix; Owner: rafa
--

CREATE FUNCTION get_min(arr anyarray) RETURNS anyelement
    LANGUAGE plpgsql
    AS $$
    BEGIN
        RETURN arr[matrix.get_min_pos(arr)];
    END;
$$;


ALTER FUNCTION matrix.get_min(arr anyarray) OWNER TO rafa;

--
-- Name: get_min_pos(anyarray); Type: FUNCTION; Schema: matrix; Owner: rafa
--

CREATE FUNCTION get_min_pos(arr anyarray) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
    DECLARE 
        pos bigint;
        i bigint;
        cant bigint;
    BEGIN
        cant := matrix.get_length_of(arr, 1);
        
        IF cant < 1 THEN
            RETURN -1;
        END IF;
        
        pos := 1;
        i := 1;
        LOOP
            EXIT WHEN i > cant;
            IF arr[pos] > arr[i] THEN 
                pos := i;
            END IF;

            EXIT WHEN i = cant;
            i := i + 1;
        END LOOP;

        RETURN pos;
    END;
$$;


ALTER FUNCTION matrix.get_min_pos(arr anyarray) OWNER TO rafa;

--
-- Name: get_pos_of(anyarray, anyelement); Type: FUNCTION; Schema: matrix; Owner: rafa
--

CREATE FUNCTION get_pos_of(arr anyarray, v anyelement) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
    DECLARE i BIGINT; j BIGINT; 
        x BIGINT;
    BEGIN
        x := matrix.get_length_of(arr,1);
        IF x > 0 THEN
            i := 1;
            LOOP
                IF arr[i] = v THEN
                    RETURN i;
                END IF;
                
                EXIT WHEN i >= x;
                i := i + 1;
            END LOOP;
        END IF;
        RETURN -1;
        
    END;
$$;


ALTER FUNCTION matrix.get_pos_of(arr anyarray, v anyelement) OWNER TO rafa;

--
-- Name: set_matrix_in_cube(anyarray, bigint); Type: FUNCTION; Schema: matrix; Owner: rafa
--

CREATE FUNCTION set_matrix_in_cube(OUT pcube anyarray, pmatrix anyarray, pos bigint) RETURNS anyarray
    LANGUAGE plpgsql
    AS $$
    DECLARE x BIGINT; y BIGINT; z BIGINT; r BIGINT; c BIGINT; i BIGINT; j BIGINT; 
    BEGIN
        x := matrix.get_length_of(pcube,1);
        y := matrix.get_length_of(pcube,2);
        z := matrix.get_length_of(pcube,3);

        r := matrix.get_length_of(pmatrix,1);
        c := matrix.get_length_of(pmatrix,2);

        IF x > 0 AND y > 0 AND z > 0 AND r > 0 AND c > 0 THEN
                    
            i := 0;
            LOOP
                j := 0;
                LOOP
                    
                    pcube[pos][i][j] := pmatrix[i][j];
                    
                    EXIT WHEN j >= c;
                    j := j + 1;
                END LOOP;
                EXIT WHEN i >= r;
                i := i + 1;
            END LOOP;
        END IF;
    END;
$$;


ALTER FUNCTION matrix.set_matrix_in_cube(OUT pcube anyarray, pmatrix anyarray, pos bigint) OWNER TO rafa;

SET search_path = prioriza, pg_catalog;

--
-- Name: nivelar(numeric[], boolean); Type: FUNCTION; Schema: prioriza; Owner: rafa
--

CREATE FUNCTION nivelar(arr numeric[], criterio boolean) RETURNS integer[]
    LANGUAGE plpgsql
    AS $$
    DECLARE niveles int[];
        nivel int;
        ya BOOLEAN[];
        i INTEGER;
        countya INTEGER;
        optimo INTEGER;
        primero BOOLEAN;
        cant bigint;
    BEGIN
        nivel := 1;
        cant := matrix.get_length_of(arr,1);
        niveles := matrix.create_numeric_list(cant);

	--RAISE NOTICE 'Nivelando una fila';
        
        i := 0;
        countya := 0;

        LOOP
            ya[i] = FALSE;
            EXIT WHEN i >= cant;
            i := i + 1;
        END LOOP;

        LOOP
            
            IF criterio = TRUE THEN
		--RAISE NOTICE 'Criterio TRUE buscando minimo...';
                -- buscando minimo
                optimo := 0;
                primero := TRUE;
                i := 1;
                LOOP
                    IF ya[i] = FALSE THEN
                        IF optimo > arr[i] or primero = TRUE THEN 
                            optimo := arr[i];
                            primero := FALSE;
                        END IF;
                    END IF;

                    EXIT WHEN i >= cant;
                    i := i + 1;
                    
                END LOOP;
            ELSE
		--RAISE NOTICE 'Criterio FALSE buscando maximo...';
                -- buscando maximo
                optimo := 0;
                primero := TRUE;
                i := 1;
                LOOP
                    IF ya[i] = FALSE THEN
                        IF optimo < arr[i] or primero = TRUE THEN 
                            optimo := arr[i];
                            primero := FALSE;
                        END IF;
                    END IF;
                    
                    EXIT WHEN i >= cant;
                    i := i + 1;
                    
                END LOOP;
            END IF;

	    --RAISE NOTICE 'Optimo %', optimo;
	    --RAISE NOTICE 'Criterio TRUE buscando minimo... %', countya;
	    
            i := 1;
            LOOP
                IF ya[i] = FALSE THEN
                    IF optimo = arr[i] THEN 
                        niveles[i] := nivel;
                        ya[i] := TRUE;
                        countya := countya + 1;                    
                    END IF;
                END IF;
                
                EXIT WHEN i >= cant;
                i := i + 1;
            END LOOP;
            nivel := nivel + 1;
            EXIT WHEN countya = cant;
        END LOOP;
        RETURN niveles;
    END;
$$;


ALTER FUNCTION prioriza.nivelar(arr numeric[], criterio boolean) OWNER TO rafa;

--
-- Name: nivelar_matrix(numeric[], boolean[]); Type: FUNCTION; Schema: prioriza; Owner: rafa
--

CREATE FUNCTION nivelar_matrix(tabla numeric[], criterios boolean[]) RETURNS integer[]
    LANGUAGE plpgsql
    AS $$
    DECLARE
        valores NUMERIC[];
        nivelados INTEGER[];
        niveles INTEGER[][];
        filas bigint;
        columnas bigint;
        i INTEGER;
        j INTEGER;
    BEGIN

        niveles := tabla;
        filas := matrix.get_length_of(tabla,1);
        columnas := matrix.get_length_of(tabla,2);

	--RAISE NOTICE 'filas %, columnas %', filas, columnas;
        
        i := 1;
        LOOP
            -- tomo la columna actual
            --RAISE NOTICE 'nivelando columna % de %', i, columnas;
            j :=1;
            LOOP
                valores[j] = tabla[j][i];
                EXIT WHEN j >= filas;
                j := j + 1;
            END LOOP;
            
            -- nivelo la columna
	    
	    --EXECUTE matrix.echo(valores);
	    --EXECUTE matrix.echo(criterios);
            nivelados := prioriza.nivelar(valores, criterios[i]);
            
            -- la introduzco en la matriz de respuesta

            j := 1;
            LOOP
                niveles[j][i] := nivelados[j];            
                EXIT WHEN j >= filas;
                j := j + 1;
            END LOOP;            
            
            EXIT WHEN i >= columnas;
            i := i + 1;
        END LOOP;

        RETURN niveles;
    END;
$$;


ALTER FUNCTION prioriza.nivelar_matrix(tabla numeric[], criterios boolean[]) OWNER TO rafa;

SET search_path = public, pg_catalog;

--
-- Name: actualiza_orden_act_after_delete(); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION actualiza_orden_act_after_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	declare r integer;
	begin

		r := actualiza_orden_plantillas(OLD.desglose);
		return OLD;
	end;
$$;


ALTER FUNCTION public.actualiza_orden_act_after_delete() OWNER TO rafa;

--
-- Name: actualiza_orden_act_after_insert(); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION actualiza_orden_act_after_insert() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	declare r integer;
	
	begin
		r := actualiza_orden_plantillas(NEW.desglose);
		
		return NEW;
	end;
$$;


ALTER FUNCTION public.actualiza_orden_act_after_insert() OWNER TO rafa;

--
-- Name: actualiza_orden_act_after_update(); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION actualiza_orden_act_after_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	declare r integer;
	begin

		IF NEW.actualizacion_interna = FALSE THEN
			IF OLD.orden <> NEW.orden THEN
				r := actualiza_orden_plantillas(NEW.desglose);
			END IF;
		END IF;
		
		return NEW;
	end;
$$;


ALTER FUNCTION public.actualiza_orden_act_after_update() OWNER TO rafa;

--
-- Name: actualiza_orden_act_before_insert(); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION actualiza_orden_act_before_insert() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	declare r integer;
		rr record;
	begin
		SELECT * into rr from plantilla_de_actividad WHERE desglose = NEW.desglose AND orden = NEW.orden;

		IF FOUND THEN
			NEW.orden := dame_max_orden_act(NEW.desglose) + 1;
		END IF;
		
		return NEW;
	end;
$$;


ALTER FUNCTION public.actualiza_orden_act_before_insert() OWNER TO rafa;

--
-- Name: actualiza_orden_act_before_update(); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION actualiza_orden_act_before_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	declare r integer;
		rr record;
	begin
		IF NEW.actualizacion_interna = FALSE THEN
			IF (OLD.orden <> NEW.orden AND OLD.desglose = NEW.desglose) OR OLD.desglose <> NEW.desglose THEN
			
				SELECT * INTO rr FROM plantilla_de_actividad WHERE desglose = NEW.desglose AND orden = NEW.orden;

				IF FOUND THEN
					IF OLD.desglose = NEW.desglose THEN
						NEW.orden := OLD.orden;
					ELSE
						NEW.orden := dame_max_orden_act(NEW.desglose) + 1;
					END IF;
				END IF;
				
			END IF;
		END IF;
		
		return NEW;
	end;
$$;


ALTER FUNCTION public.actualiza_orden_act_before_update() OWNER TO rafa;

--
-- Name: actualiza_orden_actividades(); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION actualiza_orden_actividades() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	declare r integer;
	begin
		r := actualiza_orden_plantillas(NEW.desglose);
		return NEW;
	end;
$$;


ALTER FUNCTION public.actualiza_orden_actividades() OWNER TO rafa;

--
-- Name: actualiza_orden_plantillas(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION actualiza_orden_plantillas(iddesglose character varying) RETURNS integer
    LANGUAGE plpgsql
    AS $$
	declare r record;
		c bigint;
		ids varchar[];
		i bigint;
	begin
		c := dame_cant_act_desglose(iddesglose);
		ids := matrix.create_string_list(c);
		
		i := 0;

		for r in select * from plantilla_de_actividad where desglose = iddesglose order by orden loop
		  i:=i+1;
		  ids[i] := r.id;
		end loop;
		
	        i := 0;
	        loop
		  i := i + 1;
		  update plantilla_de_actividad set orden = i, actualizacion_interna = true where id = ids[i] AND orden <> i;
		  update plantilla_de_actividad set actualizacion_interna = false where id = ids[i];
		  exit when i >= c;
		end loop;
		
		return c;
	end;
$$;


ALTER FUNCTION public.actualiza_orden_plantillas(iddesglose character varying) OWNER TO rafa;

--
-- Name: actualiza_profesor_para_grupo(); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION actualiza_profesor_para_grupo() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	declare r record;
	begin

		select * into r from profesor_para_grupo where profesor_para_actividad = NEW.profesor_para_actividad and grupo = NEW.grupo;
		if not found then
			insert into profesor_para_grupo (profesor_para_actividad, grupo) VALUES (NEW.profesor_para_actividad, NEW.grupo);
		end if;
		return NEW;
	end;
$$;


ALTER FUNCTION public.actualiza_profesor_para_grupo() OWNER TO rafa;

--
-- Name: actualiza_restriccion_real(character varying, character varying, character varying, character varying, integer, integer, boolean, character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION actualiza_restriccion_real(idobjeto character varying, idactividad character varying, idnominal character varying, idperiodo character varying, pdia integer, pturno integer, por_actividad boolean, tabla_real character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE 
    rperiodicidad RECORD;
    rreal RECORD;
    rplanificacion RECORD;
    idact varchar;
    rperiodo RECORD;
    c bigint;
    
    -- campos a actualizar
    fecha bigint;
    dia_inicial bigint;
    hora_inicial double precision;
    hora_final double precision;
BEGIN   
    
    
    IF idactividad IS NULL THEN
        idact := 'NULL';
    ELSE
        idact := quote_literal(idactividad);
    END IF;  

    -- se obtienen otros datos de la restriccion nominal
    -- nota: la tabla de restricciones de periodos no es igual a las demas pero 
        -- todas contiene un campo llamado 'periodo' por lo que no hay problema
        -- en utilizarlo
    SELECT * INTO rplanificacion FROM planificacion WHERE id = dame_planificacion_de_periodo(idperiodo);
    SELECT * INTO rperiodo FROM periodo WHERE id = idperiodo;
    
    -- se calculan los demas datos de la fecha real
    dia_inicial := dame_dia_real_planificacion(rplanificacion.id, 1);
    hora_inicial := dame_hora_inicial_turno(idperiodo, pturno); 
    hora_final := hora_inicial + rperiodo.duracion_del_turno;

    -- en rnominal se tiene el registro de la restriccion nominal
    -- ahora hay que actualizar o insertar las restricciones reales correspondientes
    -- para eso se recorren todas la periodicidades de la restriccion nominal y si no se encuentra
    -- se inserta y si ya existe se actualiza
    
    FOR rperiodicidad IN SELECT * FROM periodicidad WHERE periodo = idperiodo LOOP
       
       -- se busca si existe
       EXECUTE 'SELECT * FROM ' || tabla_real || ' WHERE restriccion_nominal = ' || quote_literal(idnominal) || ' AND periodicidad = ' || quote_literal(rperiodicidad.id) || ';' INTO rreal;
       GET DIAGNOSTICS c = ROW_COUNT;
       
       fecha := dia_inicial + rperiodicidad.dia - 1 + pdia - 1;
       
       IF c > 0 THEN
            -- actualizar
            EXECUTE 'UPDATE ' || tabla_real || ' SET fecha = ' || fecha || ', hora_inicial = ' || hora_inicial || ', hora_final = ' || hora_final || ', por_actividad = ' || bool_to_str(por_actividad) || ', actividad = ' || idact || ', objeto = ' || quote_literal(idobjeto) || ' WHERE restriccion_nominal = ' || quote_literal(idnominal) || ' AND periodicidad = ' || quote_literal(rperiodicidad.id) || ';';
            
       ELSE
            -- insertar
        
           EXECUTE 'INSERT INTO ' || tabla_real || '(restriccion_nominal, periodicidad, fecha, hora_inicial, hora_final, por_actividad, actividad, objeto) VALUES (' || quote_literal(idnominal) || ',' || quote_literal(rperiodicidad.id) || ',' || fecha || ',' || hora_inicial || ',' || hora_final || ',' || bool_to_str(por_actividad) || ',' || idact || ',' || quote_literal(idobjeto) || ');';
           
       END IF;
    END LOOP;
END;
$$;


ALTER FUNCTION public.actualiza_restriccion_real(idobjeto character varying, idactividad character varying, idnominal character varying, idperiodo character varying, pdia integer, pturno integer, por_actividad boolean, tabla_real character varying) OWNER TO rafa;

--
-- Name: agrega_actividad(character varying, character varying, character varying, integer, integer, character varying, character varying[], double precision, character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION agrega_actividad(idplantilla character varying, idprofesor character varying, idlugar character varying, pdia integer, pturno integer, idgrupo character varying, idrecursos character varying[], momento double precision, pcreador character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE pid VARCHAR;
        listaidbrg VARCHAR[];
        cant BIGINT;
        i BIGINT; j INTEGER;
        rplantilla record;
        r record;
    BEGIN

        SELECT * INTO rplantilla FROM plantilla_de_actividad WHERE id = idplantilla;

        pid := crear_id_de_replica ('ancoragoh','actividad','id','actividad');
        INSERT INTO actividad (id, plantilla, profesor, lugar, dia, turno, momento_de_colocacion, creador, grupo) VALUES (pid, idplantilla, idprofesor, idlugar, pdia, pturno, momento, pcreador, idgrupo);

        cant := matrix.get_length_of(idrecursos, 1);

        IF cant > 0 THEN
		i := 1;
		LOOP
		    INSERT INTO otros_recursos_usados (otro_recurso, actividad) VALUES (idrecursos[i], pid);
		    EXIT WHEN i = cant;
		    i := i + 1;
		END LOOP;
        END IF;
    END;
$$;


ALTER FUNCTION public.agrega_actividad(idplantilla character varying, idprofesor character varying, idlugar character varying, pdia integer, pturno integer, idgrupo character varying, idrecursos character varying[], momento double precision, pcreador character varying) OWNER TO rafa;

--
-- Name: and_mpi(character varying[], integer, integer, character varying, bigint, boolean); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION and_mpi(listaidbrg character varying[], cd integer, ct integer, idplantilla character varying, zona bigint, excepto boolean) RETURNS boolean[]
    LANGUAGE plpgsql
    AS $$
    DECLARE mpi BOOLEAN[][];
        r RECORD;
        i INTEGER;
        j INTEGER;
        k INTEGER;
        cantBrg BIGINT;
        pi BOOLEAN;
        lugares VARCHAR[];
        cantLugares BIGINT;
        profesores VARCHAR[];
        cantProfes BIGINT;
        grupos VARCHAR[];
    BEGIN

	--RAISE NOTICE '     [INFO] AND MPI ...';
	
        cantBrg := matrix.get_length_of(listaidbrg, 1);

	--RAISE NOTICE '          [INFO] AND MPI: obtengo los lugares y profesores asignados a la plantilla ...';
	
        -- obtengo los lugares y profesores asignados a la plantilla 
        lugares := dame_lista_id_lugares_asignados(idplantilla);
        cantLugares := matrix.get_length_of(lugares, 1);

        profesores := dame_lista_id_profes_asignados(idplantilla);
        cantProfes := matrix.get_length_of(profesores, 1);

	--RAISE NOTICE '          [INFO] AND MPI: obtengo los grupos involucrados segun la plantilla y las brigadas ...';
        -- obtengo los grupos involucrados segun la plantilla y las brigadas
        -- generalmente debe ser uno solo

        grupos := dame_grupos_de_brigadas (listaidbrg, idplantilla);

        --RAISE NOTICE '          [INFO] AND MPI: creo la mpi ...';
        -- creo la mpi
        mpi := matrix.create_boolean_matrix(cd,ct);

	--RAISE NOTICE '          [INFO] AND MPI: inicializo la mpi con TRUE en todas las casillas ...';
        -- inicializo la mpi con TRUE en todas las casillas
        i := 1;

        LOOP
            j := 1;
            LOOP
                mpi[i][j] := TRUE;
                EXIT WHEN j = ct;
                j := j + 1;
            END LOOP;
            
            EXIT WHEN i = cd;
            i := i + 1;
        END LOOP;

        --RAISE NOTICE '          [INFO] AND MPI: recorro cada brigada comprobando la disponibilidad en cada turno ...';
        -- recorro cada brigada comprobando la disponibilidad en cada turno
        k := 1;
        LOOP
	    --RAISE NOTICE '          [INFO] AND MPI: % verifico para cada turno si es posible inicio ...', k;
            -- verifico para cada turno si es posible inicio
            i := 1;
            LOOP
                j := 1;
                LOOP
                    pi := posible_inicio(idplantilla, i, j, listaidbrg[k], lugares, profesores);

                    IF excepto = TRUE THEN
                        SELECT * INTO r FROM actividad WHERE plantilla = idplantilla AND dia = i AND turno = j;
                        IF r.plantilla = idplantilla THEN
                            pi = TRUE;
                        END IF;
                    END IF;

		    --RAISE NOTICE '          [INFO] AND MPI: %  me quedo con los lugares que tengan capacidad ...', k;
                    -- me quedo con los lugares que tengan capacidad
                    lugares := quita_segun_capacidad(listaidbrg, lugares);
                    
		    --RAISE NOTICE '          [INFO] AND MPI: %  me quedo con los lugares que no estan prohibidos ...', k;
                    -- me quedo con los lugares que no estan prohibidos

                    lugares := quita_segun_prohibidos(grupos, lugares);

                    IF matrix.get_length_of(lugares, 1) = 0 THEN
                        pi := FALSE;
                    END IF;

                    mpi[i][j] := mpi[i][j] AND pi;

                    EXIT WHEN j = ct;
                    j := j + 1;
                END LOOP;
                
                EXIT WHEN i = cd;
                i := i + 1;
            END LOOP;

            EXIT WHEN k = cantBrg;
            k := k + 1;
        END LOOP;
        
        RETURN mpi;
    END;
    
$$;


ALTER FUNCTION public.and_mpi(listaidbrg character varying[], cd integer, ct integer, idplantilla character varying, zona bigint, excepto boolean) OWNER TO rafa;

--
-- Name: arregla_prioridades_clasif(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION arregla_prioridades_clasif(pcreador character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
	declare r record;
		cla varchar[];
		c bigint;
		i bigint;
	begin
	
		FOR r IN SELECT * FROM clasificacion_de_actividad WHERE creador = pcreador ORDER BY prioridad LOOP
		    cla := array_append(cla, r.id);
		END LOOP;
       
		c := matrix.get_length_of(cla,1);
		i := 1;
		LOOP
			UPDATE clasificacion_de_actividad SET prioridad = i WHERE id = cla[i];
			EXIT WHEN i >= c;
			i := i + 1;
		END LOOP;

	end;
$$;


ALTER FUNCTION public.arregla_prioridades_clasif(pcreador character varying) OWNER TO postgres;

--
-- Name: arregla_prioridades_clasif_after_delete(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION arregla_prioridades_clasif_after_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	begin
		execute arregla_prioridades_clasif(old.creador);
		return old;
	end;
$$;


ALTER FUNCTION public.arregla_prioridades_clasif_after_delete() OWNER TO postgres;

--
-- Name: baja_orden_de_plantilla(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION baja_orden_de_plantilla(idplantilla character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
	declare r record;
		rplantilla1 record;
		rplantilla2 record;
		m integer;
		o1 integer;
		o2 integer;
		
	begin
		
		select * into rplantilla1 from plantilla_de_actividad where id = idplantilla;

		-- asegurando que este en orden las plantillas, de paso devuelve la cantidad y max
		
		m := actualiza_orden_plantillas(rplantilla1.desglose);

		
		if found then
			if rplantilla1.orden < m then

				-- obtengo la plantilla de abajo
				select * into rplantilla2 from plantilla_de_actividad where desglose = rplantilla1.desglose and orden = rplantilla1.orden + 1;

				-- hago el intercambio

				o1 := rplantilla1.orden;
				o2 := rplantilla2.orden;
				
				update plantilla_de_actividad set orden = m + 1, actualizacion_interna = true where id = rplantilla1.id;
				update plantilla_de_actividad set orden = o1, actualizacion_interna = true where id = rplantilla2.id;
				update plantilla_de_actividad set orden = o2, actualizacion_interna = true where id = rplantilla1.id;

				-- quitando actualizacion interna
				update plantilla_de_actividad set actualizacion_interna = false where id = rplantilla1.id or id = rplantilla2.id;
			end if;
			return true;
		end if;
		return false;
	end;
$$;


ALTER FUNCTION public.baja_orden_de_plantilla(idplantilla character varying) OWNER TO rafa;

--
-- Name: baja_prioridad_clasif(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION baja_prioridad_clasif(idclasif character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
	declare 
		r1 record;
		r2 record;
	begin
		SELECT * INTO r1 FROM clasificacion_de_actividad WHERE id = idclasif;

		IF r1.prioridad < dame_cant_clasif() THEN
			SELECT * INTO r2 FROM clasificacion_de_actividad WHERE creador = r1.creador AND prioridad = r1.prioridad + 1;
			UPDATE clasificacion_de_actividad SET prioridad = r1.prioridad WHERE id = r2.id;
			UPDATE clasificacion_de_actividad SET prioridad = r2.prioridad WHERE id = r1.id;
		END IF;
		
		return true;
	end;
$$;


ALTER FUNCTION public.baja_prioridad_clasif(idclasif character varying) OWNER TO postgres;

--
-- Name: bool_to_int(boolean); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION bool_to_int(valor boolean) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN 
    IF valor = TRUE THEN
        RETURN 1;
    END IF;
    RETURN 0;
END;
$$;


ALTER FUNCTION public.bool_to_int(valor boolean) OWNER TO rafa;

--
-- Name: FUNCTION bool_to_int(valor boolean); Type: COMMENT; Schema: public; Owner: rafa
--

COMMENT ON FUNCTION bool_to_int(valor boolean) IS 'Convierte un valor BOOLEAN a un entero donde 1 = TRUE y 0 = FALSE';


--
-- Name: bool_to_str(boolean); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION bool_to_str(valor boolean) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
BEGIN 
    IF valor = TRUE THEN
        RETURN 'TRUE';
    END IF;
    RETURN 'FALSE';
END;
$$;


ALTER FUNCTION public.bool_to_str(valor boolean) OWNER TO rafa;

--
-- Name: FUNCTION bool_to_str(valor boolean); Type: COMMENT; Schema: public; Owner: rafa
--

COMMENT ON FUNCTION bool_to_str(valor boolean) IS 'Convierte un valor BOOLEAN a un VARCHAR donde "TRUE" = TRUE y "FALSE" = FALSE';


--
-- Name: busca_lugar_mas_utilizado_por(character varying[], character varying, boolean); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION busca_lugar_mas_utilizado_por(lugares character varying[], idgrupo character varying, los_demas boolean) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
    DECLARE i BIGINT;
        cant BIGINT;
        m INTEGER;
        cantr INTEGER;
        pos BIGINT;
        r record;
    BEGIN
        cant := matrix.get_length_of(lugares, 1);

        m := 0;
        pos := 0;
        
        i := 1;
        LOOP
            SELECT * INTO r FROM actividad WHERE lugar = lugares[i] AND ((grupo = idgrupo AND los_demas = FALSE) OR (grupo <> idgrupo AND los_demas = TRUE)) ;

            IF NOT FOUND THEN
                cantr :=0;
            ELSE
                GET DIAGNOSTICS cantr = ROW_COUNT;
            END IF;

            IF cantr > m OR i = 1 THEN
                m := cantr;
                pos := i;
            END IF;
            
            EXIT WHEN i = cant;
            i := i + 1;
        END LOOP;

        -- al meno uno de los lugares debe ser utilizado
        IF m = 0 THEN 
            RETURN '';
        END IF;
        RETURN lugares[pos];
    END;
$$;


ALTER FUNCTION public.busca_lugar_mas_utilizado_por(lugares character varying[], idgrupo character varying, los_demas boolean) OWNER TO rafa;

--
-- Name: busca_lugar_menos_costoso(character varying[], character varying[]); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION busca_lugar_menos_costoso(origenes character varying[], destinos character varying[]) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
    DECLARE i BIGINT; j BIGINT;
        min BIGINT; pos BIGINT;
        cant_origenes BIGINT; 
        cant_destinos BIGINT;
        costo BIGINT;
        r record;
    BEGIN
        cant_origenes := matrix.get_length_of(origenes, 1);
        cant_destinos := matrix.get_length_of(destinos, 1);
    
        min := 0;
        pos := -1;
        
        i := 1;
        IF cant_origenes > 0 THEN
		LOOP
		    costo := 0;
		    j := 1;
		    IF cant_destinos > 0 THEN
			    LOOP
				SELECT * INTO r FROM costo_de_traslado WHERE origen = origenes[i] AND destino = destinos[j];
				
				costo := costo + r.costo;
				
				EXIT WHEN j >= cant_destinos;
				j := j + 1;
			    END LOOP;
		    END IF;
		    IF min > costo OR pos = -1 THEN
			min = costo;
			pos = i;
		    END IF;
		    
		    EXIT WHEN i >= cant_origenes;
		    i := i + 1;
		END LOOP;
        END IF;

        IF pos = -1 THEN
            RETURN '';
        END IF;
        
        RETURN origenes[pos];
    END;
$$;


ALTER FUNCTION public.busca_lugar_menos_costoso(origenes character varying[], destinos character varying[]) OWNER TO rafa;

--
-- Name: busca_lugar_menos_utilizado_por(character varying[], character varying, boolean); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION busca_lugar_menos_utilizado_por(lugares character varying[], idgrupo character varying, los_demas boolean) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
    DECLARE i BIGINT;
        cant BIGINT;
        m INTEGER;
        cantr INTEGER;
        pos BIGINT;
        r record;
    BEGIN
        cant := matrix.get_length_of(lugares, 1);

        m := 0;
        pos := 0;
        
        i := 1;
        
        LOOP
            SELECT * INTO r FROM actividad WHERE lugar = lugares[i] AND ((grupo = idgrupo AND los_demas = FALSE) OR (grupo <> idgrupo AND los_demas = TRUE)) ;

            IF NOT FOUND THEN
                cantr :=0;
            ELSE
                GET DIAGNOSTICS cantr = ROW_COUNT;
            END IF;

            IF cantr <m OR i = 1 THEN
                m := cantr;
                pos := i;
            END IF;
            
            EXIT WHEN i = cant;
            i := i + 1;
        END LOOP;

        -- al meno uno de los lugares debe ser utilizado
        IF m = 0 THEN 
            RETURN '';
        END IF;
        
        RETURN lugares[pos];
    END;
$$;


ALTER FUNCTION public.busca_lugar_menos_utilizado_por(lugares character varying[], idgrupo character varying, los_demas boolean) OWNER TO rafa;

--
-- Name: check_hrt(character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION check_hrt(hijo_brigada character varying, hijo_profesor character varying, hijo_lugar character varying, hijo_otro_recurso character varying, padre_brigada character varying, padre_profesor character varying, padre_lugar character varying, padre_otro_recurso character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
    DECLARE c1 INTEGER; c2 INTEGER;
        ta INTEGER; tb INTEGER;
        ida VARCHAR; idb VARCHAR;
    BEGIN
        c1 := 0;
        c1 := c1 + iif(hijo_brigada is null,0,1);      
        c1 := c1 + iif(hijo_profesor is null,0,1);
        c1 := c1 + iif(hijo_lugar is null,0,1);
        c1 := c1 + iif(hijo_otro_recurso is null,0,1);

        IF (c1 > 1 OR c1 = 0) THEN
            RETURN FALSE;
        END IF;
        
        c2 := 0;
        c2 := c2 + iif(padre_brigada is null,0,1);
        c2 := c2 + iif(padre_profesor is null,0,1);
        c2 := c2 + iif(padre_lugar is null,0,1);
        c2 := c2 + iif(padre_otro_recurso is null,0,1);

        IF (c2 > 1 OR c2 = 0) THEN
            RETURN FALSE;
        END IF;

        ta := iif(hijo_brigada is null,0,1);
        ta := iif(hijo_profesor is null,0,2);
        ta := iif(hijo_lugar is null,0,3);
        ta := iif(hijo_otro_recurso is null,0,4);

        tb := iif(padre_brigada is null,0,1);
        tb := iif(padre_profesor is null,0,2);
        tb := iif(padre_lugar is null,0,3);
        tb := iif(padre_otro_recurso is null,0,4);        

        ida := iif (ta = 1, hijo_brigada, '');
        ida := iif (ta = 2, hijo_profesor, '');
        ida := iif (ta = 3, hijo_lugar, '');
        ida := iif (ta = 4, hijo_otro_recurso, '');

        idb := iif (ta = 1, padre_brigada, '');
        idb := iif (ta = 2, padre_profesor, '');
        idb := iif (ta = 3, padre_lugar, '');
        idb := iif (ta = 4, padre_otro_recurso, '');

        IF (ida = '' OR idb = '') THEN
            RETURN FALSE;
        END IF;
        
        IF (ta = tb AND ida = idb) THEN
            RETURN FALSE;
        END IF;

        RETURN TRUE;
    END;
$$;


ALTER FUNCTION public.check_hrt(hijo_brigada character varying, hijo_profesor character varying, hijo_lugar character varying, hijo_otro_recurso character varying, padre_brigada character varying, padre_profesor character varying, padre_lugar character varying, padre_otro_recurso character varying) OWNER TO rafa;

--
-- Name: concat(text, text); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION concat(text, text) RETURNS text
    LANGUAGE sql
    AS $_$SELECT $1 || $2;$_$;


ALTER FUNCTION public.concat(text, text) OWNER TO rafa;

--
-- Name: crear_cadena_aleatoria(character varying, integer); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION crear_cadena_aleatoria(caracteres character varying DEFAULT 'abcdefghijklmnopqrstuvwxyz1234567890'::character varying, longitud integer DEFAULT 20) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
DECLARE 
    i INTEGER; 
    cadena VARCHAR; 
    posicion INTEGER;
BEGIN
    cadena := '';
    i := 1;
    LOOP
        posicion := round(1 + random() * char_length(caracteres));
        cadena := cadena || substring(caracteres from posicion FOR 1);
        EXIT WHEN i = longitud;
        i := i + 1;
    END LOOP;
    RETURN cadena;
END;
$$;


ALTER FUNCTION public.crear_cadena_aleatoria(caracteres character varying, longitud integer) OWNER TO rafa;

--
-- Name: FUNCTION crear_cadena_aleatoria(caracteres character varying, longitud integer); Type: COMMENT; Schema: public; Owner: rafa
--

COMMENT ON FUNCTION crear_cadena_aleatoria(caracteres character varying, longitud integer) IS 'Devuelve una cadena de caracteres alfanum?ricos aleatorios';


--
-- Name: crear_id_de_replica(character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION crear_id_de_replica(prefijo character varying, tabla character varying, campoid character varying, sufijo character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
DECLARE 
    id VARCHAR;
    cant INTEGER;
BEGIN

    -- mientras exista el id de replica generado genero nuevos id de replicas
    LOOP
        -- se genera el id de replica
        id := prefijo || '-' || CURRENT_TIMESTAMP || '-' || crear_cadena_aleatoria('abcdefghijklmnopqrstuvwxyz1234567890', 20) || '-' || sufijo;

        -- se consulta la tabla correspondiente para asegurarse que no exista
        EXECUTE 'SELECT * FROM ' || tabla || ' WHERE ' || campoid ||' = ' || quote_literal(id);        

        -- se obtiene la cantidad de filas encontradas seg?n la instrucci?n SELECT anterior
        GET DIAGNOSTICS cant = ROW_COUNT;

        -- si no se encontraron filas entonces el id no existe y se puede salir del ciclo
        EXIT WHEN cant = 0;            
    END LOOP;
  
    RETURN id;
END;
$$;


ALTER FUNCTION public.crear_id_de_replica(prefijo character varying, tabla character varying, campoid character varying, sufijo character varying) OWNER TO rafa;

--
-- Name: FUNCTION crear_id_de_replica(prefijo character varying, tabla character varying, campoid character varying, sufijo character varying); Type: COMMENT; Schema: public; Owner: rafa
--

COMMENT ON FUNCTION crear_id_de_replica(prefijo character varying, tabla character varying, campoid character varying, sufijo character varying) IS 'Crea una cadena de caracteres ?nica para una columna de una tabla';


--
-- Name: dame_asig_segun_esp_anno(character varying, character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_asig_segun_esp_anno(idesp character varying, idnivel character varying) RETURNS character varying[]
    LANGUAGE plpgsql
    AS $$
    DECLARE arr VARCHAR[];
        r record;
    BEGIN
        FOR r IN SELECT * FROM asignatura WHERE especialidad = idesp AND nivel = idnivel LOOP
            arr := array_append(arr, r.id);
        END LOOP;
        RETURN arr;
    END;
$$;


ALTER FUNCTION public.dame_asig_segun_esp_anno(idesp character varying, idnivel character varying) OWNER TO rafa;

--
-- Name: dame_asig_segun_esp_anno_per(character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_asig_segun_esp_anno_per(idesp character varying, idnivel character varying, idperiodo character varying) RETURNS character varying[]
    LANGUAGE plpgsql
    AS $$
    DECLARE arr VARCHAR[];
        r record;
    BEGIN
        FOR r IN SELECT * FROM asignatura WHERE especialidad = idesp AND nivel = idnivel ORDER BY dame_cant_act(asignatura.id, idperiodo) DESC LOOP
            arr := array_append(arr, r.id);
        END LOOP;
        RETURN arr;
    END;
$$;


ALTER FUNCTION public.dame_asig_segun_esp_anno_per(idesp character varying, idnivel character varying, idperiodo character varying) OWNER TO rafa;

--
-- Name: dame_asignatura_desglose(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_asignatura_desglose(character varying) RETURNS character varying
    LANGUAGE sql
    AS $_$
    SELECT asignatura FROM desglose WHERE id = $1;
$_$;


ALTER FUNCTION public.dame_asignatura_desglose(character varying) OWNER TO rafa;

--
-- Name: dame_asignatura_plantilla_de_actividad(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_asignatura_plantilla_de_actividad(id character varying) RETURNS character varying
    LANGUAGE sql
    AS $_$
    SELECT dame_asignatura_desglose(desglose) FROM plantilla_de_actividad WHERE id = $1;
$_$;


ALTER FUNCTION public.dame_asignatura_plantilla_de_actividad(id character varying) OWNER TO rafa;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: brigada; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE brigada (
    id character varying DEFAULT crear_id_de_replica('ancoragoh'::character varying, 'brigada'::character varying, 'id'::character varying, 'brigada'::character varying) NOT NULL,
    descripcion character varying NOT NULL,
    especialidad character varying NOT NULL,
    nivel character varying NOT NULL,
    matricula integer DEFAULT 0,
    creador character varying NOT NULL
);


ALTER TABLE public.brigada OWNER TO rafa;

--
-- Name: dame_brigadas_de_grupo(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_brigadas_de_grupo(idgrupo character varying) RETURNS SETOF brigada
    LANGUAGE sql
    AS $_$ 
	select brigada.* from brigada_de_grupo inner join brigada on brigada_de_grupo.brigada = brigada.id
	where brigada_de_grupo.grupo = $1;
$_$;


ALTER FUNCTION public.dame_brigadas_de_grupo(idgrupo character varying) OWNER TO rafa;

--
-- Name: dame_brigadas_sin_grupo(character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_brigadas_sin_grupo(idesp character varying, idnivel character varying, idclasif character varying, idplanificacion character varying) RETURNS SETOF character varying
    LANGUAGE plpgsql
    AS $_$
	declare r brigada%rowtype;
		r1 record;
		-- ids varchar[];
	begin
		for r in select * from brigada where especialidad = $1 and nivel = $2 loop
			select * into r1 from brigada_de_grupo where brigada = r.id and dame_clasificacion_de_grupo(grupo) = idclasif and dame_planificacion_de_grupo(grupo) = idplanificacion;
			if not found then
				return next r.id; -- ids := array_append(ids, r.id);
			end if;
		end loop;
		return; -- ids;
	end;
$_$;


ALTER FUNCTION public.dame_brigadas_sin_grupo(idesp character varying, idnivel character varying, idclasif character varying, idplanificacion character varying) OWNER TO rafa;

--
-- Name: dame_cant_accesos_prohibidos_al_grupo(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_cant_accesos_prohibidos_al_grupo(character varying) RETURNS bigint
    LANGUAGE sql
    AS $_$
    SELECT count(lugar) FROM acceso_prohibido WHERE grupo = $1;
$_$;


ALTER FUNCTION public.dame_cant_accesos_prohibidos_al_grupo(character varying) OWNER TO rafa;

--
-- Name: dame_cant_act(character varying, character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_cant_act(asig character varying, periodo character varying) RETURNS bigint
    LANGUAGE sql
    AS $_$
    SELECT count(plantilla_de_actividad.id)
    FROM asignatura 
    INNER JOIN desglose 
        ON asignatura.id = desglose.asignatura
    INNER JOIN plantilla_de_actividad 
        ON plantilla_de_actividad.desglose = desglose.id
    WHERE asignatura.id = $1 AND desglose.periodo = $2;
$_$;


ALTER FUNCTION public.dame_cant_act(asig character varying, periodo character varying) OWNER TO rafa;

--
-- Name: dame_cant_act_desglose(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_cant_act_desglose(desglose character varying) RETURNS bigint
    LANGUAGE sql
    AS $_$
    SELECT count(plantilla_de_actividad.id)
    FROM desglose 
    INNER JOIN plantilla_de_actividad 
        ON plantilla_de_actividad.desglose = desglose.id
    WHERE desglose.id = $1;
$_$;


ALTER FUNCTION public.dame_cant_act_desglose(desglose character varying) OWNER TO rafa;

--
-- Name: dame_cant_asig_de_esp_anno(character varying, character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_cant_asig_de_esp_anno(idesp character varying, idnivel character varying) RETURNS bigint
    LANGUAGE sql
    AS $_$
    SELECT count(id) FROM asignatura WHERE especialidad = $1 AND nivel = $2;
$_$;


ALTER FUNCTION public.dame_cant_asig_de_esp_anno(idesp character varying, idnivel character varying) OWNER TO rafa;

--
-- Name: dame_cant_clasif(); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_cant_clasif() RETURNS bigint
    LANGUAGE sql
    AS $$
    SELECT count(id) AS cant FROM clasificacion_de_actividad;
$$;


ALTER FUNCTION public.dame_cant_clasif() OWNER TO rafa;

--
-- Name: dame_cant_dias(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_cant_dias(idperiodo character varying) RETURNS integer
    LANGUAGE sql
    AS $_$
    SELECT cant_dias FROM periodo WHERE id = $1;
$_$;


ALTER FUNCTION public.dame_cant_dias(idperiodo character varying) OWNER TO rafa;

--
-- Name: dame_cant_grupos_de_recursos_asignados(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_cant_grupos_de_recursos_asignados(idplantilla character varying) RETURNS bigint
    LANGUAGE sql
    AS $_$
    SELECT count(id) FROM otro_grupo_de_recursos_para_actividad WHERE plantilla = $1;
$_$;


ALTER FUNCTION public.dame_cant_grupos_de_recursos_asignados(idplantilla character varying) OWNER TO rafa;

--
-- Name: dame_cant_lugares_asignados(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_cant_lugares_asignados(idplantilla character varying) RETURNS bigint
    LANGUAGE sql
    AS $_$
    SELECT count(lugar) FROM lugar_para_actividad WHERE plantilla = $1;
$_$;


ALTER FUNCTION public.dame_cant_lugares_asignados(idplantilla character varying) OWNER TO rafa;

--
-- Name: dame_cant_otros_recursos_asignados(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_cant_otros_recursos_asignados(idgrupo character varying) RETURNS bigint
    LANGUAGE sql
    AS $_$
    SELECT count(otro_recurso) FROM otro_recurso_para_actividad WHERE grupo_de_recursos = $1;
$_$;


ALTER FUNCTION public.dame_cant_otros_recursos_asignados(idgrupo character varying) OWNER TO rafa;

--
-- Name: dame_cant_otros_recursos_imprescindibles(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_cant_otros_recursos_imprescindibles(idplantilla character varying) RETURNS bigint
    LANGUAGE plpgsql
    AS $_$
	declare r record;
	begin
		SELECT sum(otro_grupo_de_recursos_para_actividad.necesarios) as s INTO r FROM otro_grupo_de_recursos_para_actividad WHERE plantilla = $1 AND imprescindibles = TRUE;
		IF NOT FOUND OR r.s IS NULL THEN
			return 0;
		END IF;
		return r.s;
	end;
$_$;


ALTER FUNCTION public.dame_cant_otros_recursos_imprescindibles(idplantilla character varying) OWNER TO rafa;

--
-- Name: dame_cant_profes_asignados(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_cant_profes_asignados(idplantilla character varying) RETURNS bigint
    LANGUAGE sql
    AS $_$
    SELECT count(id) FROM profesor_para_actividad WHERE plantilla = $1;
$_$;


ALTER FUNCTION public.dame_cant_profes_asignados(idplantilla character varying) OWNER TO rafa;

--
-- Name: dame_cant_rest_asignatura(character varying, character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_cant_rest_asignatura(idasig character varying, idperiodo character varying) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
	declare cd integer;
			ct integer;
			c bigint;
			i integer;
			j integer;
			v integer;
	begin
		cd := dame_cant_dias(idperiodo);
		ct := dame_cant_turnos(idperiodo);
		c := 0;
		i:=1;
		LOOP
			j:=1;
			LOOP
				v := valor_restriccion_asignatura(idasig, idperiodo, i,j);
				if v > 0 then
					c := c +1;
				end if;
				EXIT WHEN j>=ct;
				j:=j+1;
			END LOOP;
			EXIT WHEN i>=cd;
			i:=i+1;
		END LOOP;
		
		return c;
	end;
  
$$;


ALTER FUNCTION public.dame_cant_rest_asignatura(idasig character varying, idperiodo character varying) OWNER TO rafa;

--
-- Name: dame_cant_rest_profe(character varying, character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_cant_rest_profe(idprofe character varying, idperiodo character varying) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
	declare cd integer;
			ct integer;
			c bigint;
			i integer;
			j integer;
			v integer;
	begin
		cd := dame_cant_dias(idperiodo);
		ct := dame_cant_turnos(idperiodo);
		c := 0;
		i:=1;
		LOOP
			j:=1;
			LOOP
				v := valor_restriccion_profesor(idprofe, idperiodo, i,j);
				if v > 0 then
					c := c +1;
				end if;
				EXIT WHEN j>=ct;
				j:=j+1;
			END LOOP;
			EXIT WHEN i>=cd;
			i:=i+1;
		END LOOP;
		
		return c;
	end;
  
$$;


ALTER FUNCTION public.dame_cant_rest_profe(idprofe character varying, idperiodo character varying) OWNER TO rafa;

--
-- Name: dame_cant_turnos(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_cant_turnos(idperiodo character varying) RETURNS integer
    LANGUAGE sql
    AS $_$
    SELECT cant_turnos FROM periodo WHERE id = $1;
$_$;


ALTER FUNCTION public.dame_cant_turnos(idperiodo character varying) OWNER TO rafa;

--
-- Name: dame_capacidad(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_capacidad(lug character varying) RETURNS integer
    LANGUAGE sql
    AS $_$
    SELECT capacidad FROM lugar WHERE id = $1;
$_$;


ALTER FUNCTION public.dame_capacidad(lug character varying) OWNER TO rafa;

--
-- Name: dame_clasif_de_asignaturas(character varying, character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_clasif_de_asignaturas(asignatura character varying, periodo character varying) RETURNS character varying[]
    LANGUAGE plpgsql
    AS $$
    DECLARE arr VARCHAR[];
        r record;
    BEGIN
        FOR r IN SELECT plantilla_de_actividad.clasificacion as clasif 
             FROM plantilla_de_actividad 
             INNER JOIN desglose ON plantilla_de_actividad.desglose = desglose.id 
             WHERE desglose.periodo = periodo AND desglose.asignatura = asignatura 
             ORDER BY plantilla_de_actividad.orden LOOP
            arr := array_append(arr, r.clasif);
        END LOOP;
        RETURN arr;
    END;
$$;


ALTER FUNCTION public.dame_clasif_de_asignaturas(asignatura character varying, periodo character varying) OWNER TO rafa;

--
-- Name: dame_clasif_plantilla_de_actividad(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_clasif_plantilla_de_actividad(character varying) RETURNS character varying
    LANGUAGE sql
    AS $_$
    SELECT clasificacion FROM plantilla_de_actividad WHERE id = $1;
$_$;


ALTER FUNCTION public.dame_clasif_plantilla_de_actividad(character varying) OWNER TO rafa;

--
-- Name: dame_clasificacion_de_grupo(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_clasificacion_de_grupo(idgrupo character varying) RETURNS character varying
    LANGUAGE sql
    AS $_$
    SELECT clasificacion FROM grupo WHERE id = $1;
$_$;


ALTER FUNCTION public.dame_clasificacion_de_grupo(idgrupo character varying) OWNER TO rafa;

--
-- Name: dame_costo_trasladar_recurso(character varying, character varying, character varying, integer, integer); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_costo_trasladar_recurso(idrecurso character varying, idlugar character varying, idperiodo character varying, pdia integer, pturno integer) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
    DECLARE i BIGINT; j BIGINT;
        costo BIGINT;
        rperiodo record;
        r record;
        id VARCHAR;
    BEGIN

        SELECT * INTO rperiodo FROM periodo WHERE id = idperiodo;

        costo := 0;

        IF rperiodo.cant_turnos > 0 THEN
            
            -- busco actividad anterior
            i := pturno - 1;
            LOOP
                SELECT actividad.lugar as lugar INTO r FROM otros_recursos_usados INNER JOIN actividad ON actividad.id = otros_recursos_usados.actividad WHERE actividad.dia = pdia AND actividad.turno = i AND dame_periodo_plantilla_de_actividad(actividad.plantilla) = idperiodo AND otros_recursos_usados.otro_recurso = idrecurso;

                IF FOUND THEN
                    id := r.lugar;
                    SELECT costo INTO r FROM costo_de_traslado WHERE origen = id AND destino = idlugar;
                    IF FOUND THEN
                        costo := r.costo;
                    END IF;
                END IF;

                EXIT WHEN i = 1;
                i := i -1;
            END LOOP;

            
            -- busco actividad siguiente
            i := pturno + 1;
            LOOP
                SELECT actividad.lugar as lugar INTO r FROM otros_recursos_usados INNER JOIN actividad ON actividad.id = otros_recursos_usados.actividad WHERE actividad.dia = pdia AND actividad.turno = i AND dame_periodo_plantilla_de_actividad(actividad.plantilla) = idperiodo AND otros_recursos_usados.otro_recurso = idrecurso;

                IF FOUND THEN
                    id := r.lugar;
                    SELECT costo INTO r FROM costo_de_traslado WHERE destino = id AND origen = idlugar;
                    IF FOUND THEN
                        costo := costo + r.costo;
                    END IF;
                END IF;

                EXIT WHEN i = rperiodo.cant_turnos;
                i := i + 1;
            END LOOP;
        END IF;
        RETURN costo;
    END;
$$;


ALTER FUNCTION public.dame_costo_trasladar_recurso(idrecurso character varying, idlugar character varying, idperiodo character varying, pdia integer, pturno integer) OWNER TO rafa;

--
-- Name: dame_creador_de_asignatura(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_creador_de_asignatura(idasig character varying) RETURNS character varying
    LANGUAGE sql
    AS $_$
	select creador from asignatura where id = $1;
$_$;


ALTER FUNCTION public.dame_creador_de_asignatura(idasig character varying) OWNER TO rafa;

--
-- Name: dame_creador_de_clasifact(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_creador_de_clasifact(idclasif character varying) RETURNS character varying
    LANGUAGE sql
    AS $_$
	select creador from clasificacion_de_actividad where id = $1;
$_$;


ALTER FUNCTION public.dame_creador_de_clasifact(idclasif character varying) OWNER TO rafa;

--
-- Name: dame_creador_de_especialidad(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_creador_de_especialidad(esp character varying) RETURNS character varying
    LANGUAGE sql
    AS $_$
	select creador from especialidad where id = $1;
$_$;


ALTER FUNCTION public.dame_creador_de_especialidad(esp character varying) OWNER TO rafa;

--
-- Name: dame_creador_de_planificacion(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_creador_de_planificacion(id character varying) RETURNS character varying
    LANGUAGE sql
    AS $_$
    SELECT creador FROM planificacion WHERE id = $1;
$_$;


ALTER FUNCTION public.dame_creador_de_planificacion(id character varying) OWNER TO rafa;

--
-- Name: dame_creador_de_plantilla(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_creador_de_plantilla(idplantilla character varying) RETURNS character varying
    LANGUAGE sql
    AS $_$
	select dame_creador_de_asignatura(dame_asignatura_desglose(dame_desglose_de_plantilla($1)));
$_$;


ALTER FUNCTION public.dame_creador_de_plantilla(idplantilla character varying) OWNER TO rafa;

--
-- Name: dame_desglose_de_plantilla(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_desglose_de_plantilla(idplantilla character varying) RETURNS character varying
    LANGUAGE sql
    AS $_$
    SELECT desglose FROM plantilla_de_actividad WHERE id = $1;
$_$;


ALTER FUNCTION public.dame_desglose_de_plantilla(idplantilla character varying) OWNER TO rafa;

--
-- Name: dame_dia_real_planificacion(character varying, integer); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_dia_real_planificacion(pid character varying, dia integer) RETURNS bigint
    LANGUAGE sql
    AS $_$
    SELECT fecha_inicial + $2 - 1  FROM planificacion WHERE id = $1;
$_$;


ALTER FUNCTION public.dame_dia_real_planificacion(pid character varying, dia integer) OWNER TO rafa;

--
-- Name: dame_duracion_actividad(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_duracion_actividad(id character varying) RETURNS integer
    LANGUAGE sql
    AS $_$
        SELECT dame_duracion_plantilla_de_actividad(plantilla) from actividad where id =$1
    $_$;


ALTER FUNCTION public.dame_duracion_actividad(id character varying) OWNER TO rafa;

--
-- Name: dame_duracion_clasif_de_actividad(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_duracion_clasif_de_actividad(character varying) RETURNS integer
    LANGUAGE sql
    AS $_$
    SELECT duracion FROM clasificacion_de_actividad WHERE id = $1;
$_$;


ALTER FUNCTION public.dame_duracion_clasif_de_actividad(character varying) OWNER TO rafa;

--
-- Name: dame_duracion_plantilla_de_actividad(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_duracion_plantilla_de_actividad(character varying) RETURNS integer
    LANGUAGE sql
    AS $_$
    SELECT dame_duracion_clasif_de_actividad(clasificacion) FROM plantilla_de_actividad WHERE id = $1;
$_$;


ALTER FUNCTION public.dame_duracion_plantilla_de_actividad(character varying) OWNER TO rafa;

--
-- Name: dame_duracion_turno_periodo(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_duracion_turno_periodo(pid character varying) RETURNS double precision
    LANGUAGE sql
    AS $_$
        SELECT duracion_del_turno FROM periodo WHERE id = $1;
    $_$;


ALTER FUNCTION public.dame_duracion_turno_periodo(pid character varying) OWNER TO rafa;

--
-- Name: dame_especialidad_de_asignatura(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_especialidad_de_asignatura(idasig character varying) RETURNS character varying
    LANGUAGE sql
    AS $_$
    SELECT especialidad FROM asignatura WHERE id = $1;
$_$;


ALTER FUNCTION public.dame_especialidad_de_asignatura(idasig character varying) OWNER TO rafa;

--
-- Name: dame_especialidad_de_brigada(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_especialidad_de_brigada(idbrigada character varying) RETURNS character varying
    LANGUAGE sql
    AS $_$
    SELECT especialidad FROM brigada WHERE id = $1;
$_$;


ALTER FUNCTION public.dame_especialidad_de_brigada(idbrigada character varying) OWNER TO rafa;

--
-- Name: dame_especialidad_de_grupo(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_especialidad_de_grupo(idgrupo character varying) RETURNS character varying
    LANGUAGE sql
    AS $_$
	select especialidad from grupo where id = $1;
$_$;


ALTER FUNCTION public.dame_especialidad_de_grupo(idgrupo character varying) OWNER TO rafa;

--
-- Name: dame_gasto_de_plantilla(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_gasto_de_plantilla(idplantilla character varying) RETURNS integer
    LANGUAGE sql
    AS $_$
    SELECT gasto FROM clasificacion_de_actividad WHERE id = dame_clasif_plantilla_de_actividad($1);
$_$;


ALTER FUNCTION public.dame_gasto_de_plantilla(idplantilla character varying) OWNER TO rafa;

--
-- Name: dame_gasto_lugares_en_el_dia(character varying[], character varying, integer); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_gasto_lugares_en_el_dia(lugares character varying[], periodo character varying, pdia integer) RETURNS bigint[]
    LANGUAGE plpgsql
    AS $$
    DECLARE
        arr BIGINT[];
        u BIGINT;
        i BIGINT;
        cant BIGINT;
    BEGIN
        cant := matrix.get_length_of(lugares, 1);

        arr := matrix.create_numeric_list(cant);
        
        i := 1;
        LOOP            
            SELECT * FROM actividad WHERE dia = pdia AND lugar = lugares[i] AND dame_periodo_de_plantilla(plantilla) = periodo GROUP BY lugar;

            IF NOT FOUND THEN
                u:=0;
            ELSE
                GET DIAGNOSTICS u := ROW_COUNT;
            END IF;

            arr[i] := u;
            
            EXIT WHEN i = cant;
            i:= i + 1;
        END LOOP;
    
        RETURN arr;
    END;
$$;


ALTER FUNCTION public.dame_gasto_lugares_en_el_dia(lugares character varying[], periodo character varying, pdia integer) OWNER TO rafa;

--
-- Name: dame_grupo(character varying, character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_grupo(brg character varying, clasif character varying) RETURNS character varying
    LANGUAGE sql
    AS $_$
    SELECT grupo FROM brigada_de_grupo WHERE brigada = $1 AND dame_clasificacion_de_grupo(grupo) = $2;
$_$;


ALTER FUNCTION public.dame_grupo(brg character varying, clasif character varying) OWNER TO rafa;

--
-- Name: dame_grupos(character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_grupos(idesp character varying, idnivel character varying, idclasif character varying) RETURNS character varying[]
    LANGUAGE plpgsql
    AS $$
    DECLARE arr VARCHAR[];
        r RECORD;
    BEGIN
        FOR r IN SELECT grupo FROM brigada_de_grupo WHERE dame_especialidad_de_brigada(brigada) = idesp AND dame_nivel_de_brigada(brigada) = idnivel AND dame_clasificacion_de_grupo(grupo) = idclasif GROUP BY grupo LOOP
            arr := array_append(arr,r.grupo);
        END LOOP;
        RETURN arr;
    END;
    
$$;


ALTER FUNCTION public.dame_grupos(idesp character varying, idnivel character varying, idclasif character varying) OWNER TO rafa;

--
-- Name: dame_grupos_de_brigadas(character varying[], character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_grupos_de_brigadas(brigadas character varying[], idplantilla character varying) RETURNS character varying[]
    LANGUAGE plpgsql
    AS $$
    DECLARE arr VARCHAR[];
        cantBrg BIGINT;
        i BIGINT;
        g VARCHAR;
        clasif VARCHAR;
    BEGIN 
        cantBrg := matrix.get_length_of(brigadas,1);
        clasif := dame_clasif_plantilla_de_actividad(idplantilla);

        i := 1;
        LOOP
            g := dame_grupo(brigadas[i], clasif);

            IF g IS NOT NULL THEN
                IF matrix.get_pos_of(arr, g) <> -1 THEN
                    arr := array_append(arr, g);
                END IF;
            END IF;
            EXIT WHEN i = cantBrg;
            i := i + 1;
        END LOOP;
        RETURN arr;
    END;
$$;


ALTER FUNCTION public.dame_grupos_de_brigadas(brigadas character varying[], idplantilla character varying) OWNER TO rafa;

--
-- Name: grupo; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE grupo (
    id character varying NOT NULL,
    clasificacion character varying NOT NULL,
    descripcion character varying NOT NULL,
    especialidad character varying NOT NULL,
    nivel character varying NOT NULL,
    planificacion character varying NOT NULL
);


ALTER TABLE public.grupo OWNER TO rafa;

--
-- Name: dame_grupos_de_plantilla(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_grupos_de_plantilla(idplantilla character varying) RETURNS SETOF grupo
    LANGUAGE plpgsql
    AS $$
	declare r record;
		asig varchar;
	begin
		asig := dame_asignatura_plantilla_de_actividad(idplantilla);
		
		for r in select * from grupo 
			where clasificacion = dame_clasif_plantilla_de_actividad(idplantilla)
			and planificacion = dame_planificacion_de_periodo(dame_periodo_plantilla_de_actividad(idplantilla))
			and especialidad = dame_especialidad_de_asignatura(asig)
			and nivel = dame_nivel_de_asignatura(asig) loop

			return next r;
		end loop;
		
		return;
	end;
$$;


ALTER FUNCTION public.dame_grupos_de_plantilla(idplantilla character varying) OWNER TO rafa;

--
-- Name: dame_hora_inicial_turno(character varying, integer); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_hora_inicial_turno(idperiodo character varying, pturno integer) RETURNS double precision
    LANGUAGE plpgsql
    AS $$
    DECLARE r record;
        h DOUBLE PRECISION;
    BEGIN
        SELECT * into r from periodo where id = idperiodo;
        h := r.hora_inicial + (pturno - 1) * r.duracion_del_turno;

        FOR r IN SELECT * from receso where periodo = idperiodo and despues_del_turno < pturno LOOP
            h := h + r.duracion;
        END LOOP;
        
        RETURN h;

    END;
$$;


ALTER FUNCTION public.dame_hora_inicial_turno(idperiodo character varying, pturno integer) OWNER TO rafa;

--
-- Name: dame_id_plantilla(character varying, character varying, bigint); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_id_plantilla(idasig character varying, idperiodo character varying, orden bigint) RETURNS character varying
    LANGUAGE sql
    AS $_$
    SELECT plantilla_de_actividad.id FROM plantilla_de_actividad INNER JOIN desglose ON plantilla_de_actividad.desglose = desglose.id WHERE desglose.asignatura = $1 AND desglose.periodo = $2 AND plantilla_de_actividad.orden = $3;
$_$;


ALTER FUNCTION public.dame_id_plantilla(idasig character varying, idperiodo character varying, orden bigint) OWNER TO rafa;

--
-- Name: dame_idobjeto_de_restriccion_de_brigada(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_idobjeto_de_restriccion_de_brigada(pid character varying) RETURNS character varying
    LANGUAGE sql
    AS $_$
            SELECT brigada FROM restriccion_de_brigada WHERE id = $1;
       $_$;


ALTER FUNCTION public.dame_idobjeto_de_restriccion_de_brigada(pid character varying) OWNER TO rafa;

--
-- Name: dame_idobjeto_de_restriccion_de_especialidad(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_idobjeto_de_restriccion_de_especialidad(pid character varying) RETURNS character varying
    LANGUAGE sql
    AS $_$
            SELECT especialidad FROM restriccion_de_especialidad WHERE id = $1;
       $_$;


ALTER FUNCTION public.dame_idobjeto_de_restriccion_de_especialidad(pid character varying) OWNER TO rafa;

--
-- Name: dame_idobjeto_de_restriccion_de_periodo(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_idobjeto_de_restriccion_de_periodo(pid character varying) RETURNS character varying
    LANGUAGE sql
    AS $_$
            SELECT periodo FROM restriccion_de_periodo WHERE id = $1;
       $_$;


ALTER FUNCTION public.dame_idobjeto_de_restriccion_de_periodo(pid character varying) OWNER TO rafa;

--
-- Name: dame_lista_id_brigadas_de_esp(character varying, character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_lista_id_brigadas_de_esp(esp character varying, niv character varying) RETURNS character varying[]
    LANGUAGE plpgsql
    AS $$
    DECLARE arr VARCHAR[];
        r record;
    BEGIN
        FOR r IN SELECT * FROM brigada WHERE especialidad = esp AND nivel = niv LOOP
            arr := array_append(arr,r.id);
        END LOOP;

        RETURN arr;
    END;
$$;


ALTER FUNCTION public.dame_lista_id_brigadas_de_esp(esp character varying, niv character varying) OWNER TO rafa;

--
-- Name: dame_lista_id_brigadas_de_grupo(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_lista_id_brigadas_de_grupo(pgrupo character varying) RETURNS character varying[]
    LANGUAGE plpgsql
    AS $$
    DECLARE arr VARCHAR[];
        r RECORD;
    BEGIN
        FOR r IN SELECT brigada FROM brigada_de_grupo WHERE grupo = pgrupo LOOP
            arr := array_append(arr,r.brigada);
        END LOOP;
        RETURN arr;
    END;
    
$$;


ALTER FUNCTION public.dame_lista_id_brigadas_de_grupo(pgrupo character varying) OWNER TO rafa;

--
-- Name: dame_lista_id_clasif(); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_lista_id_clasif() RETURNS character varying[]
    LANGUAGE plpgsql
    AS $$
    DECLARE arr VARCHAR[];
        r record;
    BEGIN
        FOR r IN SELECT * FROM clasificacion_de_actividad ORDER BY prioridad LOOP
            arr := array_append(arr, r.id);
        END LOOP;
        RETURN arr;
    END;
$$;


ALTER FUNCTION public.dame_lista_id_clasif() OWNER TO rafa;

--
-- Name: dame_lista_id_grupos_de_recursos_asignados(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_lista_id_grupos_de_recursos_asignados(idplantilla character varying) RETURNS character varying[]
    LANGUAGE plpgsql
    AS $$
    DECLARE arr VARCHAR[];
        r record;
    BEGIN
        FOR r IN SELECT * FROM otro_grupo_de_recursos_para_actividad WHERE plantilla = idplantilla LOOP
            arr := array_append(arr,r.id);
        END LOOP;

        RETURN arr;
    END;
$$;


ALTER FUNCTION public.dame_lista_id_grupos_de_recursos_asignados(idplantilla character varying) OWNER TO rafa;

--
-- Name: dame_lista_id_lugares_asignados(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_lista_id_lugares_asignados(idplantilla character varying) RETURNS character varying[]
    LANGUAGE plpgsql
    AS $$
    DECLARE arr VARCHAR[];
        r record;
    BEGIN
        FOR r IN SELECT * FROM lugar_para_actividad WHERE plantilla = idplantilla LOOP
            arr := array_append(arr,r.lugar);
        END LOOP;

        RETURN arr;
    END;
$$;


ALTER FUNCTION public.dame_lista_id_lugares_asignados(idplantilla character varying) OWNER TO rafa;

--
-- Name: dame_lista_id_otros_recursos_asignados(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_lista_id_otros_recursos_asignados(idgrupo character varying) RETURNS character varying[]
    LANGUAGE plpgsql
    AS $$
    DECLARE arr VARCHAR[];
        r record;
    BEGIN
        FOR r IN SELECT * FROM otro_recurso_para_actividad WHERE grupo_de_recursos = idgrupo LOOP
            arr := array_append(arr,r.otro_recurso);
        END LOOP;

        RETURN arr;
    END;
$$;


ALTER FUNCTION public.dame_lista_id_otros_recursos_asignados(idgrupo character varying) OWNER TO rafa;

--
-- Name: dame_lista_id_otros_recursos_usados(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dame_lista_id_otros_recursos_usados(idactividad character varying) RETURNS character varying[]
    LANGUAGE plpgsql
    AS $$
    DECLARE arr VARCHAR[];
        r record;
    BEGIN
        FOR r IN SELECT * FROM otros_recursos_usados WHERE actividad = idactividad = idgrupo LOOP
            arr := array_append(arr,r.otro_recurso);
        END LOOP;

        RETURN arr;
    END;
$$;


ALTER FUNCTION public.dame_lista_id_otros_recursos_usados(idactividad character varying) OWNER TO postgres;

--
-- Name: dame_lista_id_profes_asignados(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_lista_id_profes_asignados(idplantilla character varying) RETURNS character varying[]
    LANGUAGE plpgsql
    AS $$
    DECLARE arr VARCHAR[];
        r record;
    BEGIN
        FOR r IN SELECT * FROM profesor_para_actividad WHERE plantilla = idplantilla LOOP
            arr := array_append(arr,r.profesor);
        END LOOP;

        RETURN arr;
    END;
$$;


ALTER FUNCTION public.dame_lista_id_profes_asignados(idplantilla character varying) OWNER TO rafa;

--
-- Name: dame_lista_id_profes_asignados_al_grupo(character varying, character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_lista_id_profes_asignados_al_grupo(idplantilla character varying, idgrupo character varying) RETURNS character varying[]
    LANGUAGE plpgsql
    AS $$
    DECLARE arr VARCHAR[];
        r record;
    BEGIN
        FOR r IN SELECT * FROM profesor_para_actividad 
		WHERE plantilla = idplantilla AND EXISTS(SELECT * FROM profesor_para_grupo 
							  WHERE profesor_para_grupo.profesor_para_actividad = profesor_para_actividad.id 
							  AND profesor_para_grupo.grupo = idgrupo) ORDER BY prioridad 
	LOOP
            arr := array_append(arr,r.profesor);
        END LOOP;

        RETURN arr;
    END;
$$;


ALTER FUNCTION public.dame_lista_id_profes_asignados_al_grupo(idplantilla character varying, idgrupo character varying) OWNER TO rafa;

--
-- Name: lugar; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE lugar (
    id character varying DEFAULT crear_id_de_replica('ancoragoh'::character varying, 'lugar'::character varying, 'id'::character varying, 'lugar'::character varying) NOT NULL,
    nombre character varying,
    capacidad integer DEFAULT 0,
    creador character varying NOT NULL
);


ALTER TABLE public.lugar OWNER TO rafa;

--
-- Name: dame_lugares_no_asignados_a(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_lugares_no_asignados_a(idplantilla character varying) RETURNS SETOF lugar
    LANGUAGE plpgsql
    AS $$
	declare pcreador varchar;
		r record;
		rr record;
	begin
		pcreador := dame_creador_de_plantilla(idplantilla);

		for r in select * from lugar where creador = pcreador loop
			select * into rr from lugar_para_actividad where plantilla = idplantilla and lugar = r.id;
			if not found then
				return next r;
			end if;
		end loop;

		return;
		
	end;
$$;


ALTER FUNCTION public.dame_lugares_no_asignados_a(idplantilla character varying) OWNER TO rafa;

--
-- Name: dame_lugares_usados_alrededor_de(character varying[], character varying, integer, integer); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_lugares_usados_alrededor_de(brigadas character varying[], idperiodo character varying, pdia integer, pturno integer) RETURNS character varying[]
    LANGUAGE plpgsql
    AS $$
    DECLARE arr VARCHAR[];
        cantbrg BIGINT;
        i BIGINT;
        j INTEGER;
        rperiodo record;
        r record;
    BEGIN
        SELECT * INTO rperiodo FROM periodo WHERE id = idperiodo;
        
        cantbrg := matrix.get_length_of(brigadas,1);

        i := 0;
        LOOP
            -- buscando el anterior
            j := pturno - 1;
            IF j > 0 THEN
		    LOOP
			SELECT * INTO r FROM actividad WHERE idperiodo = dame_periodo_plantilla_de_actividad(plantilla) AND dia = pdia AND turno = j AND grupo = dame_grupo(brigadas[i], dame_clasif_plantilla_de_actividad(plantilla));

			IF FOUND THEN
			    arr := array_append(arr, r.lugar);
			    EXIT;
			END IF;
			
			EXIT WHEN j <= 1;
			j :=j - 1;
		    END LOOP;
	    END IF;
            -- buscando el siguiente
            j := pturno + 1;
            IF j <= rperiodo.cant_turnos THEN
		    LOOP
			SELECT * INTO r FROM actividad WHERE idperiodo = dame_periodo_plantilla_de_actividad(plantilla) AND dia = pdia AND turno = j AND grupo = dame_grupo(brigadas[i], dame_clasif_plantilla_de_actividad(plantilla));

			IF FOUND THEN
			    arr := array_append(arr, r.lugar);
			    EXIT;
			END IF;
			
			EXIT WHEN j >= rperiodo.cant_turnos;
			j := j + 1;
		    END LOOP;
            END IF;
            
            EXIT WHEN i = cantbrg;
            i := i + 1;
        END LOOP;
        
        RETURN arr;
    END;
$$;


ALTER FUNCTION public.dame_lugares_usados_alrededor_de(brigadas character varying[], idperiodo character varying, pdia integer, pturno integer) OWNER TO rafa;

--
-- Name: dame_lugares_utilizados_en_el_dia(character varying, character varying, integer); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_lugares_utilizados_en_el_dia(pgrupo character varying, periodo character varying, pdia integer) RETURNS character varying[]
    LANGUAGE plpgsql
    AS $$
    DECLARE
        arr VARCHAR[];
        r record;
        
    BEGIN
        FOR r IN SELECT * FROM actividades WHERE grupo = pgrupo AND dia = pdia AND dame_periodo_de_plantilla(plantilla) = periodo LOOP
            arr := array_append (arr,r.lugar);
        END LOOP;
        
        RETURN arr;
    END;
$$;


ALTER FUNCTION public.dame_lugares_utilizados_en_el_dia(pgrupo character varying, periodo character varying, pdia integer) OWNER TO rafa;

--
-- Name: dame_matricula(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_matricula(brg character varying) RETURNS integer
    LANGUAGE sql
    AS $_$
    SELECT matricula FROM brigada WHERE id = $1;
$_$;


ALTER FUNCTION public.dame_matricula(brg character varying) OWNER TO rafa;

--
-- Name: dame_matricula_total(character varying[]); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_matricula_total(brigadas character varying[]) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
    DECLARE i BIGINT;
        total BIGINT;
        cantBrg BIGINT;
    BEGIN
        
        total := 0;
        cantBrg := matrix.get_length_of(brigadas, 1);

        i := 1;
        LOOP
            total := total + dame_matricula(brigadas[i]);
            EXIT WHEN i = cantBrg;
            i := i+ 1;
        END LOOP;

        RETURN total;
    END;
$$;


ALTER FUNCTION public.dame_matricula_total(brigadas character varying[]) OWNER TO rafa;

--
-- Name: dame_max_orden_act(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_max_orden_act(iddesglose character varying) RETURNS integer
    LANGUAGE sql
    AS $_$ 
	select max(orden) from plantilla_de_actividad where desglose = $1;
$_$;


ALTER FUNCTION public.dame_max_orden_act(iddesglose character varying) OWNER TO rafa;

--
-- Name: dame_max_priori_clasif_act(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_max_priori_clasif_act(pcreador character varying) RETURNS integer
    LANGUAGE plpgsql
    AS $$
    DECLARE r record;
    BEGIN
        
        SELECT max(prioridad) as m into r FROM clasificacion_de_actividad WHERE creador='admin-superuser' GROUP BY creador;

        IF r.m is null THEN
            RETURN 1;
        END IF;
        
        RETURN r.m;
    END;
$$;


ALTER FUNCTION public.dame_max_priori_clasif_act(pcreador character varying) OWNER TO rafa;

--
-- Name: dame_max_priori_otro_recurso(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dame_max_priori_otro_recurso(idgr character varying) RETURNS integer
    LANGUAGE sql
    AS $_$
	select max(prioridad) from otro_recurso_para_actividad where grupo_de_recursos = $1;
$_$;


ALTER FUNCTION public.dame_max_priori_otro_recurso(idgr character varying) OWNER TO postgres;

--
-- Name: dame_max_prioridad_de_pxact(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_max_prioridad_de_pxact(idplantilla character varying) RETURNS integer
    LANGUAGE sql
    AS $_$
	select max(prioridad) from profesor_para_actividad where plantilla = $1;
$_$;


ALTER FUNCTION public.dame_max_prioridad_de_pxact(idplantilla character varying) OWNER TO rafa;

--
-- Name: dame_max_prioridad_lxact(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_max_prioridad_lxact(idplantilla character varying) RETURNS integer
    LANGUAGE sql
    AS $_$
	select max(prioridad) from lugar_para_actividad where plantilla = $1;
$_$;


ALTER FUNCTION public.dame_max_prioridad_lxact(idplantilla character varying) OWNER TO rafa;

--
-- Name: dame_max_prioridad_rxact(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_max_prioridad_rxact(idplantilla character varying) RETURNS integer
    LANGUAGE sql
    AS $_$
	select max(prioridad) from otro_grupo_de_recursos_para_actividad where plantilla = $1;
$_$;


ALTER FUNCTION public.dame_max_prioridad_rxact(idplantilla character varying) OWNER TO rafa;

--
-- Name: dame_nivel_de_asignatura(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_nivel_de_asignatura(idasig character varying) RETURNS character varying
    LANGUAGE sql
    AS $_$
    SELECT nivel FROM asignatura WHERE id = $1;
$_$;


ALTER FUNCTION public.dame_nivel_de_asignatura(idasig character varying) OWNER TO rafa;

--
-- Name: dame_nivel_de_brigada(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_nivel_de_brigada(idbrigada character varying) RETURNS character varying
    LANGUAGE sql
    AS $_$
    SELECT nivel FROM brigada WHERE id = $1;
$_$;


ALTER FUNCTION public.dame_nivel_de_brigada(idbrigada character varying) OWNER TO rafa;

--
-- Name: dame_nivel_de_grupo(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_nivel_de_grupo(idgrupo character varying) RETURNS character varying
    LANGUAGE sql
    AS $_$
	select nivel from grupo where id = $1;
$_$;


ALTER FUNCTION public.dame_nivel_de_grupo(idgrupo character varying) OWNER TO rafa;

--
-- Name: otro_recurso; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE otro_recurso (
    id character varying DEFAULT crear_id_de_replica('ancoragoh'::character varying, 'otro_recurso'::character varying, 'id'::character varying, 'otro_recurso'::character varying) NOT NULL,
    nombre character varying,
    creador character varying NOT NULL
);


ALTER TABLE public.otro_recurso OWNER TO rafa;

--
-- Name: dame_otros_recursos_sin_asignar(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dame_otros_recursos_sin_asignar(idplantilla character varying) RETURNS SETOF otro_recurso
    LANGUAGE plpgsql
    AS $_$ 
	declare r record;
	begin

	for r in select * from otro_recurso where esta_otro_recurso_asignado(id, $1) = false loop
		return next r;
	end loop;
	end;
$_$;


ALTER FUNCTION public.dame_otros_recursos_sin_asignar(idplantilla character varying) OWNER TO postgres;

--
-- Name: dame_periodo_desglose(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_periodo_desglose(character varying) RETURNS character varying
    LANGUAGE sql
    AS $_$
    SELECT periodo FROM desglose WHERE id = $1;
$_$;


ALTER FUNCTION public.dame_periodo_desglose(character varying) OWNER TO rafa;

--
-- Name: dame_periodo_plantilla_de_actividad(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_periodo_plantilla_de_actividad(character varying) RETURNS character varying
    LANGUAGE sql
    AS $_$
    SELECT dame_periodo_desglose(desglose) FROM plantilla_de_actividad WHERE id = $1;
$_$;


ALTER FUNCTION public.dame_periodo_plantilla_de_actividad(character varying) OWNER TO rafa;

--
-- Name: dame_planificacion_de_grupo(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_planificacion_de_grupo(idgrupo character varying) RETURNS character varying
    LANGUAGE sql
    AS $_$
	select planificacion from grupo where id = $1;
$_$;


ALTER FUNCTION public.dame_planificacion_de_grupo(idgrupo character varying) OWNER TO rafa;

--
-- Name: dame_planificacion_de_periodo(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_planificacion_de_periodo(pid character varying) RETURNS character varying
    LANGUAGE sql
    AS $_$
    SELECT planificacion FROM periodo WHERE id = $1;
$_$;


ALTER FUNCTION public.dame_planificacion_de_periodo(pid character varying) OWNER TO rafa;

--
-- Name: dame_plantilla_de_grupo_de_recursos(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dame_plantilla_de_grupo_de_recursos(idgrupo character varying) RETURNS character varying
    LANGUAGE sql
    AS $_$
	select plantilla from otro_grupo_de_recursos_para_actividad where id = $1;
$_$;


ALTER FUNCTION public.dame_plantilla_de_grupo_de_recursos(idgrupo character varying) OWNER TO postgres;

--
-- Name: dame_profesores_no_asignados_a(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_profesores_no_asignados_a(idplantilla character varying) RETURNS SETOF character varying
    LANGUAGE plpgsql
    AS $$
	declare pcreador varchar;
		r record;
		rr record;
	begin
		pcreador := dame_creador_de_plantilla(idplantilla);

		for r in select * from profesor where creador = pcreador order by nombre loop
			select * into rr from profesor_para_actividad where plantilla = idplantilla and profesor = r.id;
			if not found then
				return next r.id;
			end if;
		end loop;

		return;
		
	end;
$$;


ALTER FUNCTION public.dame_profesores_no_asignados_a(idplantilla character varying) OWNER TO rafa;

--
-- Name: dame_tipo_consec_rest_cond(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_tipo_consec_rest_cond(pid character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
    DECLARE t VARCHAR;
        r record;
    BEGIN
        SELECT * INTO r FROM restriccion_condicional WHERE id = pid;
        
        t := iif(r.hijo_brigada is null,'','BRIGADA');
        t := iif(r.hijo_profesor is null,'','PROFESOR');
        t := iif(r.hijo_lugar is null,'','LUGAR');
        t := iif(r.hijo_otro_recurso is null,'','OTRORECURSO');
        
        RETURN t;

    END;
$$;


ALTER FUNCTION public.dame_tipo_consec_rest_cond(pid character varying) OWNER TO rafa;

--
-- Name: dame_tipo_hijo_hrt(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_tipo_hijo_hrt(pid character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
    DECLARE t VARCHAR;
        r record;
    BEGIN
        SELECT * INTO r FROM herencia_de_restricciones WHERE id = pid;
        
        t := iif(r.hijo_brigada is null,'','BRIGADA');
        t := iif(r.hijo_profesor is null,'','PROFESOR');
        t := iif(r.hijo_lugar is null,'','LUGAR');
        t := iif(r.hijo_otro_recurso is null,'','OTRORECURSO');
        
        RETURN t;

    END;
$$;


ALTER FUNCTION public.dame_tipo_hijo_hrt(pid character varying) OWNER TO rafa;

--
-- Name: dame_tipo_padre_hrt(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_tipo_padre_hrt(pid character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
    DECLARE t VARCHAR;
    r record;
    BEGIN
        SELECT * INTO r FROM herencia_de_restricciones WHERE id = pid;

        t := iif(r.padre_brigada is null,'','BRIGADA');
        t := iif(r.padre_profesor is null,'','PROFESOR');
        t := iif(r.padre_lugar is null,'','LUGAR');
        t := iif(r.padre_otro_recurso is null,'','OTRORECURSO');
        
        RETURN t;

    END;
$$;


ALTER FUNCTION public.dame_tipo_padre_hrt(pid character varying) OWNER TO rafa;

--
-- Name: dame_total_otros_recursos_asignados(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_total_otros_recursos_asignados(idplantilla character varying) RETURNS numeric
    LANGUAGE plpgsql
    AS $_$
	declare r record;
	begin
		 SELECT sum(dame_cant_otros_recursos_asignados(id)) as s INTO r FROM otro_grupo_de_recursos_para_actividad WHERE plantilla = $1;
		IF NOT FOUND OR r.s IS NULL THEN
			return 0;
		END IF;
		return r.s;
	end;
$_$;


ALTER FUNCTION public.dame_total_otros_recursos_asignados(idplantilla character varying) OWNER TO rafa;

--
-- Name: dame_uso_de_otro_recurso(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_uso_de_otro_recurso(id character varying) RETURNS bigint
    LANGUAGE sql
    AS $_$
    SELECT count(actividad) FROM otros_recursos_usados WHERE otro_recurso = $1
$_$;


ALTER FUNCTION public.dame_uso_de_otro_recurso(id character varying) OWNER TO rafa;

--
-- Name: dame_zpriori(character varying, character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dame_zpriori(clasif character varying, idperiodo character varying) RETURNS integer[]
    LANGUAGE plpgsql
    AS $$
    DECLARE zp INTEGER[][];
        i BIGINT; j BIGINT;
        CD INTEGER; CT INTEGER;
        r record;
    BEGIN 
        
        CD := dame_cant_dias(idperiodo);
        CT := dame_cant_turnos(idperiodo);
        
        zp := matrix.create_numeric_matrix(CD,CT);

	i:= 1;
	LOOP
		j:=1;
		LOOP
			zp[i][j] := 1;
			EXIT WHEN j = CT;
			j:=j+1;
		END LOOP;
		EXIT WHEN i = CD;
		i := i + 1;
	END LOOP;
    
        FOR r IN SELECT * FROM zpriori WHERE clasificacion = clasif AND periodo = idperiodo LOOP
            zp[r.dia][r.turno] := r.valor;
        END LOOP;
        
        RETURN zp;
    END;
$$;


ALTER FUNCTION public.dame_zpriori(clasif character varying, idperiodo character varying) OWNER TO rafa;

--
-- Name: dia_minimo_impacto(character varying, character varying, character varying, character varying, integer, integer); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dia_minimo_impacto(idclasif character varying, idesp character varying, idnivel character varying, idperiodo character varying, dia_ini integer, dia_fin integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
    DECLARE
        i BIGINT; j BIGINT; k BIGINT; l BIGINT; ll BIGINT; dia INTEGER;
        max BIGINT;
        cant BIGINT;
        r record;
        CD INTEGER;
        CT INTEGER;
        rperiodo RECORD;
        cantBrg BIGINT;
        maxzpriori INTEGER;
        zp INTEGER[][];
        impactodiario INTEGER[];
        min bigint;
        impacto bigint;
    BEGIN
 
        zp := dame_zpriori(idclasif, idperiodo);

        SELECT * INTO r FROM zpriori WHERE clasificacion = idclasif AND periodo = idperiodo ORDER BY valor DESC;

        maxzpriori := r.valor;
            
        SELECT * INTO rperiodo FROM periodo WHERE id = idperiodo;

        CD := rperiodo.cant_dias;
        CT := rperiodo.cant_turnos;
        
        SELECT count(id) as c INTO r FROM brigada WHERE especialidad = idesp AND nivel = idnivel;

        cantBrg := r.c;

        i := dia_ini;
        LOOP
            j := 1;
            LOOP
                zp[i][j] := maxzpriori - zp[i][j];
                EXIT WHEN j = CT;
                j := j + 1;
            END LOOP;
            
            EXIT WHEN i = dia_fin;
            i := i + 1;
        END LOOP;


        -- En los turnos restringidos el impacto es cero tanto para el grupoXClasif en curso
        -- como para los dem?
        -- Poniendo cero seg??estricciones de la clasificacion de actividad
        FOR r IN SELECT * FROM restriccion_de_clasif_act WHERE clasificacion = idclasif AND periodo = idperiodo LOOP
            IF r.valor > 0 THEN 
                zp[r.dia][r.turno] := 0;
            END IF;
        END LOOP;
    
        -- Poniendo cero seg??estricciones de las brigadas
        FOR r IN SELECT * FROM restriccion_de_brigada WHERE dame_especialidad_de_brigada(brigada) = idesp AND dame_nivel_de_brigada(brigada) = idnivel LOOP
            IF r.valor > 0 THEN 
                zp[r.dia][r.turno] := 0;
            END IF;
        END LOOP;

        -- Poniendo cero seg??estricciones del periodo
        FOR r IN SELECT * FROM restriccion_de_periodo WHERE periodo = idperiodo LOOP
            IF r.valor > 0 THEN 
                zp[r.dia][r.turno] := 0;
            END IF;
        END LOOP;

        -- calculando impacto diario y minimizando
        
        i := dia_ini;
        min := -1;
        dia := 0;
        LOOP
            impacto := 0;
            j := 1;
            LOOP
                impacto := impacto + zp[i][j];
                EXIT WHEN j = CT;
                j := j + 1;
            END LOOP;

            -- puede que haya otros minimos, pero me quedo con el primero porque est?as cerca
            -- del origen del periodo (recordar que se colocan actividades por nivel)
            
            IF min = -1 OR min > impacto THEN
                min := impacto;
                dia := i;
            END IF;
            
            EXIT WHEN i = dia_fin;
            i := i + 1;
        END LOOP;

        RETURN dia;
    END;
$$;


ALTER FUNCTION public.dia_minimo_impacto(idclasif character varying, idesp character varying, idnivel character varying, idperiodo character varying, dia_ini integer, dia_fin integer) OWNER TO rafa;

--
-- Name: dias_se_solapan(character varying, integer, character varying, integer); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION dias_se_solapan(idperiodo1 character varying, dia1 integer, idperiodo2 character varying, dia2 integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
        DECLARE r1 record;
            r2 record;
            dia1 BIGINT;
            dia2 BIGINT;
            planificacion1 VARCHAR;
            planificacion2 VARCHAR;
            dia_real1 BIGINT;
            dia_real2 BIGINT;

        BEGIN
            planificacion1 := dame_planificacion_de_periodo(idperiodo1);
            planificacion2 := dame_planificacion_de_periodo(idperiodo2);
            dia_real1 := dame_dia_real_planificacion(planificacion1,1);
            dia_real2 := dame_dia_real_planificacion(planificacion2,1);

            -- recorro cada periodicidad del segundo por cada periodicidad del primero
            FOR r1 IN SELECT * FROM periodicidad WHERE periodo = idperiodo1 LOOP
                dia1 := dia_real1 + r1.dia - 1;
                FOR r2 IN SELECT * FROM periodicidad WHERE periodo = idperiodo2 LOOP
                    dia2 := dia_real2 + r2.dia - 1;    
                    IF dia1 = dia2 THEN
                        RETURN TRUE;
                    END IF;
                END LOOP;
            END LOOP;

            RETURN FALSE;
        END;
    $$;


ALTER FUNCTION public.dias_se_solapan(idperiodo1 character varying, dia1 integer, idperiodo2 character varying, dia2 integer) OWNER TO rafa;

--
-- Name: es_higienico_brigada(character varying, character varying, integer); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION es_higienico_brigada(idbrigada character varying, idplantilla character varying, pdia integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
    DECLARE r record;
        r1 record;
        h record;
        idperiodo VARCHAR;
        rclasif VARCHAR;
        gasto INTEGER;
    BEGIN
        idperiodo := dame_periodo_plantilla_de_actividad(idplantilla);
        gasto := dame_gasto_de_plantilla(idplantilla);

        FOR r1 IN SELECT * FROM actividad WHERE dame_periodo_plantilla_de_actividad(plantilla) = idperiodo AND dia = pdia AND matrix.get_pos_of(dame_lista_id_brigadas_de_grupo(grupo), idbrigada) > -1 LOOP
            gasto := gasto + dame_gasto_de_plantilla(idplantilla);            
        END LOOP;

        SELECT * INTO h FROM higiene_para_brigada WHERE periodo = idperiodo and brigada = idbrigada;

        IF FOUND THEN
            IF h.gasto_maximo_diario < gasto THEN
                RETURN FALSE;
            END IF;
        END IF;
        
        RETURN TRUE;
    END;
$$;


ALTER FUNCTION public.es_higienico_brigada(idbrigada character varying, idplantilla character varying, pdia integer) OWNER TO rafa;

--
-- Name: es_higienico_profesor(character varying, character varying, integer); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION es_higienico_profesor(idprofesor character varying, idplantilla character varying, pdia integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
    DECLARE r record;
        r1 record;
        h record;
        idperiodo VARCHAR;
        rclasif VARCHAR;
        gasto INTEGER;
    BEGIN
        idperiodo := dame_periodo_plantilla_de_actividad(idplantilla);
        gasto := dame_gasto_de_plantilla(idplantilla);

        FOR r1 IN SELECT * FROM actividad WHERE dame_periodo_plantilla_de_actividad(plantilla) = idperiodo AND dia = pdia AND profesor = idprofesor LOOP
            gasto := gasto + dame_gasto_de_plantilla(idplantilla);            
        END LOOP;

        SELECT * INTO h FROM higiene_para_profesor WHERE periodo = idperiodo and profesor = idprofesor;

        IF FOUND THEN
            IF h.gasto_maximo_diario < gasto THEN
                RETURN FALSE;
            END IF;
        END IF;
        
        RETURN TRUE;
    END;
$$;


ALTER FUNCTION public.es_higienico_profesor(idprofesor character varying, idplantilla character varying, pdia integer) OWNER TO rafa;

--
-- Name: es_lugar_prohibido(character varying, character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION es_lugar_prohibido(pgrupo character varying, plugar character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
    DECLARE r record;
    BEGIN
        SELECT * INTO r FROM acceso_prohibido WHERE grupo = pgrupo AND lugar = plugar;
        IF r.grupo = pgrupo THEN
            RETURN TRUE;
        END IF;
        RETURN FALSE;
    END;
$$;


ALTER FUNCTION public.es_lugar_prohibido(pgrupo character varying, plugar character varying) OWNER TO rafa;

--
-- Name: esta_dia_en_rango_planificacion(integer, character varying, integer, integer); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION esta_dia_en_rango_planificacion(pdia integer, idperiodo character varying, dia_ini integer, dia_fin integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
    DECLARE r record;
    BEGIN
        SELECT * into r from periodicidad where periodo = idperiodo and (dia+pdia >=dia_ini AND dia+pdia<=dia_fin);
        IF FOUND THEN
            RETURN TRUE;
        END IF;
        
        RETURN FALSE;
    END;
$$;


ALTER FUNCTION public.esta_dia_en_rango_planificacion(pdia integer, idperiodo character varying, dia_ini integer, dia_fin integer) OWNER TO rafa;

--
-- Name: esta_otro_recurso_asignado(character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION esta_otro_recurso_asignado(idrecurso character varying, idplantilla character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
	declare r record;
	begin
		select * into r from otro_recurso_para_actividad 
		where dame_plantilla_de_grupo_de_recursos(grupo_de_recursos) = idplantilla
		and otro_recurso = idrecurso;

		if found then
			return true;
		end if;

		return false;
	end;
$$;


ALTER FUNCTION public.esta_otro_recurso_asignado(idrecurso character varying, idplantilla character varying) OWNER TO postgres;

--
-- Name: existe_grupo_de_profesor(character varying, character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION existe_grupo_de_profesor(profe_para_act character varying, pgrupo character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
    DECLARE r record;
    BEGIN
        SELECT * INTO r FROM profesor_para_grupo WHERE profesor_para_actividad = profe_para_act AND grupo = pgrupo;    
        IF r.grupo = pgrupo THEN
            RETURN TRUE;
        END IF;
        RETURN FALSE;
    END;
$$;


ALTER FUNCTION public.existe_grupo_de_profesor(profe_para_act character varying, pgrupo character varying) OWNER TO rafa;

--
-- Name: extraer_lugares_que_no_permanecen(character varying[], character varying, integer, integer, integer); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION extraer_lugares_que_no_permanecen(lugares character varying[], periodo character varying, dia integer, turno integer, duracion integer) RETURNS character varying[]
    LANGUAGE plpgsql
    AS $$
    DECLARE
        arr VARCHAR[];
        cant BIGINT;
        i BIGINT;
        
    BEGIN
        cant := matrix.get_length_Of(lugares,1);
        
        i := 1;
        LOOP
            IF lugar_permanece_en(lugares[i],periodo,dia,turno,duracion) THEN
                arr := array_append(arr, lugares[i]);
            END IF;
            EXIT WHEN i >= cant;
            i := i + 1;
        END LOOP;
        RETURN arr;
    END;
$$;


ALTER FUNCTION public.extraer_lugares_que_no_permanecen(lugares character varying[], periodo character varying, dia integer, turno integer, duracion integer) OWNER TO rafa;

--
-- Name: first(anyelement, anyelement); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION first(anyelement, anyelement) RETURNS anyelement
    LANGUAGE sql
    AS $_$SELECT COALESCE($1, $2);$_$;


ALTER FUNCTION public.first(anyelement, anyelement) OWNER TO rafa;

--
-- Name: generar(character varying, character varying, character varying, bigint, boolean, bigint, boolean, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION generar(idesp character varying, idnivel character varying, idperiodo character varying, forma bigint, parche boolean, compactar bigint, parche1 boolean, buscalugar boolean) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
	v integer;
	ddia integer;
	tturno integer;
	dduracion integer;

	sePudoColocar boolean;
        cantAsigEnCurso INTEGER;
        cantActEnCurso INTEGER;
        cantCriterios INTEGER;
        cantMaxAct INTEGER;
        matrixAct VARCHAR[][];
        plantillasEnCurso VARCHAR[];
        asigEnCurso VARCHAR[];
        cantActs BIGINT[];
        temp VARCHAR[];
        idprofe VARCHAR;
        
        kk INTEGER;
        idxOrdenAct BIGINT[];

        -- contadores
        i BIGINT;
        j BIGINT;
        k INTEGER;
        l BIGINT;
        ll BIGINT;
        r RECORD;
        dia INTEGER;
        turno INTEGER;
        
        voyact BIGINT;
        cantCiclo1 BIGINT;
        cantCiclo2 BIGINT;
        varCiclo1 BIGINT;
        varCiclo2 BIGINT;
        listaid_clasif VARCHAR[];
        cantClasif BIGINT;
        nivel_actual BIGINT;
        clasif_actual BIGINT;
        TablaPrioriza NUMERIC[][];
        cantPriorizando BIGINT;
        CD INTEGER;
        CT INTEGER;

        -- parametros
        profesAsignados VARCHAR[];
        lugaresAsignados VARCHAR[];
        param_cantProfesAsignados BIGINT;
        param_cantLugaresAsignados BIGINT;
        param_cantRestProfe BIGINT;
        param_cantRestLugar BIGINT;
        idxAsigEnPriori BIGINT[];
        param_cantActAsig BIGINT;
        param_cantRestAsig BIGINT;
        param_cantRecursosImprescindibles BIGINT;
        param_cantRecursosAsignados BIGINT;
        niveles NUMERIC[][];
        criterios BOOLEAN[];

        -- colocando actividad
        grupos VARCHAR[];
        cantGrupos BIGINT;
        faltan BIGINT;
        rasignatura record;
        rdesglose record;
        rplantilla record;
        rperiodo record;
        rclasificacion record;
        ztodo INTEGER;
        fatan INTEGER;
        gruposEnCurso BOOLEAN[][][];
        listaidbrg VARCHAR[];
        grupompi BOOLEAN[][];
        idMaxPIGrupo BIGINT[][];
        maxColoca BIGINT;
        diaBooleano BOOLEAN[];
        posibXDia BIGINT[];

        ya BOOLEAN[];
        zp INTEGER[][];

        -- para la optimizacion profesor
        actual_profe VARCHAR[];
        actual_profe_cant BIGINT[][];
        actual_profe_priori BIGINT[][];
        actual_profe_grupos BIGINT[][];
        actual_profe_cgrupos BIGINT[];
        
        -- cada profesor tiene un rango posible de colocacion de la actividad distinto
        -- para cada grupoXclasif
        
        actual_profe_rango INTEGER[][][]; -- profe i, grupo j, actual_profe[i][j][1] = ini actual_profe[i][j][2] = fin
        actual_profe_misact BOOLEAN[][][];

        miDiaSegunProfe INTEGER[];
        
        g BIGINT;
        min INTEGER;
        gmin BIGINT;
        c INTEGER;
        tt INTEGER;
        xasig BOOLEAN[];

        cantActualProfe BIGINT;

        rangobusqueda TRango;

        temp_rango TRango;
        grupos_rangos INTEGER[][];
        actual_profe_gastos INTEGER[];

        idClasifSgte VARCHAR;
        dia_anterior INTEGER;
        esta_colocada BOOLEAN;

        sentido INTEGER;
        ini_sentido INTEGER;
        fin_sentido INTEGER;
        step_sentido INTEGER;
        zona INTEGER;

        etapa INTEGER;
        maxDia INTEGER;
        CicloIni INTEGER;
        CicloFin INTEGER;
        
        puedo BOOLEAN;
        t INTEGER;

        idlugar varchar;
        pos BIGINT;
        lugs VARCHAR[];
        
        lugs_priori BIGINT[];
        cantLugs BIGINT;
        lgi VARCHAR;
        
        grupo_anterior BIGINT;

        mejor_profe BIGINT;
        minim BIGINT;

        dias_buenos_profe INTEGER[];
        -- brgsEnCurso VARCHAR[];
        -- cantBrgsEnCurso BIGINT;

        lugares VARCHAR[];
        cantLugares BIGINT;
        maxpriori BIGINT;

        lugsarround VARCHAR[];
        idrecursos VARCHAR[];
        gruporecursos VARCHAR[];
        cantGrupoRecursos BIGINT;
        gr BIGINT;
        rgruporecurso record;

        cantListaIdBrg BIGINT;

    ih INTEGER;
    es_higienico_profe BOOLEAN;
    es_higienico_brg BOOLEAN;
	
    BEGIN

        cantCriterios := 9;
        cantActEnCurso := 0;

	RAISE NOTICE '[INFO] Comenzando...';
	
        -- brgsEnCurso := dame_lista_id_brigadas_de_esp(idesp, idnivel);
        -- cantBrgsEnCurso := matrix.get_length_of(brgsEnCurso);
                
        -- aqui se obtienen los ids de las asignaturas implicadas en la generacion
        -- ordenadas segun la cantidad de actividades que tienen en el periodo
        -- especificado "idperiodo"

        RAISE NOTICE '[INFO] Obteniendo listado de asignaturas implicadas...';
        
        asigEnCurso := dame_asig_segun_esp_anno_per(idesp, idnivel, idperiodo);

        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------

        cantAsigEnCurso := matrix.get_length_of(asigEnCurso,1 );
        
        CD := dame_cant_dias(idperiodo);
        CT := dame_cant_turnos(idperiodo);
        
        SELECT * INTO rperiodo FROM periodo WHERE id = idperiodo;
        CD := rperiodo.cant_dias;
        CT := rperiodo.cant_turnos;

        cantMaxAct := max_cant_act(idesp, idnivel, idperiodo);
        matrixAct := matrix.create_string_matrix(cantAsigEnCurso, cantMaxAct);


        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------

        RAISE NOTICE '[INFO] Preparando matrix de actividades ...';
        -- preparando la matrix de actividades
        i := 1;
        LOOP
            j := 1;
            
            k := dame_cant_act(asigEnCurso[i],idperiodo);

            cantActs[i] := k;
            
            cantActEnCurso := cantActEnCurso + k;

            temp := dame_clasif_de_asignaturas(asigEnCurso[i],idperiodo);
            LOOP
                matrixAct[i][j] := temp[j];
                EXIT WHEN j = cantActs[i];
                j := j + 1;
            END LOOP;
            EXIT WHEN i = cantAsigEnCurso;
            i := i + 1;
        END LOOP;
        
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------
        
	RAISE NOTICE '[INFO] Cantidad de actividades en curso % ...', cantActEnCurso;
        -- hasta este momento se ha obtenido lo siguiente

        /*
         i  asigEnCurso[i]  cantActs[i]  matrixAct[i]
         -----------------------------------------
         1  matematica      3            {"conf","conf","cp"}
         2  fisica          2            {"conf","cp"}
         3  ingles          1            {"conf"} 
        */
        
        voyact := 0;

        listaid_clasif := dame_lista_id_clasif();
        cantClasif := matrix.get_length_of(listaid_clasif, 1);
        
        IF forma = 1 THEN
            cantCiclo2 := cantMaxAct;
            cantCiclo1 := cantClasif;
        ELSE
            cantCiclo1 := cantMaxAct;
            cantCiclo2 := cantClasif;        
        END IF;


        RAISE NOTICE '[INFO] Generando ...';
        -- !!! GENERANDO !!!


        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------    

        LOOP
            varCiclo1 := 0;
            LOOP
		varCiclo1 := varCiclo1 + 1;
		EXIT WHEN varCiclo1 > cantCiclo1;
		
                varCiclo2 :=0;
                LOOP
		    varCiclo2 := varCiclo2 + 1;
		    EXIT WHEN varCiclo2 > cantCiclo2;
		    
                    IF forma = 1 THEN
                         nivel_actual := varCiclo2;
                        clasif_actual := varCiclo1;
                    ELSE
                         nivel_actual := varCiclo1;
                        clasif_actual := varCiclo2;    
                    END IF;


		    RAISE NOTICE '[INFO] Calculando cantidad de actividades a priorizar ...';
                    -- calcular la cantidad de actividades a priorizar

        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------
        
                    cantPriorizando :=0;
                    i := 1;
                    plantillasEnCurso := '{}'::VARCHAR[];
                    idxAsigEnPriori := '{}'::BIGINT[];
                    LOOP
                        IF matrixAct[i][nivel_actual] = listaid_clasif[clasif_actual] THEN
                            cantPriorizando := cantPriorizando + 1;
                            plantillasEnCurso := array_append(plantillasEnCurso,dame_id_plantilla(asigEnCurso[i], idperiodo, nivel_actual));
                            idxAsigEnPriori := array_append(idxAsigEnPriori,i);
                        END IF;
                        EXIT WHEN i = cantAsigEnCurso;
                        i := i + 1;
                    END LOOP;

		    RAISE NOTICE '[INFO] Llenando la tabla prioriza con % actividades...', cantPriorizando;
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------
		    CONTINUE WHEN cantPriorizando = 0;
		    
                    -- Llenando la tabla prioriza
                    TablaPrioriza := matrix.create_numeric_matrix(cantPriorizando, 9);

                    i := 1;
                    LOOP
                        -- Cantidad de profesores asignados
                        param_cantProfesAsignados := dame_cant_profes_asignados(plantillasEnCurso[i]);
                        
                        -- Cantidad de restricciones de los profesores asignados
                        profesAsignados := dame_lista_id_profes_asignados(plantillasEnCurso[i]);
                        param_cantRestProfe := 0;
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------
                        j := 0;
                        LOOP
                            EXIT WHEN j = param_cantProfesAsignados;
                            param_cantRestProfe := param_cantRestProfe + dame_cant_rest_profe(profesAsignados[j], idperiodo);
                            j := j + 1;
                        END LOOP;

                        -- Cantiad de lugares asignados
                        param_cantLugaresAsignados := dame_cant_lugares_asignados(plantillasEnCurso[i]);

                        -- Cantidad de restricciones de los profesores asignados
                        lugaresAsignados := dame_lista_id_lugares_asignados(plantillasEnCurso[i]);
                        param_cantRestLugar := 0;
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------
                        j := 0;
                        LOOP
                            EXIT WHEN j = param_cantLugaresAsignados;
                            param_cantRestLugar := param_cantRestLugar + dame_cant_rest_profe(lugaresAsignados[j], idperiodo);
                            j := j + 1;
                        END LOOP;

                        -- Cantidad de actividades de la asignatura
                        param_cantActAsig := cantActs[idxAsigEnPriori[i]];
                        
                        -- Cantidad de otros recursos imprescindibles
                        param_cantRecursosImprescindibles := dame_cant_otros_recursos_imprescindibles(plantillasEnCurso[i]);
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------                        
                        -- Cantidad de otros recursos asignados
                        param_cantRecursosAsignados := dame_total_otros_recursos_asignados(plantillasEnCurso[i]);
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------                        
                        -- Cantidad de restricciones de la asignatura
                        param_cantRestAsig := dame_cant_rest_asignatura(asigEnCurso[idxAsigEnPriori[i]], idperiodo);

                        -- Rellenando la tabla
                        
                        TablaPrioriza[i][1] := param_cantProfesAsignados;          
                        TablaPrioriza[i][2] := param_cantRestProfe;
                        TablaPrioriza[i][3] := param_cantLugaresAsignados;
                        TablaPrioriza[i][4] := param_cantRestLugar;
                        TablaPrioriza[i][5] := param_cantActAsig;
                        TablaPrioriza[i][6] := param_cantRecursosImprescindibles;
                        TablaPrioriza[i][7] := param_cantRecursosAsignados;
                        TablaPrioriza[i][8] := param_cantRestAsig;
                        TablaPrioriza[i][9] := 0;
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------
			RAISE NOTICE '% - % % % % % % % % - %',i,TablaPrioriza[i][1],TablaPrioriza[i][2],TablaPrioriza[i][3],TablaPrioriza[i][4],TablaPrioriza[i][5],TablaPrioriza[i][6],TablaPrioriza[i][7],TablaPrioriza[i][8],TablaPrioriza[i][9];
                        EXIT WHEN i = cantPriorizando;
                        i := i + 1;
                    END LOOP;

		    RAISE NOTICE '[INFO] Tabla obtenida:';
		    EXECUTE matrix.echo(TablaPrioriza);
		    RAISE NOTICE '[INFO] Priorizando actividad a colocar ...';	
		    	

        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------		    
                    -- Priorizando la actividad a colocar
                    criterios := '{t,f,t,f,f,f,t,f}'::BOOLEAN[];
                    niveles:= prioriza.nivelar_matrix(TablaPrioriza, criterios);

		    RAISE NOTICE '[INFO] Calculando totales horizontales ...';	
		    
                    -- calculando totales horizontales
                    -- nota: los totales se colocan en la ??ma columna de la TablaPrioriza
                    i := 1;
                    LOOP
                        k := 0; -- va a llevar la suma
                        j := 1;
                        LOOP
                            k := k + niveles[i][j];
                            EXIT WHEN j=8;
                            j := j + 1;
                        END LOOP;
                        -- La ??ma columna puede variar si se agregan nuevos par?tros
                        TablaPrioriza[i][9] := k;
                        EXIT WHEN i = cantPriorizando;
                        i := i + 1;
                    END LOOP;
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------                    
                    -- Determino el orden de prioridad para colocar las actividades que entraron en juego
                    -- El orden se determina seg??os totales horizontales calculados, de menor a mayor

                    -- Inicializo el arreglo que va a tener el orden
                    
                    idxOrdenAct := '{}'::INTEGER[];

		    RAISE NOTICE '[INFO] Ordenando totales horizontales ...';
                    -- Al principio idxOrdenAct[i] = i
                    i := 1;
                    LOOP
                        idxOrdenAct := array_append(idxOrdenAct,i);
                        EXIT WHEN i = cantPriorizando;
                        i := i + 1;
                    END LOOP;

                    -- Ordeno la novena columna
                    i := 1;
                    LOOP
                        EXIT WHEN i = cantPriorizando;

                        j := i + 1;

                        LOOP
                            IF TablaPrioriza[idxOrdenAct[i]][9] > TablaPrioriza[idxOrdenAct[j]][9] THEN
                                -- Intercambio
                                                               k := TablaPrioriza[idxOrdenAct[j]][9];
                                TablaPrioriza[idxOrdenAct[j]][9] := TablaPrioriza[idxOrdenAct[i]][9];
                                TablaPrioriza[idxOrdenAct[i]][9] := k;

                                             k := idxOrdenAct[j];
                                idxOrdenAct[j] := idxOrdenAct[i];
                                idxOrdenAct[i] := k;
                            END IF;
                            
                            EXIT WHEN j = cantPriorizando;
                            j := j + 1;
                        END LOOP;
                        
                        i := i + 1;
                    END LOOP;
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------
		    RAISE NOTICE '[INFO] Determinando clasificacion siguiente ...';

                    -- Determinando la clasificacion de actividad siguiente
                    
                    idClasifSgte := '';

                    i := clasif_actual + 1;
                    LOOP
                        EXIT WHEN i > cantClasif;
                        
                        j :=1;
                        LOOP
                            IF matrixAct[j][nivel_actual] = listaid_clasif[i] THEN
                                idClasifSgte := listaid_clasif[i];
                                i := cantclasif;
                                EXIT;
                            END IF;
                            EXIT WHEN j = cantAsigEnCurso;
                            j := j + 1;
                        END LOOP;
                        
                        i := i + 1;
                    END LOOP;
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------
                    RAISE NOTICE '[INFO] Colocando actividad ...';
                    -- -------------------------------------------
                    -- Colocando la actividad 

                    SELECT * INTO rclasificacion FROM clasificacion_de_actividad WHERE id = listaid_clasif[clasif_actual];
                    SELECT valor INTO r FROM zpriori WHERE clasificacion = listaid_clasif[clasif_actual] AND periodo = idperiodo ORDER By valor DESC LIMIT 1 OFFSET 0;

		    ztodo := r.valor;
            
                    posibXDia := matrix.create_numeric_list(CD);

		    RAISE NOTICE '      [INFO] obteniendo zpriori ...';
		    
                    zp := dame_zpriori(rclasificacion.id, idperiodo);

                    IF ztodo IS NULL THEN
                        ztodo := 1;
                    END IF;

        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------		    
                    i := 1;
                                        
                    LOOP   

			RAISE NOTICE '      [INFO] colocando actividad i = % ',i;

			
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------                        
                        SELECT * INTO rplantilla FROM plantilla_de_actividad WHERE id = plantillasEnCurso[idxOrdenAct[i]];
                        SELECT * INTO rdesglose FROM desglose WHERE id = rplantilla.desglose;
                        SELECT * INTO rasignatura FROM asignatura WHERE id = rdesglose.asignatura;


			maxDia := CD -((cantActs[i] - nivel_actual) - compactar) * IIf(rdesglose.respetar_orden, 1, 0);

                        sentido := 2;
                        dia_anterior := 0;

                        grupos := dame_grupos(idesp, idnivel, rplantilla.clasificacion);
                        
                        cantGrupos := matrix.get_length_of(grupos,1);

                        idMaxPIGrupo := matrix.create_numeric_matrix(cantGrupos,CD);
                        
                        faltan := cantGrupos;

                        gruposEnCurso := matrix.create_boolean_cube(cantGrupos, CD, CT);

                        j := 1;
                        LOOP
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------                        
			    RAISE NOTICE '      [INFO] colocando por grupo j = % ',j;

			    RAISE NOTICE '      [INFO] obteniendo listaidbrg';
                            listaidbrg := dame_lista_id_brigadas_de_grupo(grupos[j]);

			    RAISE NOTICE '      [INFO] obteniendo grupompi';
                            grupompi := and_mpi(listaidbrg,CD,CT,rplantilla.id,0,TRUE);

			    RAISE NOTICE '      [INFO] obteniendo gruposEnCurso';
                            gruposEnCurso := matrix.set_matrix_in_cube(grupompi, j);

                            RAISE NOTICE '      [INFO] and mpi a grupompi';
                            grupompi := and_mpi(listaidbrg,CD,CT,rplantilla.id,0,FALSE);

			    RAISE NOTICE '      [INFO] calculando idmaxpigrupo';

                            k := 1;

                            LOOP
				--RAISE NOTICE '      [INFO] calculando idmaxpigrupo CD = % k = %', CD, k;
				--RAISE NOTICE '            obteniendo dia booleano';
                                diaBooleano := matrix.extract_boolean_column(grupompi, k);
                                --RAISE NOTICE '            obteniendo maxColoca';
                                --RAISE NOTICE '            	diaBooleano = ';

                                --execute matrix.echo(diaBooleano);
                                
                                maxColoca := get_max_colocation(diaBooleano, rclasificacion.duracion);

                                --RAISE NOTICE '            maxColoca = %', maxColoca;

                                idMaxPIGrupo[j][k] := maxColoca;

                                IF posibXDia[k] > maxColoca or k = 1 THEN
                                    posibXDia[k] = maxColoca;
                                END IF;
                                
                                EXIT WHEN k = CD;
                                k := k + 1;
                            END LOOP;
                            
                            EXIT WHEN j = cantGrupos;
                            j := j + 1;
                        END LOOP;
                        
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------
			RAISE NOTICE '       [INFO] calculo de los posibles turnos optimos en zonapriori ...';
                        -- calculo de los posibles turnos optimos en zonapriori

                        IF parche1 = TRUE THEN
				RAISE NOTICE '       [INFO] busco los turnos optimos de los grupos por dias ...';
                            -- busco los turnos optimos de los grupos por dias

                            j := 1;
                            LOOP
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------                            
				RAISE NOTICE '       [INFO] calculo las posibilidades para todos los grupos ...';
                                -- calculo las posibilidades para todos los grupos

                                -- busco el m?mo
                                ya := matrix.create_boolean_list(cantGrupos);

                                k := 1;
                                LOOP
                                    
                                    l := 1;
                                    LOOP
                                        min := CT + 1;
                                        gmin := 0;

					RAISE NOTICE '       [INFO] busco el grupo con el minimo de posibilidades optimas (en zpriori = 1) ...';
                                        -- busco el grupo con el minimo de posibilidades optimas (en zpriori = 1)

                                        g := 1;
                                        LOOP
                                            c := 0;
                                            IF ya[g] = FALSE THEN

                                                t:=1;
                                                LOOP 
                                                    IF gruposEnCurso[g][j][t] = TRUE and zp[j][t] = 1 THEN
                                                        c := c + 1;
                                                    END IF;
                                                    
                                                    EXIT WHEN t = CT;
                                                    t := t + 1;
                                                END LOOP;

                                                IF min > c THEN
                                                    min := c;
                                                    gmin := g;
                                                END IF;
                                            END IF;
                                            
                                            EXIT WHEN g = cantGrupos;
                                            g := g + 1;
                                        END LOOP;
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------
					RAISE NOTICE '       [INFO] busco la primera posibilidad para el grupo encontrado ...';
                                        -- busco la primera posibilidad para el grupo encontrado

                                        t := 1;
                                        LOOP 
                                            IF gruposEnCurso[gmin][j][t] = TRUE and zp[j][t] = 1 THEN
                                                idMaxPIGrupo[gmin][j] := t;
                                                ya[gmin] = TRUE;

                                                -- deshabilito para todos los grupos, el tiempo ocupado por el grupo encontrado
                                                -- para que los dem?turnos ??mos no se solapen con los encontrados
                                                g := 1;
                                                LOOP
                                                    tt := 1;
                                                    LOOP

                                                        gruposEnCurso[g][t + tt - 1] = FALSE;
                                                        
                                                        EXIT WHEN tt = rclasificacion.duracion;
                                                        tt := tt + 1;
                                                    END LOOP;
                                                    
                                                    EXIT WHEN g = cantGrupos;
                                                    g := g + 1;
                                                END LOOP;
                                                
                                                t := CT;
                                            END IF;

                                            EXIT WHEN t = CT;
                                            t := t + 1;
                                        END LOOP;
                                        
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------
                                        EXIT WHEN l = cantGrupos;
                                        l := l + 1;
                                    END LOOP;


                                    EXIT WHEN k = cantGrupos;
                                    k := k + 1;
                                END LOOP;
                                
                                EXIT WHEN j = CD;
                                j := j + 1;
                            END LOOP;
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------
			    RAISE NOTICE '       [INFO] actualizo posibXDias ...';
                            -- actualizo posibXDias
                            
                            j := 1;
                            LOOP
                                posibXDia[j] := 0;

                                g := 1;
                                
                                LOOP
                                    IF idMaxPIGrupo[g][j] <> 0 THEN
                                        posibXDia[j] := posibXDia[j] + 1;
                                    END IF;
                                    
                                    EXIT WHEN g = cantGrupos;
                                    g := g + 1;
                                END LOOP;
                                
                                EXIT WHEN j = CD;
                                j := j + 1;
                            END LOOP;

                        END IF;

                        xasig := matrix.create_boolean_list(CT);

			RAISE NOTICE '       [INFO] empieza la colocacion ...';
                        -- empieza la colocacion                      
                        grupo_anterior := 0; -- verificar que el grupo_anterior puede ser el mismo que j

                        
                        
                        j := 1;
                        LOOP
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------
			    sePudoColocar := false;

			    RAISE NOTICE '[INFO] Asig: %,%', rasignatura.descripcion, rasignatura.id;
			    RAISE NOTICE '[INFO] Clasif: %,%', rclasificacion.descripcion, rclasificacion.id;
			    RAISE NOTICE '[INFO] Colocando plantilla %', rplantilla.id;
			    
			    RAISE NOTICE '[INFO] Colocando grupo %: %',j,grupos[j];
			    
                            listaidbrg := dame_lista_id_brigadas_de_grupo(grupos[j]);

                            cantListaIdBrg := matrix.get_length_of(listaidbrg, 1);
                            
                            grupompi := and_mpi(listaidbrg,CD,CT,rplantilla.id,0,FALSE);

			    RAISE NOTICE ' grupompi = ';
                            execute matrix.echo(grupompi);

			    RAISE NOTICE '       [INFO] calculo el rango de busqueda ...';
                            -- calculo el rango de busqueda
                            
                            rangobusqueda := rango(rplantilla.id, grupos[j], rdesglose.min_dias, rdesglose.max_dias);

			    IF rplantilla.exige_profesor THEN
			    
			    RAISE NOTICE '       [INFO] OPTIMIZACION DEL PROFESOR ...';
                            -- ----------------------------------------------------------------------------
                            -- OPTIMIZACION DEL PROFESOR
                            -- ----------------------------------------------------------------------------
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------
				RAISE NOTICE '       [INFO] Obtengo los profesores asignados al grupo actual para la actividad actual ...';
                                -- Obtengo los profesores asignados al grupo actual para la actividad actual

                                actual_profe := dame_lista_id_profes_asignados_al_grupo(rplantilla.id, grupos[j]);
                                
                                cantActualProfe := matrix.get_length_of(actual_profe, 1);
                                
				RAISE NOTICE '       [INFO] cantActualProfe = % ', cantActualProfe;
				
				IF cantActualProfe > 0 THEN
					actual_profe_cant := matrix.create_numeric_matrix(cantActualProfe,CD);
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------
					-- cantidad de turnos ocupados en actividades por dia

					RAISE NOTICE '       [INFO] se calcula el gasto total en el periodo para cada profesor ...';
					  
					-- se calcula el gasto total en el periodo para cada profesor

					l := 1;
					LOOP
					    actual_profe_gastos[l] := 0;
					    FOR r IN SELECT * FROM actividad WHERE dame_periodo_plantilla_de_actividad(plantilla) = rperiodo.id AND profesor = actual_profe[l] LOOP
						k := dame_duracion_clasif_de_actividad(dame_clasif_plantilla_de_actividad(rplantilla.id));
						actual_profe_cant[l][r.dia] := actual_profe_cant[l][r.dia] + k;
						actual_profe_gastos[l] := actual_profe_gastos[l] + k;
					    END LOOP;

					    EXIT WHEN l >= cantActualProfe;
					    l := l + 1;
					END LOOP;
					
					-- si hay mas de un profesor se selecciona el mejor con el metodo prioriza 
					-- dado los criterios:
					--      gasto (min)
					--      prioridad segun el seguridad.usuario (min)
					-- pero como la lista de profesores ya viene ordenada por prioridad
					-- entonces basta con buscar el primer profesor con el minimo gasto
					
					RAISE NOTICE '       [INFO] buscar el primer profesor con el minimo gasto ...';
					
					mejor_profe := 1;
					minim := -1;
					IF cantActualProfe > 1 THEN
					    l := 1;
					    LOOP
						IF minim = -1 OR minim > actual_profe_gastos[l] THEN
						    minim := actual_profe_gastos[l];
						    mejor_profe := l;
						END IF;
						
						EXIT WHEN l >= cantActualProfe;
						l := l + 1;
					    END LOOP;
					    
					END IF;
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------					
					-- una vez obtenido el mejor profesor, entonces se crea una lista
					-- con los mejores dias para el profesor en el rango posible de colocacion
					-- el dia optimo esta dado por el dia de mas gasto
					-- pues la idea es minimizar la cantidad de dias que debe venir
					-- el profesor a dar clases (este parametro puede ser configurable)

					RAISE NOTICE '       [INFO] determinando los mejores dias para el profesor en el rango posible de colocacion ...';
								 
					dias_buenos_profe := matrix.create_numeric_list(CD);
					
					-- la principio es consecutivo
					l := 1;
					LOOP
					    dias_buenos_profe[l] := l;
					    EXIT WHEN l = CD;
					    l := l + 1;
					END LOOP;

					RAISE NOTICE '       [INFO] luego ordeno en el rango, de mayor a menor ...';
					
					-- luego ordeno en el rango, de mayo a menor
					
					l := rangobusqueda.ini;
					LOOP
					    k := l + 1;
					    LOOP
						IF actual_profe_cant[mejor_profe][l] < actual_profe_cant[mejor_profe][k]  THEN
						    t := actual_profe_cant[mejor_profe][l];
						    actual_profe_cant[mejor_profe][l] := actual_profe_cant[mejor_profe][k];
						    actual_profe_cant[mejor_profe][k] := t;
						    
						    t:= dias_buenos_profe[l];
						    dias_buenos_profe[l] := dias_buenos_profe[k];
						    dias_buenos_profe[k] := t;
						END IF;
											
						EXIT WHEN k >= rangobusqueda.fin;
						k := k + 1;
					    END LOOP;
					    EXIT WHEN l >= rangobusqueda.fin - 1;
					    l := l +1;
					END LOOP;
                                END IF;
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------
				RAISE NOTICE 'dias_buenos_profe =';
				execute matrix.echo(dias_buenos_profe);
                                
                                RAISE NOTICE '       [INFO] terminada la OPTIMIZACION DEL PROFESOR ...';
				-- ----------------------------------------------------------------------------

				-- deshabilitar los turnos donde el profesor no puede dar clases

				ddia :=1;
				LOOP
					tturno :=1;
					LOOP
						dduracion := 1;
						LOOP
							EXIT WHEN grupompi[ddia][tturno] = false;
							
							v := valor_restriccion_profesor(actual_profe[mejor_profe], rperiodo.id, ddia, tturno + dduracion - 1);
							IF v > 0 THEN
								grupompi[ddia][tturno] := false;
								EXIT;
							END IF;
							EXIT WHEN dduracion >= rclasificacion.duracion;
							dduracion := dduracion + 1;
						END LOOP;
						EXIT WHEN tturno >= CT;
						tturno := tturno + 1;
					END LOOP;
					EXIT WHEN ddia >= CD;
					ddia := ddia + 1;
				END LOOP;
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------
                            
                            END IF;
                            
                            IF j = 1 AND idClasifSgte <> '' AND idClasifSgte <> rclasificacion.id THEN
                                IF parche = FALSE OR dia_anterior <= (CD / 2) -1 THEN
                                    dia_anterior := dia_minimo_impacto (idClasifSgte, idesp, idnivel, rperiodo.id, rangobusqueda.ini, rangobusqueda.fin);
                                    -- dia_anterior := dia_minimo_impacto (idClasifSgte, idesp, idnivel, rperiodo.id, grupos_rangos[j][1], grupos_rangos[j][2]);
                                END IF;
                            END IF;

                            RAISE NOTICE '       [INFO] verificando que la actividad no este asignada ...';
                            -- verificando que la actividad no este asignada
                            
                            SELECT count(id) as cant INTO r FROM actividad WHERE plantilla = rplantilla.id AND grupo = grupos[j];

                            esta_colocada := FALSE;
                            IF r.cant > 0 THEN
                                esta_colocada := TRUE;
                                sePudoColocar := TRUE;
                            END IF;

                            IF esta_colocada = FALSE THEN
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------
				RAISE NOTICE '       [INFO] actualiza sentido para mayor combinacion ...';
                                -- actualiza sentido para mayor combinacion

                                IF sentido = 2 THEN
                                    sentido := 1;
                                    ini_sentido := 1;
                                    fin_sentido := CT;
                                    step_sentido := 1;
                                ELSE
                                    sentido = 2;
                                    ini_sentido := CT;
                                    fin_sentido := 1;
                                    step_sentido := -1;
                                END IF;


                                /*
                                'BUSQUEDA POR ZONAS
                                    'Polietapas
                                    'zona:
                                    '1-Zona priori
                                    '2-Zona todo
                                    'ciclo por cada etapa
                                    '1- Mismo Dia
                                    '2- Posib>=faltan
                                    '3- Cualquier dia
                                */

				RAISE NOTICE '       [INFO] busqueda por zonas ...';
                                zona := 1;
                                LOOP
                                
                                    etapa := 1;
                                    LOOP
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------                                    
					-- preparo el rango de busqueda por dia
					IF etapa = 1 And dia_anterior > rangobusqueda.ini THEN
					    CicloIni := dia_anterior;
					    CicloFin := dia_anterior;
					ELSE
					    CicloIni := rangobusqueda.ini;
					    CicloFin := rangobusqueda.fin;

					    IF CicloFin > maxDia THEN 
						CicloFin := maxDia;
					    END IF;
					END IF;

                                        kk := CicloIni;
                                        LOOP
						k := kk;
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------
						idprofe = NULL;

						es_higienico_profe := TRUE;

						RAISE NOTICE '       [INFO] optimizando al profesor e higiene para profesor ...';
						IF rplantilla.exige_profesor = TRUE THEN
						    
						    -- optimizando al profesor
						    k := dias_buenos_profe[kk];
						    idprofe := actual_profe[mejor_profe];
							
						    -- higiene para profesor
						    es_higienico_profe := es_higienico_profesor(idprofe, rplantilla.id, k);
							
						END IF;

						IF es_higienico_profe = TRUE THEN
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------
							IF rplantilla.exige_profesor = FALSE OR NOT (rplantilla.exige_profesor = TRUE AND idprofe IS NULL) THEN 
											
								RAISE NOTICE '       [INFO] higiene para brigada ...';
								-- ----------------------
								-- higiene para brigadas

								es_higienico_brg := TRUE;
								
								ih := 1;
								LOOP
								    es_higienico_brg := es_higienico_brigada(listaidbrg[ih], rplantilla.id, k);
									
								    EXIT WHEN ih >= cantListaIdBrg OR es_higienico_brg = FALSE;
								    ih := ih + 1;
								END LOOP;

								IF es_higienico_brg = TRUE THEN
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------
									-- ----------------------
									RAISE NOTICE '       [INFO] colocando ...';
											    
									puedo := TRUE;

									IF rdesglose.respetar_orden = FALSE AND rdesglose.mismo_dia = FALSE THEN

										SELECT * INTO r FROM actividad WHERE grupo = grupos[j] AND dame_desglose_de_plantilla(plantilla) = rdesglose.id;

										IF r.grupo = grupos[j] THEN
										    puedo := FALSE;
										END IF;

									END IF;

									RAISE NOTICE ' [------] k = % puedo = %', k, puedo;
												
									IF k <> 0 AND puedo = TRUE THEN

        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------

										IF posibXDia[k] >= faltan OR etapa = 3 THEN

											t := ini_sentido;

											LOOP

											    IF parche1 = TRUE THEN
												IF etapa = 1 AND idMaxPIGrupo[j][k] <> 0 THEN
												    IF grupompi[k][idMaxPiGrupo[j][k]] = TRUE AND zp[k][idMaxPiGrupo[j][k]] = zona THEN
													t := idMaxPiGrupo[j][k];
												    END IF;
												END IF;
											    END IF;
							    
											    
											    IF NOT (grupompi[k][t] = TRUE AND etapa = 1 AND xasig[t] = TRUE) THEN 
											      -- CONTINUE WHEN grupompi[k][t] = TRUE AND etapa = 1 AND xasig[t] = TRUE;
											    
												    IF grupompi[k][t] = TRUE THEN
												    
													IF etapa = 2 AND dia_anterior = 0 THEN
													    xasig[t] = TRUE;
													END IF;
												  

        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------

													    IF rplantilla.exige_lugar = TRUE THEN

														RAISE NOTICE '       [INFO] asignando lugar ...';

														-- asignando lugar
													    
														idlugar := '';
														
														-- preparando...
														
														lugares := dame_lista_id_lugares_asignados(rplantilla.id);				

														RAISE NOTICE '            --------- % lugares posibles para la plantilla %',matrix.get_length_of(lugares, 1), rplantilla.id;
														RAISE NOTICE '       [INFO] lugares filtrados, extraer los que no permanecen en el turno ';

														-- extraer los que no permanecen en el turno

														lugares := extraer_lugares_que_no_permanecen(lugares, rperiodo.id, k, t, rclasificacion.duracion);

														RAISE NOTICE '       [INFO] lugares filtrados, extraer los lugares que no tienen capacidad ';
														
														-- extraer los lugares que no tienen capacidad

        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------														lugares := quita_segun_capacidad(listaidbrg, lugares);

														RAISE NOTICE '       [INFO] lugares filtrados, extraer los lugares prohibidos ';
														
														-- extraer los lugares prohibidos

														lugares := quita_segun_prohibidos(('{' || quote_literal(grupos[j]) || '}')::VARCHAR[], lugares);

														cantLugares := matrix.get_length_of(lugares, 1);

														RAISE NOTICE '       [INFO] lugares filtrados!!!, quedaron % ', cantLugares;

														IF cantLugares > 0 THEN
															
															-- colocando ...   
															-- tratar de colocar en el aula fija
															pos := -1;
															
															IF EXISTS(SELECT * FROM lugar_fijo WHERE grupo = grupos[j]) THEN
																SELECT * INTO r FROM lugar_fijo WHERE grupo = grupos[j];
																pos := matrix.get_pos_of(lugares, r.lugar);
																IF pos > -1 THEN
																    idlugar := lugares[pos];
																END IF;
															END IF;
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------															    
															-- buscar el mejor lugar

															-- buscar segun prioridades
																									
															IF pos = -1 THEN

															    -- obtengo la maxima prioridad dada a los lugares para la plantilla de actividad actual
															    
															    SELECT * INTO r FROM lugar_para_actividad WHERE plantilla = rplantilla.id ORDER BY prioridad DESC LIMIT 1 OFFSET 0;
															   
															    maxpriori := r.prioridad;
															    
															    -- tanto para la busqueda por el lugar mas utilizado como para el mas cercano
															    -- se busca segun las prioridades dadas por el seguridad.usuario a los lugares 
															    
															    -- obtengo la prioridad de cada lugar
															    
															    lugs_priori := matrix.create_numeric_list(cantLugares);
															    
															    ll := 1;
															    LOOP
																SELECT * INTO r FROM lugar_para_actividad WHERE lugar = lugares[ll] AND plantilla = rplantilla.id;
																
																lugs_priori[ll] := r.prioridad;
																
																EXIT WHEN ll = cantLugares;
																ll := ll + 1;
															    END LOOP;
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------
															    -- comienza la colocacion
															    l := 1;
															    LOOP
																RAISE NOTICE '    seleccionando lugar prioridad % ', l;
																-- seleccionar los lugares que tienen la prioridad actual
																
																lugs := '{}'::VARCHAR[];
																
																ll := 1;
																LOOP
																    IF lugs_priori[ll] = l THEN
																	lugs := array_append(lugs, lugares[ll]);
																    END IF;
																    
																    EXIT WHEN ll = cantLugares;
																    ll := ll + 1;
																END LOOP;

        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------																
																cantLugs := matrix.get_length_of(lugs, 1);

																RAISE NOTICE ' ------ % lugares con prioridad % ',cantLugs, l;
																EXECUTE matrix.echo(lugs);
																
																idlugar := '';
																
																
																IF cantLugs > 0 THEN
																	
																    -- asignando...
																    -- TODO: pensar en una variante conjunta entre el mas usado y mas cercano

																    IF buscalugar = FALSE THEN

																	RAISE NOTICE '- buscando lugar por prioridades ';
																    
																	-- el mas utilizado por el grupo actual
																	idlugar := busca_lugar_mas_utilizado_por(lugs, grupos[j], FALSE);

																	RAISE NOTICE '- lugar mas utilizado % ', idlugar;
																	
																	IF idlugar = '' THEN
																	    
																	    -- el menos utilizado por los demas
																	    idlugar := busca_lugar_menos_utilizado_por(lugs, grupos[j], TRUE);

																	    RAISE NOTICE '- lugar menos utilizado % ', idlugar;
																	    
																	    IF idlugar = '' THEN
																		-- se coge el primero
																		idlugar := lugs[1];
																		RAISE NOTICE '- .....EL PRIMERO !!!! % ', idlugar;
																	    END IF;
																	END IF;

																	RAISE NOTICE '- mejor lugar = %', idlugar;
																	
																    ELSE
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------																    
																	RAISE NOTICE '- buscando lugar mas cercano ';
																	-- ... el mas cercano
																	RAISE NOTICE '- dame_lugares_usados_alrededor_de ';
																	lugsarround := dame_lugares_usados_alrededor_de(listaidbrg, rperiodo.id, k, t);
																	RAISE NOTICE '- busca_lugar_menos_costoso ';
																	idlugar := busca_lugar_menos_costoso(lugs, lugsarround);
																	RAISE NOTICE '- lugar mas cercano = %', idlugar;
																    END IF;
																END IF;

																EXIT WHEN l = maxpriori OR idlugar <> '';
																l := l + 1;
															    END LOOP;
															END IF;
														END IF;
													END IF;   

													IF rplantilla.exige_lugar = FALSE OR NOT (rplantilla.exige_lugar = TRUE AND idlugar = '') THEN
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------														

														RAISE NOTICE '       [INFO] asignando otros recursos ...';
														-- asignando otros recursos
														
														idrecursos := '{}'::VARCHAR[];
														
														-- comprobar la disponibilidad de otros recursos

														gruporecursos := dame_lista_id_grupos_de_recursos_asignados(rplantilla.id);
														cantGrupoRecursos := matrix.get_length_of(gruporecursos,1);

														gr := 0;
														LOOP
														    EXIT WHEN gr = cantGrupoRecursos;
														    
														    SELECT * INTO rgruporecurso FROM otro_grupo_de_recursos_para_actividad WHERE id = gruporecursos[i];
														    
														    l := 0;
														    FOR r IN SELECT *, dame_uso_de_otro_recurso(otro_recurso) as uso, 
																	dame_costo_trasladar_recurso(otro_recurso, idlugar, rperiodo.id, k, t) as costo 
															     FROM otro_recurso_para_actividad WHERE grupo_de_recursos = gruporecursos[gr] 
															     ORDER BY prioridad, uso, costo 
															LOOP
															
															idrecursos := array_append(idrecursos, r.otro_recurso);
															l := l + 1;
															EXIT WHEN l = rgruporecurso.necesarios;
														    END LOOP;
														    
														    EXIT WHEN gr = cantGrupoRecursos;
														    gr := gr + 1;
														END LOOP;
													
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------													
														RAISE NOTICE '       [INFO] agregando la actividad ...';

														-- agregando la actividad
														IF rplantilla.exige_lugar = FALSE THEN
														    idlugar := NULL;
														END IF;  
														
														-- agregando la actividad
														IF rplantilla.exige_profesor = FALSE THEN
														    idprofe := NULL;
														END IF;                        

														execute matrix.echo(lugs);
														RAISE NOTICE '       plantilla = %',rplantilla.id;
														RAISE NOTICE '       profe = %',idprofe;
														RAISE NOTICE '       lugar = %',idlugar;
														RAISE NOTICE '       k = %',k;
														RAISE NOTICE '       t = %',t;
														RAISE NOTICE '       grupo = %',grupos[j];
														
														execute matrix.echo(idrecursos);

														RAISE NOTICE '	     momento = %', tiempo.moment_now();
														RAISE NOTICE '       creador = %', rasignatura.creador;
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------																		
														EXECUTE agrega_actividad(rplantilla.id, idprofe, idlugar, k, t, grupos[j], idrecursos, tiempo.moment_now(), rasignatura.creador);

														sePudoColocar := true;
														
														-- --------------------------------------------
													ELSE
														RAISE NOTICE ' ---------------- no se pudo colocar por falta de lugar';
													END IF;
												END IF;
											END IF;
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------											
										    EXIT WHEN t = fin_sentido or sePudoColocar = true;
										    t := t + step_sentido;
										END LOOP;
									    END IF;

									END IF;
								END IF;
							    RAISE NOTICE ' ****** [INFO CICLO] kk = % de CicloFin = % ', kk , CicloFin;
							
							ELSE
								RAISE NOTICE ' ---------------- no se pudo colocar por falta de profesor';
							END IF;
						END IF;
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------						    
					    EXIT WHEN kk = CicloFin or sePudoColocar = true;
					    kk := kk + 1;
					    
					END LOOP;

					RAISE NOTICE ' ****** [INFO CICLO] etapa = % de 3  ', etapa;
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------					
					EXIT WHEN etapa = 3 or sePudoColocar = true;
					etapa := etapa + 1;
				    END LOOP;

				    RAISE NOTICE ' ****** [INFO CICLO] zona = % de ztodo = %  ', zona, ztodo;
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------				    
				    EXIT WHEN zona = ztodo or sePudoColocar = true;
				    zona := zona + 1;
				END LOOP;
			    END IF;
		    
			    IF sePudoColocar = false THEN
				RAISE NOTICE ' no se pudo colocar!!!!! ';
				-- TODO: registrar
			    END IF;
			    
			    RAISE NOTICE ' ****** [INFO CICLO] j = % de cantGrupos = %  ', j, cantGrupos;
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------			    
			    EXIT WHEN j >= cantGrupos;
			    
			    grupo_anterior := j;
			    
			    j := j + 1;
			END LOOP;
			
			-- --------------------------------------------
			RAISE NOTICE ' ****** [INFO CICLO] i = % de cantPriorizando = %  ', i, cantPriorizando;
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------			
			EXIT WHEN i = cantPriorizando;
			i := i + 1;
		    END LOOP;

		    RAISE NOTICE ' ****** [INFO CICLO] varCiclo2 = % de cantCiclo2 = %  ', varCiclo2, cantCiclo2;
		    
		    --EXIT WHEN varCiclo2 >= cantCiclo2;
		    
		    --varCiclo2 := varCiclo2 + 1;
		END LOOP;

                RAISE NOTICE ' ****** [INFO CICLO] varCiclo1 = % de cantCiclo1 = %  ', varCiclo1, cantCiclo1;
                
                --EXIT WHEN varCiclo1 >= cantCiclo1;
                --varCiclo1 := varCiclo1 + 1;
            END LOOP;

            RAISE NOTICE ' ****** [INFO CICLO] voyact = % de cantActEnCurso = %  ', voyAct, cantActEnCurso;
        -------------------------------------------------------------------
        IF generador.fue_cancelado(idesp, idnivel, idperiodo) = TRUE THEN
		RETURN;
        END IF;
        -------------------------------------------------------------------
	    voyAct := voyAct + 1;
	    
            EXIT WHEN voyact >= cantActEnCurso;
            
        END LOOP;
        
    END;
$$;


ALTER FUNCTION public.generar(idesp character varying, idnivel character varying, idperiodo character varying, forma bigint, parche boolean, compactar bigint, parche1 boolean, buscalugar boolean) OWNER TO postgres;

--
-- Name: get_max_colocation(boolean[], integer); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION get_max_colocation(arr boolean[], duracion integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
    DECLARE crows BIGINT;
        i INTEGER;
        inipi INTEGER;
        ini INTEGER;
        c INTEGER;
    BEGIN
        crows := matrix.get_length_of(arr, 1);

        IF crows = 0 THEN
            RETURN 0;
        END IF;

        inipi := 0;
        c := 0;
        
        i := 1;
        LOOP 
            IF arr[i] = TRUE THEN
                inipi = i;
                c := 1;
            END IF;
            EXIT WHEN i >= crows OR c = 1;
            i := i + 1;
        END LOOP;

        IF inipi > 0 THEN
		LOOP
		    EXIT WHEN ini + duracion > crows;

		    ini := inipi + duracion;
		    
		    IF arr[ini] = FALSE THEN
			inipi = inipi+ 1;
		    ELSE
			IF ini < crows OR duracion = 1 THEN
			    c := c + 1;
			END IF;
			inipi = ini;
		    END IF;
			
		END LOOP;
        END IF;
        
        RETURN c;

    END;
$$;


ALTER FUNCTION public.get_max_colocation(arr boolean[], duracion integer) OWNER TO rafa;

--
-- Name: FUNCTION get_max_colocation(arr boolean[], duracion integer); Type: COMMENT; Schema: public; Owner: rafa
--

COMMENT ON FUNCTION get_max_colocation(arr boolean[], duracion integer) IS 'Dado un arreglo de posibles inicios de una actividad devuelve la maxima cantidad de colocaciones posibles';


--
-- Name: greatest(numeric, numeric); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION "greatest"(numeric, numeric) RETURNS numeric
    LANGUAGE sql
    AS $_$SELECT CASE WHEN (($1 > $2) OR ($2 IS NULL)) THEN $1 ELSE $2 END;$_$;


ALTER FUNCTION public."greatest"(numeric, numeric) OWNER TO rafa;

--
-- Name: greatest(numeric, numeric, numeric); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION "greatest"(numeric, numeric, numeric) RETURNS numeric
    LANGUAGE sql
    AS $_$SELECT greatest($1, greatest($2, $3));$_$;


ALTER FUNCTION public."greatest"(numeric, numeric, numeric) OWNER TO rafa;

--
-- Name: if(boolean, text, text); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION if(boolean, text, text) RETURNS text
    LANGUAGE sql
    AS $_$SELECT CASE WHEN $1 THEN $2 ELSE $3 END;$_$;


ALTER FUNCTION public.if(boolean, text, text) OWNER TO rafa;

--
-- Name: if(boolean, integer, integer); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION if(boolean, integer, integer) RETURNS integer
    LANGUAGE sql
    AS $_$SELECT CASE WHEN $1 THEN $2 ELSE $3 END;$_$;


ALTER FUNCTION public.if(boolean, integer, integer) OWNER TO rafa;

--
-- Name: iif(boolean, anyelement, anyelement); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION iif(expresion boolean, dato1 anyelement, dato2 anyelement) RETURNS anyelement
    LANGUAGE sql
    AS $_$ 
    SELECT CASE $1 WHEN TRUE THEN $2 ELSE $3 END;
$_$;


ALTER FUNCTION public.iif(expresion boolean, dato1 anyelement, dato2 anyelement) OWNER TO rafa;

--
-- Name: FUNCTION iif(expresion boolean, dato1 anyelement, dato2 anyelement); Type: COMMENT; Schema: public; Owner: rafa
--

COMMENT ON FUNCTION iif(expresion boolean, dato1 anyelement, dato2 anyelement) IS 'Devuelve el primer elemento si la condicion es true y el segundo si es falsa';


--
-- Name: lugar_permanece_en(character varying, character varying, integer, integer, integer); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION lugar_permanece_en(plugar character varying, pperiodo character varying, pdia integer, pturno integer, duracion integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
    DECLARE i INTEGER;
	v INTEGER;
    BEGIN
	i := 1;
	LOOP
		v := valor_restriccion_lugar(plugar, pperiodo, pdia, pturno);
		IF v > 0 THEN
			RETURN FALSE;
		END IF;
		EXIT WHEN i >= pturno + duracion;
		i := i + 1;
	END LOOP;
	
        RETURN TRUE;
    END;
$$;


ALTER FUNCTION public.lugar_permanece_en(plugar character varying, pperiodo character varying, pdia integer, pturno integer, duracion integer) OWNER TO rafa;

--
-- Name: max_cant_act(character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION max_cant_act(especialidad character varying, nivel character varying, periodo character varying) RETURNS bigint
    LANGUAGE sql
    AS $_$
    SELECT max(cantidad)
    FROM asignaturas_cant_act 
    WHERE especialidad = $1 AND nivel = $2 AND periodo = $3;
$_$;


ALTER FUNCTION public.max_cant_act(especialidad character varying, nivel character varying, periodo character varying) OWNER TO rafa;

--
-- Name: mueve_o_crea_brigada_de_grupo(character varying, character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION mueve_o_crea_brigada_de_grupo(idbrg character varying, idgrupo character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
	declare r record;
		rr record;
		rgrupo record;
	begin
		-- verificando que el grupo destino no tenga actividad

		select * into r from actividad where grupo = idgrupo;

		if found then
			return false;
		end if;

		-- verificando que ya este asignado a ese grupo
		
		select * into r from brigada_de_grupo where brigada = idbrg and grupo = idgrupo;

		if found then
			return true;
		end if;

		-- verifico que el grupo no tenga actividad asignada
		
		-- obtengo el grupo
		select * into rgrupo from grupo where id = idgrupo;

		-- si no existe me voy
		if not found then
			return false;
		end if;
			
		-- verifico si esta asignada a otro grupo de la misma (esp,nivel,clasif)

		select * into r from brigada_de_grupo 
			where brigada = idbrg 
			and dame_especialidad_de_grupo(grupo) = rgrupo.especialidad 
			and dame_nivel_de_grupo(grupo) = rgrupo.nivel
			and dame_clasificacion_de_grupo(grupo) = rgrupo.clasificacion
			and dame_planificacion_de_grupo(grupo) = rgrupo.planificacion;

		-- elimino el grupo origen
		if found then
			-- verificando que el grupo origen no tenga actividad
			select * into rr from actividad where grupo = r.grupo;

			if found then
				return false;
			end if;
			
			delete from brigada_de_grupo where brigada = idbrg and grupo = r.grupo;
		end if;

		-- creo el grupo destino
		insert into brigada_de_grupo (brigada,grupo) values (idbrg, idgrupo);
		
		return true;
	end;
$$;


ALTER FUNCTION public.mueve_o_crea_brigada_de_grupo(idbrg character varying, idgrupo character varying) OWNER TO rafa;

--
-- Name: nivela_prioridad_lxact_after_delete(); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION nivela_prioridad_lxact_after_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	declare r record;
		p integer;
	begin
		p := OLD.prioridad;
		
		select * into r from lugar_para_actividad where prioridad = p AND plantilla = OLD.plantilla;
		if not found then
			update lugar_para_actividad set prioridad = prioridad - 1 where prioridad > p AND plantilla = OLD.plantilla;
		end if;

		return OLD;
	end;
$$;


ALTER FUNCTION public.nivela_prioridad_lxact_after_delete() OWNER TO rafa;

--
-- Name: nivela_prioridad_lxact_after_update(); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION nivela_prioridad_lxact_after_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	declare r record;
		p integer;
	begin
		if new.actualizacion_interna = FALSE AND new.prioridad <> old.prioridad then
			p := OLD.prioridad;
			
			select * into r from lugar_para_actividad where prioridad = p;
			if not found then
				update lugar_para_actividad set prioridad = prioridad -1, actualizacion_interna = TRUE where prioridad > p AND plantilla = OLD.plantilla;
				update lugar_para_actividad set actualizacion_interna = FALSE WHERE plantilla = OLD.plantilla AND lugar = NEW.lugar;				
				NEW.prioridad = NEW.prioridad - 1;
			end if;
		end if;
		return NEW;
	end;
$$;


ALTER FUNCTION public.nivela_prioridad_lxact_after_update() OWNER TO rafa;

--
-- Name: nivela_prioridad_rxact_after_delete(); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION nivela_prioridad_rxact_after_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	declare r record;
		p integer;
	begin
		p := OLD.prioridad;
		
		select * into r from otro_grupo_de_recursos_para_actividad where prioridad = p;
		if not found then
			update otro_grupo_de_recursos_para_actividad set prioridad = prioridad - 1 where prioridad > p AND plantilla = OLD.plantilla;
		end if;

		return OLD;
	end;
$$;


ALTER FUNCTION public.nivela_prioridad_rxact_after_delete() OWNER TO rafa;

--
-- Name: nuevo_desglose_cuando_nueva_asignatura(); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION nuevo_desglose_cuando_nueva_asignatura() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	DECLARE r record;
	    pcreador varchar;
	begin
		
		FOR r IN SELECT * FROM periodo WHERE dame_creador_de_planificacion(dame_planificacion_de_periodo(id)) = NEW.creador LOOP
			INSERT INTO desglose (asignatura, periodo) VALUES (NEW.id, r.id);
		END LOOP;
		
		return NEW;
	end;
$$;


ALTER FUNCTION public.nuevo_desglose_cuando_nueva_asignatura() OWNER TO rafa;

--
-- Name: nuevo_desglose_cuando_nuevo_periodo(); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION nuevo_desglose_cuando_nuevo_periodo() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	DECLARE r record;
	    pcreador varchar;
	begin
		pcreador := dame_creador_de_planificacion(dame_planificacion_de_periodo(NEW.id));

		FOR r IN SELECT * FROM asignatura WHERE creador = pcreador LOOP
			INSERT INTO desglose (asignatura, periodo) VALUES (r.id, NEW.id);
		END LOOP;
		
		return NEW;
	end;
$$;


ALTER FUNCTION public.nuevo_desglose_cuando_nuevo_periodo() OWNER TO rafa;

--
-- Name: plantilla_exige_lugar(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION plantilla_exige_lugar(id character varying) RETURNS boolean
    LANGUAGE sql
    AS $_$
    SELECT exige_lugar FROM plantilla_de_actividad WHERE id = $1;
$_$;


ALTER FUNCTION public.plantilla_exige_lugar(id character varying) OWNER TO rafa;

--
-- Name: plantilla_exige_profesor(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION plantilla_exige_profesor(id character varying) RETURNS boolean
    LANGUAGE sql
    AS $_$
    SELECT exige_profesor FROM plantilla_de_actividad WHERE id = $1;
$_$;


ALTER FUNCTION public.plantilla_exige_profesor(id character varying) OWNER TO rafa;

--
-- Name: actividad; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE actividad (
    id character varying DEFAULT crear_id_de_replica('ancoragoh'::character varying, 'actividad'::character varying, 'id'::character varying, 'actividad'::character varying) NOT NULL,
    plantilla character varying NOT NULL,
    grupo character varying NOT NULL,
    profesor character varying,
    lugar character varying,
    dia integer,
    turno integer,
    momento_de_colocacion double precision,
    creador character varying NOT NULL,
    CONSTRAINT actividad_check CHECK ((((plantilla_exige_profesor(plantilla) = true) AND (profesor IS NOT NULL)) OR (plantilla_exige_profesor(plantilla) = false))),
    CONSTRAINT actividad_check1 CHECK ((((plantilla_exige_lugar(plantilla) = true) AND (lugar IS NOT NULL)) OR (plantilla_exige_lugar(plantilla) = false)))
);


ALTER TABLE public.actividad OWNER TO rafa;

--
-- Name: restriccion_condicional; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE restriccion_condicional (
    id character varying DEFAULT crear_id_de_replica('ancoragoh'::character varying, 'restriccion_condicional'::character varying, 'id'::character varying, 'restriccion_condicional'::character varying) NOT NULL,
    planificacion character varying,
    activa boolean DEFAULT true,
    clasif_act character varying,
    asig character varying,
    brigada character varying,
    profesor character varying,
    lugar character varying,
    otro_recurso character varying,
    especialidad character varying,
    nivel character varying,
    fecha_ini integer,
    fecha_fin integer,
    hora_ini double precision,
    hora_fin double precision,
    discreto_exacto boolean,
    dia_ini_planif integer,
    dia_fin_planif integer,
    hora_ini_planif double precision,
    hora_fin_planif double precision,
    discreto_exacto_planif boolean,
    periodo character varying,
    dia_ini integer,
    dia_fin integer,
    turno_ini integer,
    turno_fin integer,
    discreto boolean,
    hoy boolean,
    ahora boolean,
    dia_relativo_anterior integer DEFAULT 0,
    cant_dias_relativo_anterior integer DEFAULT 0,
    dia_relativo_posterior integer DEFAULT 0,
    cant_dias_relativo_posterior integer DEFAULT 0,
    rango_tiempo_relativo_anterior_ini double precision,
    rango_tiempo_relativo_anterior_tamano double precision,
    turno_relativo_anterior integer,
    cant_turnos_relativo_anterior integer,
    turno_relativo_posterior integer DEFAULT 0,
    cant_turnos_relativo_posterior integer DEFAULT 0,
    rango_tiempo_relativo_posterior_ini double precision,
    rango_tiempo_relativo_posterior_tamano double precision,
    entre_dias_antes integer,
    entre_dias_despues integer,
    entre_turnos_antes integer,
    entre_turnos_despues integer,
    entre_tiempo_antes double precision,
    entre_tiempo_despues double precision,
    cant_exa integer DEFAULT 1,
    cant_min integer DEFAULT 1,
    cant_max integer DEFAULT 1,
    consec_brigada character varying,
    consec_profesor character varying,
    consec_lugar character varying,
    consec_otro_recurso character varying,
    consec_periodo character varying NOT NULL,
    consec_dia_ini integer,
    consec_dia_fin integer,
    consec_turno_ini integer,
    consec_turno_fin integer,
    consec_discreto boolean DEFAULT true,
    siempre boolean,
    valor integer DEFAULT 1,
    CONSTRAINT restriccion_condicional_cant_dias_relativo_anterior_check CHECK ((cant_dias_relativo_anterior > (-1))),
    CONSTRAINT restriccion_condicional_cant_dias_relativo_posterior_check CHECK ((cant_dias_relativo_posterior > (-1))),
    CONSTRAINT restriccion_condicional_cant_turnos_relativo_anterior_check CHECK ((cant_turnos_relativo_anterior > (-1))),
    CONSTRAINT restriccion_condicional_cant_turnos_relativo_posterior_check CHECK ((cant_turnos_relativo_posterior > (-1))),
    CONSTRAINT restriccion_condicional_dia_relativo_anterior_check CHECK ((dia_relativo_anterior > (-1))),
    CONSTRAINT restriccion_condicional_dia_relativo_posterior_check CHECK ((dia_relativo_posterior > (-1))),
    CONSTRAINT restriccion_condicional_turno_relativo_anterior_check CHECK ((turno_relativo_anterior > (-1))),
    CONSTRAINT restriccion_condicional_turno_relativo_posterior_check CHECK ((turno_relativo_posterior > (-1))),
    CONSTRAINT restriccion_condicional_valor_check CHECK ((valor > 0))
);


ALTER TABLE public.restriccion_condicional OWNER TO rafa;

--
-- Name: ocurre_causa_rest_cond(restriccion_condicional, actividad, character varying, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION ocurre_causa_rest_cond(rc restriccion_condicional, act actividad, idperiodo character varying, pdia integer, pturno integer, analiza_completo boolean) RETURNS boolean
    LANGUAGE plpgsql
    AS $$    
DECLARE 
    r record;
    r1 record;
    tbool boolean;
    duracion_act integer;
    actperiodo varchar;
    hi double precision;
    hf double precision;
    dia_hoy bigint;
BEGIN
	actperiodo := dame_periodo_plantilla_de_actividad(act.plantilla);

    -- analizar que la actividad se identifique con los objetos
    -- y caracteristicas (asig, clasif)
    -- si las propiedades son nulas las ignoro

    -- no analizar completo significa que lo que existen atributos
    -- que se pueden analizar en una clausula WHERE de un SELECT
    -- y queda mas optimo como por ejemplo:
        /**
            SELECT * FROM actividad WHERE 
            (r.clasif_act = dame_clasif_plantilla_de_actividad(act.plantilla) OR rc.clasif_act IS NULL) AND
            (r.asig = dame_asignatura_plantilla_de_actividad(act.plantilla) OR r.asig IS NULL) AND
            (matrix.get_pos_of(rc.brigada, dame_lista_id_brigadas_de_grupo(act.grupo)) > -1 OR r.brigada IS NULL) AND
            (r.profesor = act.profesor OR r.profesor IS NULL) AND
            (r.lugar = act.lugar OR r.lugar IS NULL) AND
            (r.especialidad = dame_especialidad_de_asignatura(dame_asignatura_plantilla_de_actividad(act.plantilla)) OR r.especialidad IS NULL) AND
            (r.nivel = dame_nivel_de_asignatura(dame_asignatura_plantilla_de_actividad(act.plantilla)) OR r.nivel IS NULL) AND
            (r.periodo = actperiodo OR r.periodo IS NULL) LOOP
            
        */
    
    IF analiza_completo = TRUE THEN
        -- clasificacion de actividad
        IF rc.clasif_act IS NOT NULL THEN
            IF rc.clasif_act <> dame_clasif_plantilla_de_actividad(act.plantilla) THEN
                RETURN FALSE;
            END IF;
        END IF;

        -- asignatura
        IF rc.asig IS NOT NULL THEN
            IF rc.asig <> dame_asignatura_plantilla_de_actividad(act.plantilla) THEN
                RETURN FALSE;
            END IF;
        END IF;
        
        -- brigada
        IF rc.brigada IS NOT NULL THEN
            IF matrix.get_pos_of(rc.brigada, dame_lista_id_brigadas_de_grupo(act.grupo)) = -1 THEN
                RETURN FALSE;
            END IF;
        END IF;

        -- profesor
        IF rc.profesor IS NOT NULL THEN
            IF rc.profesor <> act.profesor THEN
                RETURN FALSE;
            END IF;
        END IF;

        -- lugar
        IF rc.lugar IS NOT NULL THEN
            IF rc.lugar <> act.lugar THEN
                RETURN FALSE;
            END IF;
        END IF;
        -- especialidad
        IF rc.especialidad IS NOT NULL THEN
            IF rc.especialidad <> dame_especialidad_de_asignatura(dame_asignatura_plantilla_de_actividad(act.plantilla)) THEN
                RETURN FALSE;
            END IF;
        END IF;

        -- nivel
        IF rc.nivel IS NOT NULL THEN
            IF rc.nivel <> dame_nivel_de_asignatura(dame_asignatura_plantilla_de_actividad(act.plantilla)) THEN
                RETURN FALSE;
            END IF;
        END IF;

        -- analizando periodo
        IF rc.periodo IS NOT NULL THEN
            IF rc.periodo <> actperiodo THEN
                RETURN FALSE;
            END IF;
        END IF;
    END IF;
    
    -- otros recursos
    IF rc.otro_recurso IS NOT NULL THEN
        SELECT * INTO r FROM otros_recursos_usados WHERE r.otro_recurso = rc.otro_recurso AND actividad = act.id;
        
        IF NOT FOUND THEN
            RETURN FALSE;
        END IF;
    END IF;

    /*  ANALIZANDO EL TIEMPO DE LA ACTIVIDAD */
    
    /** RANGO EXACTO */
    
    tbool := false;
    
    duracion_act := dame_duracion_plantilla_de_actividad(act.plantilla); -- creo la variable para calcularla una sola vez 
                                                                         --porque luego hace falta y para calcularla
    
    hi := dame_hora_inicial_turno(actperiodo, act.turno);
    hf := hi + dame_duracion_turno_periodo(actperiodo) * duracion_act;
   
    FOR r IN SELECT * FROM periodicidad WHERE  periodo = idperiodo LOOP
        dia_hoy := dame_dia_real_planificacion(r.planificacion, r.dia) + pdia - 1;
        
        -- se analiza de forma negativa para analizar los posibles 4*4 casos posibles
        
        /**  @explicacion: no salirse del rango discreto de tiempo por cualquiera de las */
        /**  los lados que no son nulos */
        
        SELECT * INTO r1 FROM restriccion_real WHERE actividad = act.id 
            AND ((rc.discreto_exacto = TRUE 
                    AND NOT (rc.fecha_ini IS NOT NULL AND dia_hoy < rc.fecha_ini)
                    AND NOT (rc.fecha_fin IS NOT NULL AND dia_hoy > rc.fecha_fin)
                    AND NOT (rc.hora_ini IS NOT NULL AND hf < rc.hora_ini)
                    AND NOT (rc.hora_ini IS NOT NULL AND hi > rc.hora_fin)
                  ) OR
                  (rc.discreto_exacto = FALSE 
                    AND NOT (rc.fecha_ini IS NOT NULL AND dia_hoy < rc.fecha_ini)
                    AND NOT (rc.fecha_fin IS NOT NULL AND dia_hoy > rc.fecha_fin)
                    AND NOT (rc.hora_ini IS NOT NULL AND dia_hoy = fecha_ini AND hf < rc.hora_ini)
                    AND NOT (rc.hora_ini IS NOT NULL AND dia_hoy = fecha_fin AND hi > rc.hora_fin)
                  )
                 );
        
        IF FOUND THEN
            tbool := true;
        END IF;
        EXIT WHEN tbool = true;
    END LOOP;

    IF tbool = FALSE AND (
           rc.fecha_ini IS NOT NULL 
        OR rc.fecha_fin IS NOT NULL 
        OR rc.hora_ini IS NOT NULL 
        OR rc.hora_fin IS NOT NULL) THEN
        
        RETURN FALSE;
    END IF;
    
    /** HOY */

    IF rc.hoy IS NOT NULL THEN
    
        -- buscando en todas las periodicidades 
        tbool := false;
        FOR r IN SELECT * FROM periodicidad WHERE  periodo = idperiodo LOOP
            dia_hoy := dame_dia_real_planificacion(r.planificacion, r.dia) + pdia - 1;
            SELECT * INTO r1 FROM restriccion_real WHERE actividad = act.id AND fecha = dia_hoy;
            IF FOUND THEN
                tbool := true;
            END IF;
            EXIT WHEN tbool = true;
        END LOOP;
        
        IF rc.hoy = TRUE THEN
            -- si dice que tiene que ser hoy y si no es hoy me voy
            
            IF tbool = FALSE THEN
                RETURN FALSE;
            END IF;
            
            /** IF dias_se_solapan(actperiodo, act.dia, idperiodo, pdia) = FALSE THEN */
            /**    RETURN FALSE; */
            /** END IF;          */
        ELSE
            -- si dice que no puede ser hoy y si es hoy me voy
            
            IF tbool = TRUE THEN
                RETURN FALSE;
            END IF;
            
            /** IF dias_se_solapan(actperiodo, act.dia, idperiodo, pdia) = TRUE THEN */
            /**    RETURN FALSE;  */
            /** END IF;           */
        END IF;
    END IF;
   
    /** AHORA */
    IF rc.ahora IS NOT NULL THEN
        tbool := false;
        hi := dame_hora_inicial_turno(idperiodo, pturno);
        hf := hi + dame_duracion_turno_periodo(idperiodo);
        
        FOR r IN SELECT * FROM periodicidad WHERE periodo = idperiodo LOOP
            dia_hoy := dame_dia_real_planificacion(r.planificacion, r.dia) + pdia - 1;
            
            SELECT * INTO r1 FROM restriccion_real WHERE actividad = act.id AND fecha = dia_hoy AND NOT (hora_inicial > hf OR hora_final < hi);
            IF FOUND THEN
                tbool := true;
            END IF;
            EXIT WHEN tbool = true;
        END LOOP;
        
        IF rc.ahora = TRUE THEN
            -- se dice que tiene que ser ahora y si no es ahora me voy
            
            IF tbool = FALSE THEN
                RETURN FALSE;
            END IF;
            
            /*IF turnos_se_solapan(actperiodo, act.dia, act.turno, idperiodo, pdia, pturno <> pturno) = FALSE  THEN
                RETURN FALSE;
            END IF;*/
        ELSE
            -- se dice que no puede ser ahora y si es ahora me voy
            
            IF tbool = TRUE THEN
                RETURN FALSE;
            END IF;
            
            /*IF turnos_se_solapan(actperiodo, act.dia, act.turno, idperiodo, pdia, pturno <> pturno) = TRUE THEN
                RETURN FALSE;
            END IF;*/
        END IF;
    END IF;

    /** Dias anteriores */

    IF rc.dia_relativo_anterior IS NOT NULL THEN
        tbool := false;
        FOR r IN SELECT * FROM periodicidad WHERE  periodo = idperiodo LOOP
            dia_hoy := dame_dia_real_planificacion(r.planificacion, r.dia) + pdia - 1;
            SELECT * INTO r1 FROM restriccion_real WHERE actividad = act.id AND (fecha >= dia_hoy - rc.dia_relativo_anterior - rc.cant_dias_relativo_anterior + 1 AND fecha <= dia_hoy - rc.dia_relativo_anterior);
            IF FOUND THEN
                tbool := true;
            END IF;
            EXIT WHEN tbool = true;
        END LOOP;
        
        -- si no encuentra actividad en dias anteriores entonces me voy
        IF tbool = FALSE THEN
            RETURN FALSE;
        END IF;
    END IF;

    /** Dias posteriores */
    
    IF rc.dia_relativo_posterior IS NOT NULL THEN
        tbool := false;
        FOR r IN SELECT * FROM periodicidad WHERE periodo = idperiodo LOOP
            dia_hoy := dame_dia_real_planificacion(r.planificacion, r.dia) + pdia - 1;
            SELECT * INTO r1 FROM restriccion_real WHERE actividad = act.id AND (fecha >= dia_hoy + rc.dia_relativo_posterior AND fecha <= dia_hoy + rc.cant_dias_relativo_posterior - 1);
            IF FOUND THEN
                tbool := true;
            END IF;
            EXIT WHEN tbool = true;
        END LOOP;
        
        IF tbool = FALSE THEN
            RETURN FALSE;
        END IF;
    END IF;
    
    /**                                                                          */ 
    /**  o   @nota Los turnos anteriores y posteriores son referentes al periodo */--
    /** <|>  No se utilizan para especificar tiempo ante o despues relativo      */--
    /** / \  al dia que se pregunta                                              */--
    /**                                                                          */--
        --                                                                           
    
    /** turnos anteriores */
    IF rc.turno_relativo_anterior IS NOT NULL THEN
        IF act.turno < pturno - rc.turno_relativo_anterior - rc.cant_turnos_relativo_anterior + 1 AND (actperiodo = rc.periodo OR rc.periodo IS NULL) THEN
            RETURN FALSE;
        END IF;
    END IF;

    /** Turnos posteriores */
    IF rc.turno_relativo_posterior IS NOT NULL THEN
        IF act.turno < pturno + rc.turno_relativo_posterior - rc.cant_turnos_relativo_posterior - 1 AND (actperiodo = rc.periodo OR rc.periodo IS NULL) THEN
            RETURN FALSE;
        END IF;
    END IF;
        
    /** Entre dias */
    IF NOT (rc.entre_dias_antes IS NULL AND rc.entre_dias_despues IS NULL) THEN -- al menos  uno de los dos debe ser no nulo
        tbool := false;
        FOR r IN SELECT * FROM periodicidad WHERE  periodo = idperiodo LOOP
            dia_hoy := dame_dia_real_planificacion(r.planificacion, r.dia) + pdia - 1;
            
            SELECT * INTO r1 FROM restriccion_real 
                WHERE actividad = act.id 
                AND (
                     (fecha >= dia_hoy - rc.entre_dias_antes OR rc.entre_dias_antes IS NULL) 
                      AND 
                     (fecha <= dia_hoy + rc.entre_dias_despues OR rc.entre_dias_despues IS NULL)
                    );
            
            IF FOUND THEN
                tbool := true;
            END IF;
            EXIT WHEN tbool = true;
        END LOOP;
        
        -- si no encuentra actividad entre dias
        IF tbool = FALSE THEN
            RETURN FALSE;
        END IF;
    END IF;

    /** Entre turnos */
    IF NOT (rc.entre_turnos_antes IS NULL AND rc.entre_turnos_despues IS NULL) THEN
        IF (act.turno < pturno - rc.entre_turnos_antes OR act.turno > pturno + rc.entre_turnos_despues) AND (actperiodo = rc.periodo OR rc.periodo IS NULL) THEN
            RETURN FALSE;
        END IF;
    END IF;

        -- el rango de dias y turnos real no tiene por que tener periodo
        -- se pregunta de forma general, puede que existan varios periodos
        -- con la misma configuracion de tiempo

        -- tampoco es obligatorio que exista el rango, puede que sea en todo el periodo

    /** En rango en el periodo */
    
    IF rc.periodo IS NOT NULL AND actperiodo <> rc.periodo THEN
        RETURN FALSE;
    END IF;
    
    IF (rc.discreto = TRUE) THEN
      IF (rc.dia_ini IS NOT NULL AND act.dia < rc.dia_ini) 
          OR (rc.dia_fin IS NOT NULL AND act.dia > rc.dia_fin)
          OR (rc.turno_ini IS NOT NULL AND act.turno < rc.turno_ini)
          OR (rc.turno_fin IS NOT NULL AND rc.turno_fin < act.turno + duracion_act) THEN
          RETURN FALSE;
      END IF;
    ELSE
      IF (rc.dia_ini IS NOT NULL AND act.dia < rc.dia_ini) 
          OR (rc.dia_fin IS NOT NULL AND act.dia > rc.dia_fin)
          OR (rc.turno_ini IS NOT NULL AND act.dia = rc.dia_ini AND act.turno < rc.turno_ini)
          OR (rc.turno_fin IS NOT NULL AND act.dia = rc.dia_fin AND rc.turno_fin < act.turno + duracion_act) THEN
          RETURN FALSE;
      END IF;
    END IF;

    /** En rango en la planificacion */
    
    hi := dame_hora_inicial_turno(actperiodo, act.turno);
    hf := hi + dame_duracion_turno_periodo(actperiodo) * duracion_act;
    
    tbool := false;
    FOR r IN SELECT * FROM periodicidad WHERE periodo = idperiodo LOOP
        dia_hoy := act.dia + pdia - 1;
        
        IF rc.discreto_exacto_planif = TRUE THEN
            IF NOT ((rc.dia_ini_planif IS NOT NULL AND dia_hoy < rc.dia_ini_planif)
                    OR (rc.dia_fin_planif IS NOT NULL AND dia_hoy > rc.dia_fin_planif)
                    OR (rc.hora_ini_planif IS NOT NULL AND hf < rc.hora_ini_planif)
                    OR (rc.hora_fin_planif IS NOT NULL AND hi > rc.hora_fin_planif)
                    ) THEN
            
            tbool := TRUE;
            
            END IF;
        ELSE
             IF NOT ((rc.dia_ini_planif IS NOT NULL AND dia_hoy < rc.dia_ini_planif)
                    OR (rc.dia_fin_planif IS NOT NULL AND dia_hoy > rc.dia_fin_planif)
                    OR (rc.hora_ini_planif IS NOT NULL AND dia_hoy = rc.dia_ini_planif AND hf < rc.hora_ini_planif)
                    OR (rc.hora_fin_planif IS NOT NULL AND dia_hoy = rc.dia_fin_planif AND hi > rc.hora_fin_planif)
                    ) THEN
            
            tbool := TRUE;
            
            END IF;
        END IF;
           
        EXIT WHEN tbool = true;
     END LOOP;
    
     IF tbool = FALSE THEN
         RETURN FALSE;
     END IF;
    
     /** Tiempo relativo anterior */

     hi := dame_hora_inicial_turno(idperiodo, pturno);
     hf := hi + dame_duracion_turno_periodo(idperiodo);
     
     IF rc.rango_tiempo_relativo_anterior_ini IS NOT NULL THEN
         tbool := false;
         FOR r IN SELECT * FROM periodicidad WHERE periodo = idperiodo LOOP
            dia_hoy := dame_dia_real_planificacion(r.planificacion, r.dia) + pdia - 1;
            
            IF rc.rango_tiempo_relativo_anterior_tamano IS NOT NULL THEN
                SELECT * INTO r1 FROM restriccion_real 
                    WHERE actividad = act.id 
                    AND NOT tiempo.moment_number(fecha,hora_fin) < tiempo.moment_number(dia_hoy,hi) - rc.rango_tiempo_relativo_anterior_ini - rango_tiempo_relativo_anterior_tamano 
                    AND NOT tiempo.moment_number(fecha,hora_ini) > tiempo.moment_number(dia_hoy,hi) - rc.rango_tiempo_relativo_anterior_ini;
            ELSE
                SELECT * INTO r1 FROM restriccion_real 
                    WHERE actividad = act.id 
                    AND NOT tiempo.moment_number(fecha,hora_ini) > tiempo.moment_number(dia_hoy,hi) - rc.rango_tiempo_relativo_anterior_ini;
            END IF;
            
            IF FOUND THEN
                tbool := true;
            END IF;
            
            EXIT WHEN tbool = true;
          END LOOP;

          IF tbool = FALSE THEN
              RETURN FALSE;
          END IF;
      END IF;
    
    /** Tiempo relativo posterior */
    
     IF rc.rango_tiempo_relativo_posterior_ini IS NOT NULL THEN
         tbool := false;
         FOR r IN SELECT * FROM periodicidad WHERE periodo = idperiodo LOOP
            dia_hoy := dame_dia_real_planificacion(r.planificacion, r.dia) + pdia - 1;
            
            IF rc.rango_tiempo_relativo_posterior_tamano IS NOT NULL THEN
                SELECT * INTO r1 FROM restriccion_real 
                    WHERE actividad = act.id 
                    AND NOT tiempo.moment_number(fecha,hora_fin) < tiempo.moment_number(dia_hoy,hi) + rc.rango_tiempo_relativo_posterior_ini
                    AND NOT tiempo.moment_number(fecha,hora_ini) > tiempo.moment_number(dia_hoy,hi) + rc.rango_tiempo_relativo_posterior_ini + rango_tiempo_relativo_posterior_tamano;
            ELSE
                SELECT * INTO r1 FROM restriccion_real 
                    WHERE actividad = act.id 
                    AND NOT tiempo.moment_number(fecha,hora_fin) < tiempo.moment_number(dia_hoy,hi) + rc.rango_tiempo_relativo_posterior_ini;
            END IF;
            
            IF FOUND THEN
                tbool := true;
            END IF;
            
            EXIT WHEN tbool = true;
          END LOOP;

          IF tbool = FALSE THEN
              RETURN FALSE;
          END IF;
      END IF;
      
     /** Entre tiempos */
    
     IF NOT (rc.entre_tiempo_antes IS NULL AND rc.entre_tiempo_despues IS NULL) THEN
         tbool := false;
         FOR r IN SELECT * FROM periodicidad WHERE periodo = idperiodo LOOP
            dia_hoy := dame_dia_real_planificacion(r.planificacion, r.dia) + pdia - 1;
            
            SELECT * INTO r1 FROM restriccion_real 
                WHERE actividad = act.id AND
                (
                 (tiempo.moment_number(fecha,hora_fin) >= tiempo.moment_number(dia_hoy,hi) - rc.entre_tiempo_antes OR rc.entre_tiempo_antes IS NULL) 
                  AND 
                 (tiempo.moment_number(fecha,hora_ini) <= tiempo.moment_number(dia_hoy,hf) + rc.entre_tiempo_despues OR rc.entre_tiempo_despues IS NULL) 
                ); 
                    
            IF FOUND THEN
                tbool := true;
            END IF;
            
            EXIT WHEN tbool = true;
          END LOOP;

          IF tbool = FALSE THEN
              RETURN FALSE;
          END IF;
      END IF;
      
    RETURN TRUE;
END;
$$;


ALTER FUNCTION public.ocurre_causa_rest_cond(rc restriccion_condicional, act actividad, idperiodo character varying, pdia integer, pturno integer, analiza_completo boolean) OWNER TO rafa;

--
-- Name: pldbg_abort_target(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pldbg_abort_target(session integer) RETURNS SETOF boolean
    LANGUAGE c STRICT
    AS '$libdir/pldbgapi', 'pldbg_abort_target';


ALTER FUNCTION public.pldbg_abort_target(session integer) OWNER TO postgres;

--
-- Name: pldbg_attach_to_port(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pldbg_attach_to_port(portnumber integer) RETURNS integer
    LANGUAGE c STRICT
    AS '$libdir/pldbgapi', 'pldbg_attach_to_port';


ALTER FUNCTION public.pldbg_attach_to_port(portnumber integer) OWNER TO postgres;

--
-- Name: pldbg_continue(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pldbg_continue(session integer) RETURNS breakpoint
    LANGUAGE c STRICT
    AS '$libdir/pldbgapi', 'pldbg_continue';


ALTER FUNCTION public.pldbg_continue(session integer) OWNER TO postgres;

--
-- Name: pldbg_create_listener(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pldbg_create_listener() RETURNS integer
    LANGUAGE c STRICT
    AS '$libdir/pldbgapi', 'pldbg_create_listener';


ALTER FUNCTION public.pldbg_create_listener() OWNER TO postgres;

--
-- Name: pldbg_deposit_value(integer, text, integer, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pldbg_deposit_value(session integer, varname text, linenumber integer, value text) RETURNS boolean
    LANGUAGE c STRICT
    AS '$libdir/pldbgapi', 'pldbg_deposit_value';


ALTER FUNCTION public.pldbg_deposit_value(session integer, varname text, linenumber integer, value text) OWNER TO postgres;

--
-- Name: pldbg_drop_breakpoint(integer, oid, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pldbg_drop_breakpoint(session integer, func oid, linenumber integer) RETURNS boolean
    LANGUAGE c STRICT
    AS '$libdir/pldbgapi', 'pldbg_drop_breakpoint';


ALTER FUNCTION public.pldbg_drop_breakpoint(session integer, func oid, linenumber integer) OWNER TO postgres;

--
-- Name: pldbg_get_breakpoints(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pldbg_get_breakpoints(session integer) RETURNS SETOF breakpoint
    LANGUAGE c STRICT
    AS '$libdir/pldbgapi', 'pldbg_get_breakpoints';


ALTER FUNCTION public.pldbg_get_breakpoints(session integer) OWNER TO postgres;

--
-- Name: pldbg_get_proxy_info(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pldbg_get_proxy_info() RETURNS proxyinfo
    LANGUAGE c STRICT
    AS '$libdir/pldbgapi', 'pldbg_get_proxy_info';


ALTER FUNCTION public.pldbg_get_proxy_info() OWNER TO postgres;

--
-- Name: pldbg_get_source(integer, oid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pldbg_get_source(session integer, func oid) RETURNS text
    LANGUAGE c STRICT
    AS '$libdir/pldbgapi', 'pldbg_get_source';


ALTER FUNCTION public.pldbg_get_source(session integer, func oid) OWNER TO postgres;

--
-- Name: pldbg_get_stack(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pldbg_get_stack(session integer) RETURNS SETOF frame
    LANGUAGE c STRICT
    AS '$libdir/pldbgapi', 'pldbg_get_stack';


ALTER FUNCTION public.pldbg_get_stack(session integer) OWNER TO postgres;

--
-- Name: pldbg_get_target_info(text, "char"); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pldbg_get_target_info(signature text, targettype "char") RETURNS targetinfo
    LANGUAGE c STRICT
    AS '$libdir/targetinfo', 'pldbg_get_target_info';


ALTER FUNCTION public.pldbg_get_target_info(signature text, targettype "char") OWNER TO postgres;

--
-- Name: pldbg_get_variables(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pldbg_get_variables(session integer) RETURNS SETOF var
    LANGUAGE c STRICT
    AS '$libdir/pldbgapi', 'pldbg_get_variables';


ALTER FUNCTION public.pldbg_get_variables(session integer) OWNER TO postgres;

--
-- Name: pldbg_select_frame(integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pldbg_select_frame(session integer, frame integer) RETURNS breakpoint
    LANGUAGE c STRICT
    AS '$libdir/pldbgapi', 'pldbg_select_frame';


ALTER FUNCTION public.pldbg_select_frame(session integer, frame integer) OWNER TO postgres;

--
-- Name: pldbg_set_breakpoint(integer, oid, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pldbg_set_breakpoint(session integer, func oid, linenumber integer) RETURNS boolean
    LANGUAGE c STRICT
    AS '$libdir/pldbgapi', 'pldbg_set_breakpoint';


ALTER FUNCTION public.pldbg_set_breakpoint(session integer, func oid, linenumber integer) OWNER TO postgres;

--
-- Name: pldbg_set_global_breakpoint(integer, oid, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pldbg_set_global_breakpoint(session integer, func oid, linenumber integer, targetpid integer) RETURNS boolean
    LANGUAGE c
    AS '$libdir/pldbgapi', 'pldbg_set_global_breakpoint';


ALTER FUNCTION public.pldbg_set_global_breakpoint(session integer, func oid, linenumber integer, targetpid integer) OWNER TO postgres;

--
-- Name: pldbg_step_into(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pldbg_step_into(session integer) RETURNS breakpoint
    LANGUAGE c STRICT
    AS '$libdir/pldbgapi', 'pldbg_step_into';


ALTER FUNCTION public.pldbg_step_into(session integer) OWNER TO postgres;

--
-- Name: pldbg_step_over(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pldbg_step_over(session integer) RETURNS breakpoint
    LANGUAGE c STRICT
    AS '$libdir/pldbgapi', 'pldbg_step_over';


ALTER FUNCTION public.pldbg_step_over(session integer) OWNER TO postgres;

--
-- Name: pldbg_wait_for_breakpoint(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pldbg_wait_for_breakpoint(session integer) RETURNS breakpoint
    LANGUAGE c STRICT
    AS '$libdir/pldbgapi', 'pldbg_wait_for_breakpoint';


ALTER FUNCTION public.pldbg_wait_for_breakpoint(session integer) OWNER TO postgres;

--
-- Name: pldbg_wait_for_target(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pldbg_wait_for_target(session integer) RETURNS integer
    LANGUAGE c STRICT
    AS '$libdir/pldbgapi', 'pldbg_wait_for_target';


ALTER FUNCTION public.pldbg_wait_for_target(session integer) OWNER TO postgres;

--
-- Name: plpgsql_oid_debug(oid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION plpgsql_oid_debug(functionoid oid) RETURNS integer
    LANGUAGE c STRICT
    AS '$libdir/plugins/plugin_debugger', 'plpgsql_oid_debug';


ALTER FUNCTION public.plpgsql_oid_debug(functionoid oid) OWNER TO postgres;

--
-- Name: posible_inicio(character varying, integer, integer, character varying, character varying[], character varying[]); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION posible_inicio(idplantilla character varying, dia integer, turno integer, idbrigada character varying, plugares character varying[], pprofesores character varying[]) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
    DECLARE c BIGINT;
        i INTEGER;
        j INTEGER;
        k INTEGER;
        t BIGINT;
        v INTEGER;
        duracion INTEGER;
        periodo VARCHAR;
        clasif VARCHAR;
        asignatura VARCHAR;
        profesores VARCHAR[];
        lugares VARCHAR[];
        cantProfes BIGINT;
        cantLugares BIGINT;
        gruporecursos VARCHAR[];
        recursos VARCHAR[];
        cantGrupoRecursos BIGINT;
        cantRecursos BIGINT;
        r record;
        malo BOOLEAN;
        puede BOOLEAN;
        exige_lugar BOOLEAN;
        exige_profesor BOOLEAN;
    BEGIN

	--RAISE NOTICE '[INFO] POSIBLE INICIO:  dia % y turno % ', dia, turno;
	
        duracion := dame_duracion_plantilla_de_actividad(idplantilla);

        --RAISE NOTICE '[INFO] Duracion obtenida % ', duracion;
        
        periodo := dame_periodo_plantilla_de_actividad(idplantilla);
        clasif := dame_clasif_plantilla_de_actividad(idplantilla);
        asignatura := dame_asignatura_plantilla_de_actividad(idplantilla);

        exige_lugar := plantilla_exige_lugar(idplantilla);
        exige_profesor := plantilla_exige_profesor(idplantilla);

        IF exige_profesor = TRUE THEN
            IF pprofesores is null THEN
                profesores := dame_lista_id_profes_asignados(idplantilla);
            ELSE
                profesores := pprofesores;
            END IF;
            
            cantProfes := matrix.get_length_of(profesores, 1);
        END IF;
        

        IF exige_lugar = TRUE THEN
            IF plugares is null THEN
                lugares := dame_lista_id_lugares_asignados(idplantilla);    
            ELSE
                lugares := plugares;
            END IF;
            cantLugares := matrix.get_length_of(lugares, 1);
        END IF;
        
        
        i := 0;
        LOOP
	    --RAISE NOTICE '[INFO] POSIBLE INICIO: comprobando restricciones para turno % ', turno + i;
	    
            EXIT WHEN i = duracion;
            
            -- comprobando que el periodo no est?estringido
            
            v:= valor_restriccion_periodo(periodo, dia, turno + i);

            IF v > 0 THEN
                RETURN FALSE;
            END IF;

            -- comprobando la disponibilidad de la clasificacion

            v:= valor_restriccion_clasif_act(clasif, periodo, dia, turno + i);

            IF v > 0 THEN
                RETURN FALSE;
            END IF;

            -- comprobando la disponibilidad de la asignatura

            v:= valor_restriccion_asignatura(asignatura, periodo, dia, turno + i);

            IF v > 0 THEN
                RETURN FALSE;
            END IF;
            
            -- compoobando la disponibilidad de la brigada

            v:= valor_restriccion_brigada(idbrigada, periodo, dia, turno + i);

            IF v > 0 THEN
                RETURN FALSE;
            END IF;
            
            i := i + 1;
        END LOOP;


        IF exige_profesor = TRUE THEN

	    --RAISE NOTICE '[INFO] POSIBLE INICIO: comprobar la disponibilidad de profesores ';
            -- comprobar la disponibilidad de profesores
            
            j := 0;

            k := 0;
            
            LOOP
                EXIT WHEN j = cantProfes;

                puede := TRUE;
                
                i := 0;
                LOOP
                    EXIT WHEN i = duracion;
                                
                    v:= valor_restriccion_profesor(profesores[j], periodo, dia, turno + i);

                    IF v > 0 THEN
                        puede := FALSE;
                        EXIT;
                    END IF;
                    i := i + 1;
                END LOOP;

                IF puede = TRUE THEN
                    k := k + 1;
                    EXIT;
                END IF;
                
                j := j + 1;
            END LOOP;

            IF k = 0 THEN
                RETURN FALSE;
            END IF;
        END IF;

        IF exige_lugar = TRUE THEN    
		--RAISE NOTICE '[INFO] POSIBLE INICIO: comprobar la disponibilidad de lugares ';
            -- comprobar la disponibilidad de lugares
            j := 0;

            k := 0;
            
            LOOP
                EXIT WHEN j = cantLugares;

                puede := TRUE;
                
                i := 0;
                LOOP
                    EXIT WHEN i = duracion;
                                
                    v := valor_restriccion_lugar(lugares[j], periodo, dia, turno + i);

                    IF v > 0 THEN
                        puede := FALSE;
                        EXIT;
                    END IF;
                    i := i + 1;
                END LOOP;

                IF puede = TRUE THEN
                    k := k + 1;
                    EXIT;
                END IF;
                
                j := j + 1;
            END LOOP;

            IF k = 0 THEN
                RETURN FALSE;
            END IF;
        END IF;

        --RAISE NOTICE '[INFO] POSIBLE INICIO: comprobar la disponibilidad de otros recursos ';
        -- comprobar la disponibilidad de otros recursos

        gruporecursos := dame_lista_id_grupos_de_recursos_asignados(idplantilla);
        cantGrupoRecursos := matrix.get_length_of(gruporecursos,1);

	-- execute matrix.echo(gruporecursos);
	
	--RAISE NOTICE '[INFO] POSIBLE INICIO: cantGrupoRecursos = % ', cantGrupoRecursos;

        i := 0;
        LOOP
	    
            EXIT WHEN i = cantGrupoRecursos;

	    --RAISE NOTICE '[INFO] POSIBLE INICIO: ... grupo recursos %', i;

            recursos := dame_lista_id_otros_recursos_asignados(gruporecursos[i]);
            cantRecursos := matrix.get_length_of(recursos, 1);

            SELECT * INTO r FROM otro_grupo_de_recursos_para_actividad WHERE id = gruporecursos[i];

            -- me preocupo solo por lo imprescindible
            
            IF r.imprescindibles = TRUE THEN
            
                j := 0;
                t := 0; -- va a contar cuantos hay disponibles para luego compararlo contra los necesarios
                
                LOOP

                    EXIT WHEN j = cantRecursos;

                    malo := FALSE;
                    
                    LOOP
                        EXIT WHEN k = duracion;
                        v := valor_restriccion_otro_recurso(recursos[j], periodo, dia, turno + k);
                    
                        IF v > 0 THEN 
                            malo := TRUE;
                            EXIT;
                        END IF;
                        
                        k:= k + 1;
                    END LOOP;

                    IF malo = FALSE THEN
                        t := t + 1;
                    END IF;
                    
                    j := j + 1;
                END LOOP;

                -- si t no alcanza los necesarios entonces no se puede,
                -- y solo basta con que uno de los grupos de recursos 
                -- no sea satisfecho para decir que no se puede

                IF t < r.necesarios THEN
                    RETURN FALSE;
                END IF;
            END IF;
            
            i := i + 1;
        END LOOP;

        RETURN 1;
    END;
$$;


ALTER FUNCTION public.posible_inicio(idplantilla character varying, dia integer, turno integer, idbrigada character varying, plugares character varying[], pprofesores character varying[]) OWNER TO postgres;

--
-- Name: quita_segun_capacidad(character varying[], character varying[]); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION quita_segun_capacidad(brigadas character varying[], lugares character varying[]) RETURNS character varying[]
    LANGUAGE plpgsql
    AS $$
    DECLARE arr VARCHAR[];
        r RECORD;
        cantLug BIGINT;
        i BIGINT;
        matricula BIGINT;
        capacidad INTEGER;
    BEGIN
        matricula := dame_matricula_total(brigadas);
        cantLug := matrix.get_length_of(lugares, 1);

	IF cantLug > 0 THEN
		i := 1;
		LOOP
		    capacidad := dame_capacidad(lugares[i]); 

		    -- si la capacidad es 0 significa que no importa o que es infinita

		    IF capacidad = 0 OR capacidad >= matricula THEN
			arr := array_append(arr, lugares[i]);
		    END IF;
		    
		    EXIT WHEN i >= cantLug;
		    i := i + 1;
		END LOOP;
        END IF;
        
        RETURN arr;
    END;
    
$$;


ALTER FUNCTION public.quita_segun_capacidad(brigadas character varying[], lugares character varying[]) OWNER TO rafa;

--
-- Name: quita_segun_prohibidos(character varying[], character varying[]); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION quita_segun_prohibidos(grupos character varying[], lugares character varying[]) RETURNS character varying[]
    LANGUAGE plpgsql
    AS $$
    DECLARE arr VARCHAR[];
        r RECORD;
        cantLug BIGINT; cantGrupos BIGINT;
        i BIGINT; j BIGINT;
        puede BOOLEAN;
    BEGIN
        
        cantLug := matrix.get_length_of(lugares, 1);
        cantGrupos := matrix.get_length_of(grupos, 1);

        IF cantLug > 0 THEN
		i := 1;
		LOOP
		    puede := TRUE;

		    IF cantGrupos >0 THEN
		    
			    j := 1;

			    LOOP
				IF es_lugar_prohibido (grupos[j], lugares[i]) THEN
				    puede := FALSE;
				    EXIT;
				END IF;
				
				EXIT WHEN j >= cantGrupos;
				j := j + 1;
			    END LOOP;

		    END IF;
		    IF puede = TRUE THEN
			arr := array_append(arr, lugares[i]);
		    END IF;
		    
		    EXIT WHEN i = cantLug;
		    i := i + 1;
		END LOOP;
        END IF;
        
        RETURN arr;
    END;
    
$$;


ALTER FUNCTION public.quita_segun_prohibidos(grupos character varying[], lugares character varying[]) OWNER TO rafa;

--
-- Name: rand(); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION rand() RETURNS double precision
    LANGUAGE sql
    AS $$SELECT random();$$;


ALTER FUNCTION public.rand() OWNER TO rafa;

--
-- Name: rango(character varying, character varying, integer, integer); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION rango(idplantilla character varying, idgrupo character varying, minimo integer, maximo integer) RETURNS trango
    LANGUAGE plpgsql
    AS $$    
    DECLARE ran TRango;
        i INTEGER; 
        rplantilla record;
        rperiodo record;
        rdesglose record;
        n INTEGER;
        arr INTEGER[];
        CD INTEGER;
        r record;
        w record;
        c INTEGER;
        da INTEGER; db INTEGER; dif INTEGER;
    BEGIN

        SELECT * INTO rplantilla FROM plantilla_de_actividad WHERE id = idplantilla;
        SELECT * INTO rdesglose FROM desglose WHERE id = rplantilla.desglose;
        SELECT * INTO rperiodo FROM periodo WHERE id = rdesglose.periodo;

        ran.ini = 1;
        CD := rperiodo.cant_dias;
        ran.fin = CD;
        n := rplantilla.orden;
        
        IF rdesglose.respetar_orden = FALSE THEN
            RETURN ran;
        END IF;
        
        arr := matrix.create_numeric_list(CD);

        FOR r IN SELECT * FROM actividad WHERE grupo = idgrupo AND dame_desglose_de_plantilla(plantilla) = rdesglose.id LOOP
            SELECT * INTO w FROM plantilla_de_actividad WHERE id = r.plantilla;
            arr[r.dia] := w.orden;
        END LOOP;

        c := matrix.get_count_of_value_in(arr, 0);

        -- SI c = 0 ninguna actividad, el rango es todo el periodo

        IF c = 1 THEN
            -- una actividad
            i := 1;
            LOOP
                IF arr[i]<>0 THEN
                    IF arr[i] < n THEN
                        ran.ini = i + minimo;
                        ran.fin = CD;
                    ELSE
                        ran.ini = 1;
                        ran.fin = i - minimo;
                    END IF;
                    
                    EXIT;
                END IF;
                EXIT WHEN i = CD;
                i := i + 1;
            END LOOP;
        END IF;

        IF c > 1 THEN
            -- mas de una actividad

            da := 0;
            db := CD + 1;

            i := 1;
            LOOP
                IF arr[i] = n - 1 AND arr[i] <> 0 THEN
                    da = i;
                    EXIT;
                END IF;
                EXIT WHEN i = CD;            
                i := i + 1;
            END LOOP;


            i := 1;
            LOOP
                IF arr[i] = n + 1 AND arr[i] <> 0 THEN
                    db = i;
                    EXIT;
                END IF;
                EXIT WHEN i = CD;            
                i := i + 1;
            END LOOP;            

            dif := db - da;

            ran.ini := da + minimo;

            IF dif <= maximo * 2 THEN
                ran.fin = db - minimo;
            ELSE
                ran.fin = da + maximo;
            END IF;
        END IF;

        RETURN ran;
    
    END;
$$;


ALTER FUNCTION public.rango(idplantilla character varying, idgrupo character varying, minimo integer, maximo integer) OWNER TO rafa;

--
-- Name: restringe_por_uso_de_otro_recurso(character varying, character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION restringe_por_uso_de_otro_recurso(idactividad character varying, idrecurso character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE 
    cant BIGINT;
    i BIGINT; j INTEGER;
    rplantilla record;
    ractividad RECORD;
    r record;
    pid varchar;
BEGIN
    SELECT * INTO ractividad FROM actividad WHERE id = idactividad;
    SELECT * INTO rplantilla FROM plantilla_de_actividad WHERE id = idplantilla;

    j := ractividad.turno;

    LOOP
       pid := crea_id_de_replica("ancoragoh","restriccion_de_otro_recurso","id","restriccion_de_otro_recurso");
       INSERT INTO restriccion_de_otro_recurso (otro_recurso, periodo, dia, turno, valor, por_actividad, actividad) VALUES (idrecurso, ractividad.periodo, ractividad.dia, j, 1, TRUE, idactividad);
       INSERT INTO restriccion_por_actividad_de_otro_recurso (restriccion_nominal, actividad) VALUES (pid, idactividad);

       EXIT WHEN j = ractividad.turno + rplantilla.duracion - 1;
       j := j + 1;
    END LOOP;
    
    EXIT WHEN i = cant;
    
END;
$$;


ALTER FUNCTION public.restringe_por_uso_de_otro_recurso(idactividad character varying, idrecurso character varying) OWNER TO rafa;

--
-- Name: restringe_segun_actividad(character varying, character varying, character varying, character varying, integer, integer, character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION restringe_segun_actividad(idactividad character varying, idplantilla character varying, idprofesor character varying, idlugar character varying, pdia integer, pturno integer, idgrupo character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE 
    pid VARCHAR;
    listaidbrg VARCHAR[];
    cant BIGINT;
    i BIGINT; j INTEGER;
    rplantilla record;
    idperiodo varchar;
    rclasificacion record;
    r record;
BEGIN

    SELECT * INTO rplantilla FROM plantilla_de_actividad WHERE id = idplantilla;
    SELECT * INTO rclasificacion FROM clasificacion_de_actividad WHERE id = rplantilla.clasificacion;
    
    idperiodo := dame_periodo_plantilla_de_actividad(idplantilla);
    -- restringir a los implicados

    -- restringiendo a las brigadas
    listaidbrg := dame_lista_id_brigadas_de_grupo(idgrupo);
    cant := matrix.get_length_of(listaidbrg, 1);

    i := 1;
    LOOP
        j := pturno;

        LOOP
            pid := crear_id_de_replica('ancoragoh','restriccion_de_brigada','id','restriccion_de_brigada');
            INSERT INTO restriccion_de_brigada (id, brigada, periodo, dia, turno, valor, por_actividad, actividad) VALUES (pid, listaidbrg[i], idperiodo, pdia, j, 1, TRUE, idactividad);
            INSERT INTO restriccion_por_actividad_de_brigada (restriccion_nominal, actividad) VALUES (pid, idactividad);
            
            EXIT WHEN j = pturno + rclasificacion.duracion - 1;
            j := j + 1;
        END LOOP;
        
        EXIT WHEN i = cant;

        i := i + 1;
    END LOOP;
    
    -- restringiendo al profesor y lugar
    j := pturno;

    LOOP
        pid := crear_id_de_replica('ancoragoh','restriccion_de_profesor','id','restriccion_de_profesor');
        INSERT INTO restriccion_de_profesor (id, profesor, periodo, dia, turno, valor, por_actividad, actividad) VALUES (pid, idprofesor, idperiodo, pdia, j, 1, TRUE, idactividad);
        INSERT INTO restriccion_por_actividad_de_profesor (restriccion_nominal, actividad) VALUES (pid, idactividad);
        
        pid := crear_id_de_replica('ancoragoh','restriccion_de_lugar','id','restriccion_de_lugar');
        INSERT INTO restriccion_de_lugar (id, lugar, periodo, dia, turno, valor, por_actividad, actividad) VALUES (pid, idlugar, idperiodo, pdia, j, 1, TRUE, idactividad);
        INSERT INTO restriccion_por_actividad_de_lugar (restriccion_nominal, actividad) VALUES (pid, idactividad);
        
        EXIT WHEN j = pturno + rclasificacion.duracion - 1;
        j := j + 1;
    END LOOP;
   
END;
$$;


ALTER FUNCTION public.restringe_segun_actividad(idactividad character varying, idplantilla character varying, idprofesor character varying, idlugar character varying, pdia integer, pturno integer, idgrupo character varying) OWNER TO rafa;

--
-- Name: sube_orden_de_plantilla(character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION sube_orden_de_plantilla(idplantilla character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
	declare r record;
		rplantilla1 record;
		rplantilla2 record;
		m integer;
		o1 integer;
		o2 integer;
	begin
		select * into rplantilla1 from plantilla_de_actividad where id = idplantilla;

		-- asegurando que este en orden las plantillas, de paso devuelve la cantidad y max
		
		m := actualiza_orden_plantillas(rplantilla1.desglose);
		
		if found then
			if rplantilla1.orden > 1 then

				-- obtengo la plantilla de arriba
				select * into rplantilla2 from plantilla_de_actividad where desglose = rplantilla1.desglose and orden = rplantilla1.orden - 1;

				-- hago el intercambio

				o1 := rplantilla1.orden;
				o2 := rplantilla2.orden;
				
				update plantilla_de_actividad set orden = m + 1, actualizacion_interna = true where id = rplantilla1.id;
				update plantilla_de_actividad set orden = o1, actualizacion_interna = true where id = rplantilla2.id;
				update plantilla_de_actividad set orden = o2, actualizacion_interna = true where id = rplantilla1.id;

				-- quitando actualizacion interna
				update plantilla_de_actividad set actualizacion_interna = false where id = rplantilla1.id or id = rplantilla2.id;
			end if;
			return true;
		end if;
		return false;
	end;
$$;


ALTER FUNCTION public.sube_orden_de_plantilla(idplantilla character varying) OWNER TO rafa;

--
-- Name: sube_prioridad_clasif(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION sube_prioridad_clasif(idclasif character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
	declare 
		r1 record;
		r2 record;
	begin
		SELECT * INTO r1 FROM clasificacion_de_actividad WHERE id = idclasif;

		IF r1.prioridad > 1 THEN
			SELECT * INTO r2 FROM clasificacion_de_actividad WHERE creador = r1.creador AND prioridad = r1.prioridad - 1;
			UPDATE clasificacion_de_actividad SET prioridad = r1.prioridad WHERE id = r2.id;
			UPDATE clasificacion_de_actividad SET prioridad = r2.prioridad WHERE id = r1.id;
		END IF;
		
		return true;
	end;
$$;


ALTER FUNCTION public.sube_prioridad_clasif(idclasif character varying) OWNER TO postgres;

--
-- Name: turnos_se_solapan(character varying, integer, integer, integer, character varying, integer, integer, integer); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION turnos_se_solapan(idperiodo1 character varying, dia1 integer, turno1 integer, duracion1 integer, idperiodo2 character varying, dia2 integer, turno2 integer, duracion2 integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
        DECLARE r1 record;
            r2 record;
            dia1 BIGINT;
            dia2 BIGINT;
            planificacion1 VARCHAR;
            planificacion2 VARCHAR;
            dia_real1 BIGINT;
            dia_real2 BIGINT;
            duracionper2 DOUBLE PRECISION;
            hora_inicial2 DOUBLE PRECISION;
            ti1 INTEGER;
            tf1 INTEGER;
            ti2 INTEGER;
            tf2 INTEGER;
            hi DOUBLE PRECISION;
            hf DOUBLE PRECISION;
        BEGIN
            planificacion1 := dame_planificacion_de_periodo(idperiodo1);
            planificacion2 := dame_planificacion_de_periodo(idperiodo2);
            dia_real1 := dame_dia_real_planificacion(planificacion1, 1);
            dia_real2 := dame_dia_real_planificacion(planificacion2, 1);

            hi := dame_hora_inicial_turno(idperiodo1, turno);
            hf := hi + dame_duracion_turno_periodo(idperiodo1) * duracion1;

            duracionper2 := dame_duracion_turno_periodo(idperiodo2);
            hora_inicial2 := dame_hora_inicial_periodo(idperiodo2);
            
            ti2 := (hi - hora_inicial2) / duracionper2 + 1;
            tf2 := (hf - hora_inicial2) / duracionper2 + 1;

            ti1 := turno2;
            tf1 := turno2 + duracion2 - 1; 

            -- verifico que se solpen segun el horario, esto es mas eficiente que recorrer
            -- cada periodicidad y preguntar lo mismo n veces

            IF tf1 < ti2 OR tf2 < ti1 THEN
                RETURN FALSE;
            END IF;
            
            -- recorro cada periodicidad del segundo por cada periodicidad del primero
            FOR r1 IN SELECT * FROM periodicidad WHERE periodo = idperiodo1 LOOP
                dia1 := dia_real1 + r1.dia - 1;
                FOR r2 IN SELECT * FROM periodicidad WHERE periodo = idperiodo2 LOOP
                    dia2 := dia_real2 + r2.dia - 1;
                    IF dia1 = dia2 THEN
                        RETURN TRUE;
                    END IF;
                END LOOP;
            END LOOP;

            RETURN FALSE;
        END;
    $$;


ALTER FUNCTION public.turnos_se_solapan(idperiodo1 character varying, dia1 integer, turno1 integer, duracion1 integer, idperiodo2 character varying, dia2 integer, turno2 integer, duracion2 integer) OWNER TO rafa;

--
-- Name: periodo; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE periodo (
    id character varying DEFAULT crear_id_de_replica('ancoragoh'::character varying, 'periodo'::character varying, 'id'::character varying, 'periodo'::character varying) NOT NULL,
    descripcion character varying NOT NULL,
    cant_dias integer DEFAULT 5,
    cant_turnos integer DEFAULT 6,
    hora_inicial double precision,
    duracion_del_turno double precision,
    planificacion character varying NOT NULL,
    CONSTRAINT periodo_cant_dias_check CHECK ((cant_dias > 0)),
    CONSTRAINT periodo_cant_turnos_check CHECK ((cant_turnos > 0))
);


ALTER TABLE public.periodo OWNER TO rafa;

--
-- Name: valor_rest_entre_config_distintas(integer[], periodo, periodo, integer, integer); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION valor_rest_entre_config_distintas(rests integer[], per1 periodo, per2 periodo, dia integer, turno integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
    DECLARE hi DOUBLE PRECISION; hf DOUBLE PRECISION;
        ti INTEGER; tf INTEGER;
        i INTEGER;
    BEGIN
        hi := (turno-1) * per1.duracion_del_turno;
        hf := hi + per1.duracion_del_turno;

        ti := (hi - per2.hora_inicial) / per2.duracion_del_turno + 1;
        tf := (hf - per2.hora_inicial) / per2.duracion_del_turno + 1;

        i := ti;
        LOOP
            IF rests[dia][i] < 1 THEN
                RETURN rests[dia][i];
            END IF;
            EXIT WHEN i = tf;
            i := i + 1;
        END LOOP;
        RETURN 0;
    END;
$$;


ALTER FUNCTION public.valor_rest_entre_config_distintas(rests integer[], per1 periodo, per2 periodo, dia integer, turno integer) OWNER TO rafa;

--
-- Name: valor_restriccion_asignatura(character varying, character varying, integer, integer); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION valor_restriccion_asignatura(id character varying, idperiodo character varying, pdia integer, pturno integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
        BEGIN
            RETURN valor_restriccion_generica('ASIGNATURA',id, idperiodo, pdia, pturno, '*');
        END;
        
    $$;


ALTER FUNCTION public.valor_restriccion_asignatura(id character varying, idperiodo character varying, pdia integer, pturno integer) OWNER TO rafa;

--
-- Name: valor_restriccion_brigada(character varying, character varying, integer, integer); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION valor_restriccion_brigada(id character varying, idperiodo character varying, pdia integer, pturno integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
        DECLARE v INTEGER;
        BEGIN
            v := valor_restriccion_generica('BRIGADA',id, idperiodo, pdia, pturno, '*');
            
            IF v = 0 THEN
                v := valor_restriccion_heredada('BRIGADA', id, idperiodo, pdia, pturno);
            END IF;
            
            IF v = 0 THEN
                v := valor_restriccion_condicional('BRIGADA', id, idperiodo, pdia, pturno);
            END IF;
            
            RETURN v;
        END;
        
    $$;


ALTER FUNCTION public.valor_restriccion_brigada(id character varying, idperiodo character varying, pdia integer, pturno integer) OWNER TO rafa;

--
-- Name: valor_restriccion_clasif_act(character varying, character varying, integer, integer); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION valor_restriccion_clasif_act(id character varying, idperiodo character varying, pdia integer, pturno integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
        BEGIN
            RETURN valor_restriccion_generica('CLASIFACT',id, idperiodo, pdia, pturno, '*');
        END;
        
    $$;


ALTER FUNCTION public.valor_restriccion_clasif_act(id character varying, idperiodo character varying, pdia integer, pturno integer) OWNER TO rafa;

--
-- Name: valor_restriccion_condicional(character varying, character varying, character varying, integer, integer); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION valor_restriccion_condicional(tipo_consec character varying, id_consec character varying, idperiodo character varying, pdia integer, pturno integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
        DECLARE r record;
            ract record;
            c BIGINT;
        BEGIN
            -- se analizan las restricciones condicionales
            -- donde el implicado se encuentren en las consecuencias o
            -- postcondiciones de la restriccion (tipo regla)

            FOR r IN SELECT * FROM restriccion_condicional 
                            WHERE activa = TRUE AND dame_tipo_consec_rest_cond(id) = tipo_consec AND (consec_periodo = idperiodo OR consec_periodo IS NULL) LOOP
              
                IF siempre = FALSE THEN
                    IF (r.discreto = TRUE) THEN
                      CONTINUE WHEN (rcdia_ini IS NOT NULL AND act.dia < r.dia_ini) 
                          OR (r.dia_fin IS NOT NULL AND act.dia > r.dia_fin)
                          OR (r.turno_ini IS NOT NULL AND act.turno < r.turno_ini)
                          OR (r.turno_fin IS NOT NULL AND r.turno_fin < act.turno + duracion_act);
                    ELSE
                      CONTINUE WHEN (r.dia_ini IS NOT NULL AND act.dia < r.dia_ini) 
                          OR (r.dia_fin IS NOT NULL AND act.dia > r.dia_fin)
                          OR (r.turno_ini IS NOT NULL AND act.dia = r.dia_ini AND act.turno < r.turno_ini)
                          OR (r.turno_fin IS NOT NULL AND act.dia = r.dia_fin AND r.turno_fin < act.turno + duracion_act);
                    END IF;
                END IF;
                
                -- ahora se busca si la causa existe

                c := 0;
                
                FOR ract IN SELECT * FROM actividad WHERE 
                    (r.clasif_act = dame_clasif_plantilla_de_actividad(act.plantilla) OR rc.clasif_act IS NULL) AND
                    (r.asig = dame_asignatura_plantilla_de_actividad(act.plantilla) OR r.asig IS NULL) AND
                    (matrix.get_pos_of(rc.brigada, dame_lista_id_brigadas_de_grupo(act.grupo)) > -1 OR r.brigada IS NULL) AND
                    (r.profesor = act.profesor OR r.profesor IS NULL) AND
                    (r.lugar = act.lugar OR r.lugar IS NULL) AND
                    (r.especialidad = dame_especialidad_de_asignatura(dame_asignatura_plantilla_de_actividad(act.plantilla)) OR r.especialidad IS NULL) AND
                    (r.nivel = dame_nivel_de_asignatura(dame_asignatura_plantilla_de_actividad(act.plantilla)) OR r.nivel IS NULL) AND
                    (r.periodo = actperiodo OR r.periodo IS NULL) LOOP
                    
                
                    IF ocurre_causa_rest_cond(r, ract, pdia, pturno, FALSE) THEN
                        c := c + 1;
                    END IF;
                    
                END LOOP;

                -- uno de los siguientes 3 IF debe entrar
                IF r.cant_exa IS NOT NULL THEN
                    CONTINUE WHEN c <> r.cant_exa;            
                END IF;

                IF r.cant_min IS NOT NULL THEN
                    CONTINUE WHEN c < r.cant_exa;            
                END IF;

                IF r.cant_max IS NOT NULL THEN
                    CONTINUE WHEN c > r.cant_exa;            
                END IF;

                -- si no se cumplen la cantidad de casos 
                -- en la causa debe saltarse lo siguiente
                -- y continuar a la proxima restriccion condicional
                
                -- si al menos una restriccion se cumple ...

                RETURN r.valor;

            END LOOP;
            
            RETURN 0;
        END;
    $$;


ALTER FUNCTION public.valor_restriccion_condicional(tipo_consec character varying, id_consec character varying, idperiodo character varying, pdia integer, pturno integer) OWNER TO rafa;

--
-- Name: valor_restriccion_especialidad(character varying, character varying, integer, integer); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION valor_restriccion_especialidad(id character varying, idperiodo character varying, pdia integer, pturno integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
        BEGIN
            RETURN valor_restriccion_generica('ESPECIALIDAD',id, idperiodo, pdia, pturno, '*');
        END;
        
    $$;


ALTER FUNCTION public.valor_restriccion_especialidad(id character varying, idperiodo character varying, pdia integer, pturno integer) OWNER TO rafa;

--
-- Name: valor_restriccion_generica(character varying, character varying, character varying, integer, integer, character varying); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION valor_restriccion_generica(ptipo character varying, id character varying, idperiodo character varying, pdia integer, pturno integer, tipo_restricc character varying) RETURNS integer
    LANGUAGE plpgsql
    AS $$
        DECLARE r record;
            rperiodo record;
            rper record;
            r1 record;
            r2 record;
            dia_analizando INTEGER;
            hi DOUBLE PRECISION; hf DOUBLE PRECISION;
            ti INTEGER; tf INTEGER;
            i INTEGER;
            per1 record;
            tipo VARCHAR;
        BEGIN
            
            -- restricciones en el periodo

            tipo := upper(ptipo);

            IF tipo = 'PERIODO' THEN
                SELECT valor INTO r from restriccion_de_periodo where periodo = id and dia = pdia and turno = pturno; 
            END IF;
            
            IF tipo = 'ASIGNATURA' THEN
                SELECT valor INTO r from restriccion_de_asignatura where asignatura = id AND periodo = idperiodo and dia = pdia and turno = pturno;
            END IF;

            IF tipo = 'BRIGADA' THEN
                SELECT valor INTO r from restriccion_de_brigada where brigada = id AND periodo = idperiodo and dia = pdia and turno = pturno AND (tipo_restricc = '*' OR (tipo_restricc = 'ACTIVIDAD' and por_actividad = TRUE) or (tipo_restricc = 'RESTRICCION' and por_actividad = FALSE));
            END IF;

            IF tipo = 'CLASIFACT' THEN
                SELECT valor INTO r from restriccion_de_clasif_act where clasificacion = id AND periodo = idperiodo and dia = pdia and turno = pturno;
            END IF;

            IF tipo = 'ESPECIALIDAD' THEN
                SELECT valor INTO r from restriccion_de_especialidad where especialidad = id AND periodo = idperiodo and dia = pdia and turno = pturno;
            END IF;

            IF tipo = 'LUGAR' THEN
                SELECT valor INTO r from restriccion_de_lugar where lugar = id AND periodo = idperiodo and dia = pdia and turno = pturno AND (tipo_restricc = '*' OR (tipo_restricc = 'ACTIVIDAD' and por_actividad = TRUE) or (tipo_restricc = 'RESTRICCION' and por_actividad = FALSE));
            END IF;

            IF tipo = 'OTRORECURSO' THEN
                SELECT valor INTO r from restriccion_de_otro_recurso where otro_recurso = id AND periodo = idperiodo and dia = pdia and turno = pturno AND (tipo_restricc = '*' OR (tipo_restricc = 'ACTIVIDAD' and por_actividad = TRUE) or (tipo_restricc = 'RESTRICCION' and por_actividad = FALSE));
            END IF;

            IF tipo = 'PROFESOR' THEN
                SELECT valor INTO r from restriccion_de_profesor where profesor = id AND periodo = idperiodo and dia = pdia and turno = pturno AND (tipo_restricc = '*' OR (tipo_restricc = 'ACTIVIDAD' and por_actividad = TRUE) or (tipo_restricc = 'RESTRICCION' and por_actividad = FALSE));
            END IF;

            IF FOUND THEN
                RETURN r.valor;
            END IF;
            
            /** @nota: Ahora se busca en las restricciones reales. El codigo anterior puede */
            /** quitarse y entonces recorrer todas las restricciones reales,                */
            /** pero se deja para optimizar la busqueda y se recrre entonces despues las    */
            /** demas periodicidades, pues basta preguntar por el turno de un periodo y no  */
            /** por todas sus periodicidades para saber si esta restringido                 */
                        
            -- restricciones en otros periodos
            
            SELECT * INTO rperiodo FROM periodo WHERE id = idperiodo;

            hi := dame_hora_inicial_turno(rperiodo.id, pturno);
            hf := hi + rperiodo.duracion_del_turno;

            -- se analizan las periodicidades (recorriendo la temporada)
            FOR r IN SELECT * FROM periodicidad WHERE periodo <> idperiodo LOOP

                -- se calcula la fecha real
                dia_analizando := dame_dia_real_planificacion(rperiodo.planificacion, r.dia + pdia - 1);
                
                -- se busca en las restricciones reales
                
                IF tipo = 'PERIODO' THEN
                    SELECT * INTO r 
                        FROM restriccion_real_de_periodo 
                        WHERE fecha = dia_analizando AND NOT (hora_inicial > hf OR hora_final < hi);
                        IF FOUND THEN
				RETURN 1;
			END IF;
                END IF;
                
                IF tipo = 'ASIGNATURA' THEN
                    SELECT * INTO r 
                        FROM restriccion_real_de_asignatura
                        WHERE fecha = dia_analizando AND NOT (hora_inicial > hf OR hora_final < hi);             
                        IF FOUND THEN
				RETURN 1;
			END IF; 
                END IF;

                IF tipo = 'BRIGADA' THEN
                    SELECT * INTO r 
                        FROM restriccion_real_de_brigada 
                        WHERE fecha = dia_analizando AND NOT (hora_inicial > hf OR hora_final < hi)
                        AND (tipo_restricc = '*' OR (tipo_restricc = 'ACTIVIDAD' and por_actividad = TRUE) or (tipo_restricc = 'RESTRICCION' and por_actividad = FALSE));
                        IF FOUND THEN
				RETURN 1;
			END IF;
                END IF;

                IF tipo = 'CLASIFACT' THEN
                    SELECT * INTO r 
                        FROM restriccion_real_de_clasif_act
                        WHERE fecha = dia_analizando AND NOT (hora_inicial > hf OR hora_final < hi); 
                        IF FOUND THEN
				RETURN 1;
			END IF;                
                END IF;

                IF tipo = 'ESPECIALIDAD' THEN
                    SELECT * INTO r 
                        FROM restriccion_real_de_especialidad
                        WHERE fecha = dia_analizando AND NOT (hora_inicial > hf OR hora_final < hi);  
                        IF FOUND THEN
				RETURN 1;
			END IF;               
                END IF;

                IF tipo = 'LUGAR' THEN
                    SELECT * INTO r 
                        FROM restriccion_real_de_lugar 
                        WHERE fecha = dia_analizando AND NOT (hora_inicial > hf OR hora_final < hi)
                        AND (tipo_restricc = '*' OR (tipo_restricc = 'ACTIVIDAD' and por_actividad = TRUE) or (tipo_restricc = 'RESTRICCION' and por_actividad = FALSE));
                        IF FOUND THEN
				RETURN 1;
			END IF;
                END IF;

                IF tipo = 'OTRORECURSO' THEN
                    SELECT * INTO r 
                        from restriccion_real_de_otro_recurso 
                        WHERE fecha = dia_analizando AND NOT (hora_inicial > hf OR hora_final < hi)
                        AND (tipo_restricc = '*' OR (tipo_restricc = 'ACTIVIDAD' and por_actividad = TRUE) or (tipo_restricc = 'RESTRICCION' and por_actividad = FALSE));
                        IF FOUND THEN
				RETURN 1;
			END IF;
                END IF;

                IF tipo = 'PROFESOR' THEN
                    SELECT * INTO r 
                        from restriccion_real_de_profesor 
                        WHERE fecha = dia_analizando AND NOT (hora_inicial > hf OR hora_final < hi)
                        AND (tipo_restricc = '*' OR (tipo_restricc = 'ACTIVIDAD' and por_actividad = TRUE) or (tipo_restricc = 'RESTRICCION' and por_actividad = FALSE));
                        IF FOUND THEN
				RETURN 1;
			END IF;
                END IF;

                /*IF FOUND THEN
                    RETURN r2.valor;
                END IF;*/
            END LOOP;    

            RETURN 0;
            /**
            -- se analizan las periodicidades (recorriendo la temporada)
            FOR r IN SELECT * FROM periodicidad WHERE periodo = idperiodo LOOP

                dia_analizando := r.dia + pdia - 1;
                 
                -- se analizan los otros periodos

                FOR r1 IN SELECT * FROM periodicidad WHERE periodo <> idperiodo AND dia_analizando >= dia AND dia_analizando <= dia + dame_cant_dias(periodo) - 1 LOOP


                    -- hay que normalizar las configuraciones de tiempo de ambos periodos ...
                    
                    SELECT * INTO per1 FROM periodo WHERE id = r1.periodo;
                    
                    hi := dame_hora_inicial_turno(rperiodo.id, pturno);
                    hf := hi + rperiodo.duracion_del_turno;

                    ti := (hi - per1.hora_inicial) / per1.duracion + 1;
                    tf := (hf - per1.hora_inicial) / per1.duracion + 1;

                    -- para despues poder questionar las restricciones del segundo

                    -- nota: el dia a questionar es:  dia_analizando - r1.dia + 1
                    
                    i := ti;
                    LOOP

                        IF tipo = 'PERIODO' THEN
                            SELECT valor INTO r from restriccion_de_periodo where periodo = r1.periodo and dia = dia_analizando - r1.dia + 1  and turno = i;
                        END IF;
                        
                        IF tipo = 'ASIGNATURA' THEN
                            SELECT valor INTO r from restriccion_de_asignatura where asignatura = id AND periodo = r1.periodo and dia = dia_analizando - r1.dia + 1 and turno = i;
                        END IF;

                        IF tipo = 'BRIGADA' THEN
                            SELECT valor INTO r from restriccion_de_brigada where brigada = id AND periodo = r1.periodo and dia = dia_analizando - r1.dia + 1 and turno = i AND (tipo_restricc = '*' OR (tipo_restricc = 'ACTIVIDAD' and por_actividad = TRUE) or (tipo_restricc = 'RESTRICCION' and por_actividad = FALSE));
                        END IF;

                        IF tipo = 'CLASIFACT' THEN
                            SELECT valor INTO r from restriccion_de_clasif_act where clasif_act = id AND periodo = r1.periodo and dia = dia_analizando - r1.dia + 1 and turno = i;
                        END IF;

                        IF tipo = 'ESPECIALIDAD' THEN
                            SELECT valor INTO r from restriccion_de_especialidad where especialidad = id AND periodo = r1.periodo and dia = dia_analizando - r1.dia + 1 and turno = i;
                        END IF;

                        IF tipo = 'LUGAR' THEN
                            SELECT valor INTO r from restriccion_de_lugar where lugar = id AND periodo = r1.periodo and dia = dia_analizando - r1.dia + 1 and turno = i AND (tipo_restricc = '*' OR (tipo_restricc = 'ACTIVIDAD' and por_actividad = TRUE) or (tipo_restricc = 'RESTRICCION' and por_actividad = FALSE));
                        END IF;

                        IF tipo = 'OTRORECURSO' THEN
                            SELECT valor INTO r from restriccion_de_otro_recurso where otro_recurso = id AND periodo = r1.periodo and dia = dia_analizando - r1.dia + 1 and turno = i AND (tipo_restricc = '*' OR (tipo_restricc = 'ACTIVIDAD' and por_actividad = TRUE) or (tipo_restricc = 'RESTRICCION' and por_actividad = FALSE));
                        END IF;

                        IF tipo = 'PROFESOR' THEN
                            SELECT valor INTO r from restriccion_de_profesor where profesor = id AND periodo = r1.periodo and dia = dia_analizando - r1.dia + 1 and turno = i AND (tipo_restricc = '*' OR (tipo_restricc = 'ACTIVIDAD' and por_actividad = TRUE) or (tipo_restricc = 'RESTRICCION' and por_actividad = FALSE));
                        END IF;

                        IF FOUND THEN
                            RETURN r2.valor;
                        END IF;
                        
                        EXIT WHEN i = tf;
                        i := i + 1;
                    END LOOP;
                    
                END LOOP;
            
            END LOOP;*/
            
            RETURN 0;
            
        END;
    $$;


ALTER FUNCTION public.valor_restriccion_generica(ptipo character varying, id character varying, idperiodo character varying, pdia integer, pturno integer, tipo_restricc character varying) OWNER TO rafa;

--
-- Name: valor_restriccion_heredada(character varying, character varying, character varying, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION valor_restriccion_heredada(tipo_hijo character varying, id_hijo character varying, idperiodo character varying, pdia integer, pturno integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
        DECLARE th VARCHAR; 
            r record;
            v INTEGER;
            r1 record;
            otroid VARCHAR;
        BEGIN
            th := upper(tipo_hijo);

            -- ANALIZANDO LOS PADRES
            -- si algun padre est?estringido de cualquiera de las formas
            -- entonces el hijo tambien lo esta
            
            FOR r IN SELECT * FROM herencia_de_restricciones 
                WHERE activa = TRUE AND (dame_tipo_hijo_hrt(id) = th) 
                    AND ((hijo_brigada = id_hijo AND th = 'BRIGADA') 
                        OR (hijo_profesor = id_hijo AND th = 'PROFESOR')
                        OR (hijo_lugar = id_hijo AND th = 'LUGAR')
                        OR (hijo_otro_recurso = id_hijo AND th = 'OTRORECURSO')
                        )
                        LOOP

                otroid := iif(th = 'BRIGADA', r.padre_brigada, '');
                otroid := iif(th = 'PROFESOR', r.padre_profesor, '');
                otroid := iif(th = 'LUGAR', r.padre_lugar, '');
                otroid := iif(th = 'OTRORECURSO', r.padre_otro_recurso, '');
                
                v := valor_restriccion_generica(dame_tipo_padre_hrt(r.id), otroid, idperiodo, pdia, pturno, '*');

                IF v > 0 THEN

                    SELECT * INTO r1 FROM excepcion_de_hrt WHERE herencia = r.id AND periodo = idperiodo AND dia = pdia AND turno = pturno;

                    IF NOT FOUND THEN
                        RETURN v;
                    END IF;
                    
                END IF;

            END LOOP;

            -- ANALIZANDO LOS HIJOS
            -- si algn hijo esta restringido por actividad entonces el padre esta
            -- restringido
            
            FOR r IN SELECT * FROM herencia_de_restricciones 
                WHERE (dame_tipo_padre_hrt(id) = th) 
                    AND ((padre_brigada = id_hijo AND th = 'BRIGADA') 
                        OR (padre_profesor = id_hijo AND th = 'PROFESOR')
                        OR (padre_lugar = id_hijo AND th = 'LUGAR')
                        OR (padre_otro_recurso = id_hijo AND th = 'OTRORECURSO')
                        )
                        LOOP

                otroid := iif(th = 'BRIGADA', r.hijo_brigada, '');
                otroid := iif(th = 'PROFESOR', r.hijo_profesor, '');
                otroid := iif(th = 'LUGAR', r.hijo_lugar, '');
                otroid := iif(th = 'OTRORECURSO', r.hijo_otro_recurso, '');
                
                v := valor_restriccion_generica(dame_tipo_hijo_hrt(r.id), otroid, idperiodo, pdia, pturno, 'ACTIVIDAD');

                IF v > 0 THEN

                    SELECT * INTO r1 FROM excepcion_de_hrt WHERE herencia = r.id AND periodo = idperiodo AND dia = pdia AND turno = pturno;

                    IF NOT FOUND THEN
                        RETURN v;
                    END IF;
                    
                END IF;

            END LOOP;

            RETURN 0;
        END;
    $$;


ALTER FUNCTION public.valor_restriccion_heredada(tipo_hijo character varying, id_hijo character varying, idperiodo character varying, pdia integer, pturno integer) OWNER TO postgres;

--
-- Name: valor_restriccion_lugar(character varying, character varying, integer, integer); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION valor_restriccion_lugar(id character varying, idperiodo character varying, pdia integer, pturno integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
        DECLARE v INTEGER;
        BEGIN
            v := valor_restriccion_generica('LUGAR', id, idperiodo, pdia, pturno, '*');

            IF v = 0 THEN
                v := valor_restriccion_heredada('LUGAR', id, idperiodo, pdia, pturno);
            END IF;

            IF v = 0 THEN
                v := valor_restriccion_condicional('LUGAR', id, idperiodo, pdia, pturno);
            END IF;
            
            RETURN v;
        END;
        
    $$;


ALTER FUNCTION public.valor_restriccion_lugar(id character varying, idperiodo character varying, pdia integer, pturno integer) OWNER TO rafa;

--
-- Name: valor_restriccion_periodo(character varying, integer, integer); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION valor_restriccion_periodo(idperiodo character varying, pdia integer, pturno integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
        BEGIN
            RETURN valor_restriccion_generica('PERIODO', idperiodo, '', pdia, pturno, '*');            
        END;
    $$;


ALTER FUNCTION public.valor_restriccion_periodo(idperiodo character varying, pdia integer, pturno integer) OWNER TO rafa;

--
-- Name: valor_restriccion_profesor(character varying, character varying, integer, integer); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION valor_restriccion_profesor(id character varying, idperiodo character varying, pdia integer, pturno integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
        DECLARE v INTEGER;
        BEGIN
            v := valor_restriccion_generica('PROFESOR', id, idperiodo, pdia, pturno, '*');

            IF v = 0 THEN
                v := valor_restriccion_heredada('PROFESOR', id, idperiodo, pdia, pturno);
            END IF;

            IF v = 0 THEN
                v := valor_restriccion_condicional('PROFESOR', id, idperiodo, pdia, pturno);
            END IF;
            
            RETURN v;
        END;
        
    $$;


ALTER FUNCTION public.valor_restriccion_profesor(id character varying, idperiodo character varying, pdia integer, pturno integer) OWNER TO rafa;

--
-- Name: valor_zpriori(character varying, character varying, integer, integer); Type: FUNCTION; Schema: public; Owner: rafa
--

CREATE FUNCTION valor_zpriori(clasif character varying, periodo character varying, dia integer, turno integer) RETURNS integer
    LANGUAGE sql
    AS $_$
        SELECT valor from zpriori where clasificacion = $1 and periodo = $2 and dia = $3 and turno = $4
    $_$;


ALTER FUNCTION public.valor_zpriori(clasif character varying, periodo character varying, dia integer, turno integer) OWNER TO rafa;

SET search_path = seguridad, pg_catalog;

--
-- Name: check_host(character varying, character varying); Type: FUNCTION; Schema: seguridad; Owner: rafa
--

CREATE FUNCTION check_host(pusuario character varying, pip character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
	declare r record;
	begin
		select * into r from seguridad.host where usuario = pusuario and ip = ip;

		if found then
			return true;
		end if;
		
		return false;
	end;
$$;


ALTER FUNCTION seguridad.check_host(pusuario character varying, pip character varying) OWNER TO rafa;

--
-- Name: tiene_permiso(character varying, character varying); Type: FUNCTION; Schema: seguridad; Owner: rafa
--

CREATE FUNCTION tiene_permiso(pusuario character varying, ppermiso character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
	DECLARE r RECORD;
	BEGIN
		SELECT * INTO r FROM seguridad.permiso 
            INNER JOIN (seguridad.rol_de_usuario INNER JOIN seguridad.usuario ON seguridad.rol_de_usuario.usuario = seguridad.usuario.id)
            ON seguridad.rol_de_usuario.rol = seguridad.permiso.rol 
            WHERE seguridad.permiso.permiso = ppermiso AND seguridad.usuario.id = pusuario;

		IF FOUND THEN
			return true;
		END IF;
		
		return false;
	END;
$$;


ALTER FUNCTION seguridad.tiene_permiso(pusuario character varying, ppermiso character varying) OWNER TO rafa;

SET search_path = tiempo, pg_catalog;

--
-- Name: countdays_of_month(integer); Type: FUNCTION; Schema: tiempo; Owner: rafa
--

CREATE FUNCTION countdays_of_month(m integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
    DECLARE d INTEGER;
    BEGIN
        d:=31;
        
        IF (m=4 or m=6 or m=9 or m=11) THEN
            d:=30;
        END IF;
        
        IF (m=2) THEN
            d:=28;
        END IF;
        
        RETURN d;
    END;
$$;


ALTER FUNCTION tiempo.countdays_of_month(m integer) OWNER TO rafa;

--
-- Name: FUNCTION countdays_of_month(m integer); Type: COMMENT; Schema: tiempo; Owner: rafa
--

COMMENT ON FUNCTION countdays_of_month(m integer) IS 'RETURNS count of days of specificic month';


--
-- Name: current_hour_number(); Type: FUNCTION; Schema: tiempo; Owner: rafa
--

CREATE FUNCTION current_hour_number() RETURNS double precision
    LANGUAGE plpgsql
    AS $$
    DECLARE ahora timestamp;
        hora INTEGER;
        minuto INTEGER;
        segundo INTEGER;
        h DOUBLE PRECISION;
        
    BEGIN
        ahora := now();
        hora := EXTRACT(HOUR FROM ahora);
        minuto := EXTRACT(MINUTE FROM ahora);
        segundo := trunc(EXTRACT(SECOND FROM ahora));

        h := tiempo.hour_to_number(hora,minuto,segundo);
        
        RETURN h;

    END;
$$;


ALTER FUNCTION tiempo.current_hour_number() OWNER TO rafa;

--
-- Name: date_number_from_moment_number(double precision); Type: FUNCTION; Schema: tiempo; Owner: rafa
--

CREATE FUNCTION date_number_from_moment_number(m double precision) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
    BEGIN
        RETURN trunc(m / 864) + 1;
    END;
$$;


ALTER FUNCTION tiempo.date_number_from_moment_number(m double precision) OWNER TO rafa;

--
-- Name: date_to_number(integer, integer, integer); Type: FUNCTION; Schema: tiempo; Owner: rafa
--

CREATE FUNCTION date_to_number(d integer, m integer, a integer) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
    DECLARE cd INTEGER;
    
    BEGIN
        -- cantidad de dias antes del mes a partir del 1ero de enero
        cd := tiempo.day_number(d,m,a);

        -- cantidad de dias a partir del 1ero enero del 2000
        RETURN (a - 2000) * 365 + cd + (a - 2000) / 4 + bool_to_int(tiempo.is_leap_year(a) = FALSE);
    END;
$$;


ALTER FUNCTION tiempo.date_to_number(d integer, m integer, a integer) OWNER TO rafa;

--
-- Name: FUNCTION date_to_number(d integer, m integer, a integer); Type: COMMENT; Schema: tiempo; Owner: rafa
--

COMMENT ON FUNCTION date_to_number(d integer, m integer, a integer) IS 'RETURNS consecutive number of date';


--
-- Name: day_number(integer, integer, integer); Type: FUNCTION; Schema: tiempo; Owner: rafa
--

CREATE FUNCTION day_number(d integer, m integer, a integer) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
    DECLARE cd INTEGER;
	    day_began integer[12];
    
    BEGIN
        -- cantidad de dias antes del mes a partir del 1ero de enero
        cd := 0;

        day_began[1] := 1;
        day_began[2] := 31 + 1;
        day_began[3] := 31 + 28 + 1;
        day_began[4] := 31 + 28 + 31 + 1;
        day_began[5] := 31 + 28 + 31 + 30 + 1;
        day_began[6] := 31 + 28 + 31 + 30 + 31 + 1;
        day_began[7] := 31 + 28 + 31 + 30 + 31 + 30 + 1;
        day_began[8] := 31 + 28 + 31 + 30 + 31 + 30 + 31 + 1;
        day_began[9] := 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 1;
        day_began[10] := 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 1;
        day_began[11] := 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + 1;
        day_began[12] := 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + 30 + 1;

        cd := day_began[m] + d -1;

        -- si es bisiesto y la fecha es despues de febrero se le aumenta un dia
        IF (tiempo.is_leap_year(a) = TRUE and m > 2) THEN
            cd := cd + 1;
        END IF;
        
        RETURN cd;
    END;
$$;


ALTER FUNCTION tiempo.day_number(d integer, m integer, a integer) OWNER TO rafa;

--
-- Name: FUNCTION day_number(d integer, m integer, a integer); Type: COMMENT; Schema: tiempo; Owner: rafa
--

COMMENT ON FUNCTION day_number(d integer, m integer, a integer) IS 'RETURNS the consecutive number of day';


--
-- Name: hour_number_from_date_number(double precision); Type: FUNCTION; Schema: tiempo; Owner: rafa
--

CREATE FUNCTION hour_number_from_date_number(m double precision) RETURNS double precision
    LANGUAGE plpgsql
    AS $$
    BEGIN
        RETURN m - (trunc(m / 864)) * 864;
    END;
$$;


ALTER FUNCTION tiempo.hour_number_from_date_number(m double precision) OWNER TO rafa;

--
-- Name: hour_to_number(integer, integer, integer); Type: FUNCTION; Schema: tiempo; Owner: rafa
--

CREATE FUNCTION hour_to_number(h integer, m integer, s integer) RETURNS double precision
    LANGUAGE plpgsql
    AS $$
    BEGIN
        RETURN h * 36 + m * 0.6 + s * 0.01;
    END;
$$;


ALTER FUNCTION tiempo.hour_to_number(h integer, m integer, s integer) OWNER TO rafa;

--
-- Name: FUNCTION hour_to_number(h integer, m integer, s integer); Type: COMMENT; Schema: tiempo; Owner: rafa
--

COMMENT ON FUNCTION hour_to_number(h integer, m integer, s integer) IS 'Convert hour to number';


--
-- Name: is_leap_year(integer); Type: FUNCTION; Schema: tiempo; Owner: rafa
--

CREATE FUNCTION is_leap_year(pyear integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
    BEGIN
        IF mod(pyear, 4) = 0 and mod(pyear, 100) <> 0 or mod(pyear, 400) = 0 THEN 
            RETURN TRUE;
        END IF;
        RETURN FALSE;
    END;
$$;


ALTER FUNCTION tiempo.is_leap_year(pyear integer) OWNER TO rafa;

--
-- Name: FUNCTION is_leap_year(pyear integer); Type: COMMENT; Schema: tiempo; Owner: rafa
--

COMMENT ON FUNCTION is_leap_year(pyear integer) IS 'RETURN TRUE IF is a leap year';


--
-- Name: moment_now(); Type: FUNCTION; Schema: tiempo; Owner: rafa
--

CREATE FUNCTION moment_now() RETURNS double precision
    LANGUAGE plpgsql
    AS $$
    DECLARE ahora timestamp;
        f BIGINT;
        h DOUBLE PRECISION;
        
    BEGIN

        f := tiempo.today_number();
        h := tiempo.current_hour_number();
        
        RETURN tiempo.moment_number(f, h);

    END;
$$;


ALTER FUNCTION tiempo.moment_now() OWNER TO rafa;

--
-- Name: moment_number(bigint, double precision); Type: FUNCTION; Schema: tiempo; Owner: rafa
--

CREATE FUNCTION moment_number(fecha bigint, hora double precision) RETURNS double precision
    LANGUAGE sql
    AS $_$SELECT ($1 - 1) * 864 + $2;$_$;


ALTER FUNCTION tiempo.moment_number(fecha bigint, hora double precision) OWNER TO rafa;

--
-- Name: month_from_day_number(integer, integer); Type: FUNCTION; Schema: tiempo; Owner: rafa
--

CREATE FUNCTION month_from_day_number(n integer, a integer) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
    DECLARE cd INTEGER;
        x INTEGER;
    BEGIN
        x := bool_to_int(tiempo.is_leap_year(a));
        
        cd := 1 + bool_to_int(n > 31) + bool_to_int(n > 59 + x) + bool_to_int(n > 90 + x) + bool_to_int(n > 120 + x);
        cd := cd + bool_to_int(n > 151 + x) + bool_to_int(n > 181 + x) + bool_to_int(n > 212 + x) + bool_to_int(n > 243 + x);
        cd := cd + bool_to_int(n > 273 + x) + bool_to_int (n > 304 + x) + bool_to_int(n > 334 + x);

        RETURN cd;
    END;
$$;


ALTER FUNCTION tiempo.month_from_day_number(n integer, a integer) OWNER TO rafa;

--
-- Name: FUNCTION month_from_day_number(n integer, a integer); Type: COMMENT; Schema: tiempo; Owner: rafa
--

COMMENT ON FUNCTION month_from_day_number(n integer, a integer) IS 'RETURNS month from consecutive number of date';


--
-- Name: number_to_date(bigint); Type: FUNCTION; Schema: tiempo; Owner: rafa
--

CREATE FUNCTION number_to_date(n bigint) RETURNS ancora_date
    LANGUAGE plpgsql
    AS $$
    DECLARE f tiempo.ancora_date;
        cd INTEGER;
        b INTEGER;
    BEGIN
        IF (n<=366) THEN
            f.a = 2000;
        ELSE
            f.a := 2000 + trunc(n / 365.25);
        END IF;
        
        IF (n<=366) THEN
            cd := n;
        ELSE
            cd := n - tiempo.date_to_number(31, 12, f.a - 1);
        END IF;
        
        f.m := tiempo.month_from_day_number(cd, f.a);

        f.d := cd - tiempo.day_number(1, f.m, f.a) + 1;

        b:= tiempo.date_to_number(f.d,f.m,f.a) - n;

        IF f.d = 0 THEN
            f.a := f.a - 1;
            f.m := 12;
            f.d := 31;
        ELSE
            IF (b > 0) THEN
                -- retrasar un dia
                IF (f.d = 1 and f.m = 1) THEN
                    f.a := f.a - 1;
                    f.m := 12;
                    f.d := 31;
                ELSE
                    IF (f.d = 1) THEN
                        f.m := f.m - 1;
                        f.d := tiempo.countdays_of_month(f.m);
                    ELSE
                        f.d := f.d - 1;
                    END IF;
                END IF;
            END IF;
        END IF;    
        RETURN f;
    END;
$$;


ALTER FUNCTION tiempo.number_to_date(n bigint) OWNER TO rafa;

--
-- Name: FUNCTION number_to_date(n bigint); Type: COMMENT; Schema: tiempo; Owner: rafa
--

COMMENT ON FUNCTION number_to_date(n bigint) IS 'RETURNS a date from consecutive number';


--
-- Name: number_to_hour(double precision); Type: FUNCTION; Schema: tiempo; Owner: rafa
--

CREATE FUNCTION number_to_hour(n double precision) RETURNS ancora_hour
    LANGUAGE plpgsql
    AS $$
    DECLARE t tiempo.ancora_hour;
    BEGIN
        t.h := trunc(n / 36);
        t.m := trunc((n - t.h * 36) /  0.6);
        t.s := trunc((n - (t.h * 36 + t.m * 0.6)) / 0.01);
        
        RETURN t;
    END;
$$;


ALTER FUNCTION tiempo.number_to_hour(n double precision) OWNER TO rafa;

--
-- Name: FUNCTION number_to_hour(n double precision); Type: COMMENT; Schema: tiempo; Owner: rafa
--

COMMENT ON FUNCTION number_to_hour(n double precision) IS 'Conert number to hour';


--
-- Name: today_number(); Type: FUNCTION; Schema: tiempo; Owner: rafa
--

CREATE FUNCTION today_number() RETURNS bigint
    LANGUAGE plpgsql
    AS $$
    DECLARE ahora timestamp;
        dia INTEGER;    
        mes INTEGER;
        anno INTEGER;
        f BIGINT;
        
    BEGIN
        ahora := now();
        dia := EXTRACT(DAY FROM ahora);
        mes := EXTRACT(MONTH FROM ahora);
        anno := EXTRACT(YEAR FROM ahora);
        
        f := tiempo.date_to_number(dia,mes,anno);
    
        RETURN f;

    END;
$$;


ALTER FUNCTION tiempo.today_number() OWNER TO rafa;

SET search_path = public, pg_catalog;

--
-- Name: first(anyelement); Type: AGGREGATE; Schema: public; Owner: rafa
--

CREATE AGGREGATE first(anyelement) (
    SFUNC = public.first,
    STYPE = anyelement
);


ALTER AGGREGATE public.first(anyelement) OWNER TO rafa;

SET search_path = generador, pg_catalog;

--
-- Name: cancelar; Type: TABLE; Schema: generador; Owner: postgres; Tablespace: 
--

CREATE TABLE cancelar (
    especialidad character varying NOT NULL,
    nivel character varying NOT NULL,
    periodo character varying NOT NULL
);


ALTER TABLE generador.cancelar OWNER TO postgres;

SET search_path = public, pg_catalog;

--
-- Name: acceso_prohibido; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE acceso_prohibido (
    grupo character varying NOT NULL,
    lugar character varying NOT NULL
);


ALTER TABLE public.acceso_prohibido OWNER TO rafa;

--
-- Name: asignatura; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE asignatura (
    id character varying DEFAULT crear_id_de_replica('ancoragoh'::character varying, 'asignatura'::character varying, 'id'::character varying, 'asignatura'::character varying) NOT NULL,
    descripcion character varying NOT NULL,
    especialidad character varying,
    nivel character varying NOT NULL,
    creador character varying NOT NULL
);


ALTER TABLE public.asignatura OWNER TO rafa;

--
-- Name: desglose; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE desglose (
    id character varying DEFAULT crear_id_de_replica('ancoragoh'::character varying, 'desglose'::character varying, 'id'::character varying, 'desglose'::character varying) NOT NULL,
    asignatura character varying NOT NULL,
    periodo character varying NOT NULL,
    min_dias integer DEFAULT 1,
    max_dias integer DEFAULT 5,
    respetar_orden boolean DEFAULT true,
    mismo_dia boolean DEFAULT false
);


ALTER TABLE public.desglose OWNER TO rafa;

--
-- Name: asignaturas_cant_act; Type: VIEW; Schema: public; Owner: rafa
--

CREATE VIEW asignaturas_cant_act AS
    SELECT asignatura.id AS asignatura, asignatura.especialidad, asignatura.nivel, desglose.periodo, dame_cant_act(asignatura.id, desglose.periodo) AS cantidad FROM (asignatura JOIN desglose ON (((desglose.asignatura)::text = (asignatura.id)::text)));


ALTER TABLE public.asignaturas_cant_act OWNER TO rafa;

--
-- Name: brigada_de_grupo; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE brigada_de_grupo (
    brigada character varying NOT NULL,
    grupo character varying NOT NULL
);


ALTER TABLE public.brigada_de_grupo OWNER TO rafa;

--
-- Name: clasificacion_de_actividad; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE clasificacion_de_actividad (
    id character varying DEFAULT crear_id_de_replica('ancoragoh'::character varying, 'clasificacion_de_actividad'::character varying, 'id'::character varying, 'clasificacion_de_actividad'::character varying) NOT NULL,
    descripcion character varying NOT NULL,
    duracion integer DEFAULT 1,
    creador character varying NOT NULL,
    prioridad integer DEFAULT 1 NOT NULL,
    gasto integer DEFAULT 1
);


ALTER TABLE public.clasificacion_de_actividad OWNER TO rafa;

--
-- Name: costo_de_traslado; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE costo_de_traslado (
    origen character varying NOT NULL,
    destino character varying NOT NULL,
    costo bigint
);


ALTER TABLE public.costo_de_traslado OWNER TO rafa;

--
-- Name: especialidad; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE especialidad (
    id character varying DEFAULT crear_id_de_replica('ancoragoh'::character varying, 'especialidad'::character varying, 'id'::character varying, 'especialidad'::character varying) NOT NULL,
    descripcion character varying NOT NULL,
    creador character varying NOT NULL
);


ALTER TABLE public.especialidad OWNER TO rafa;

--
-- Name: excepcion_de_hrt; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE excepcion_de_hrt (
    herencia character varying NOT NULL,
    periodo character varying NOT NULL,
    dia integer NOT NULL,
    turno integer NOT NULL,
    CONSTRAINT excepcion_de_hrt_dia_check CHECK ((dia > 0)),
    CONSTRAINT excepcion_de_hrt_turno_check CHECK ((turno > 0))
);


ALTER TABLE public.excepcion_de_hrt OWNER TO rafa;

--
-- Name: herencia_de_restricciones; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE herencia_de_restricciones (
    id character varying DEFAULT crear_id_de_replica('ancoragoh'::character varying, 'herencia_de_restricciones'::character varying, 'id'::character varying, 'herencia_de_restricciones'::character varying) NOT NULL,
    planificacion character varying,
    activa boolean DEFAULT true,
    hijo_brigada character varying,
    hijo_profesor character varying,
    hijo_lugar character varying,
    hijo_otro_recurso character varying,
    padre_brigada character varying,
    padre_profesor character varying,
    padre_lugar character varying,
    padre_otro_recurso character varying,
    CONSTRAINT herencia_de_restricciones_check CHECK ((check_hrt(hijo_brigada, hijo_profesor, hijo_lugar, hijo_otro_recurso, padre_brigada, padre_profesor, padre_lugar, padre_otro_recurso) = true))
);


ALTER TABLE public.herencia_de_restricciones OWNER TO rafa;

--
-- Name: higiene_para_brigada; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE higiene_para_brigada (
    periodo character varying NOT NULL,
    brigada character varying NOT NULL,
    gasto_maximo_diario integer NOT NULL
);


ALTER TABLE public.higiene_para_brigada OWNER TO rafa;

--
-- Name: higiene_para_profesor; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE higiene_para_profesor (
    periodo character varying NOT NULL,
    profesor character varying NOT NULL,
    gasto_maximo_diario integer NOT NULL
);


ALTER TABLE public.higiene_para_profesor OWNER TO rafa;

--
-- Name: lugar_fijo; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE lugar_fijo (
    grupo character varying NOT NULL,
    lugar character varying NOT NULL
);


ALTER TABLE public.lugar_fijo OWNER TO rafa;

--
-- Name: lugar_para_actividad; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE lugar_para_actividad (
    plantilla character varying NOT NULL,
    lugar character varying NOT NULL,
    prioridad integer DEFAULT 1 NOT NULL,
    actualizacion_interna boolean DEFAULT false
);


ALTER TABLE public.lugar_para_actividad OWNER TO rafa;

--
-- Name: nivel; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE nivel (
    id character varying DEFAULT crear_id_de_replica('ancoragoh'::character varying, 'nivel'::character varying, 'id'::character varying, 'nivel'::character varying) NOT NULL,
    descripcion character varying NOT NULL,
    creador character varying NOT NULL
);


ALTER TABLE public.nivel OWNER TO rafa;

--
-- Name: otro_grupo_de_recursos_para_actividad; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE otro_grupo_de_recursos_para_actividad (
    id character varying DEFAULT crear_id_de_replica('ancoragoh'::character varying, 'otro_grupo_de_recursos_para_actividad'::character varying, 'id'::character varying, 'otro_grupo_de_recursos_para_actividad'::character varying) NOT NULL,
    plantilla character varying NOT NULL,
    prioridad integer DEFAULT 1 NOT NULL,
    necesarios integer DEFAULT 1 NOT NULL,
    imprescindibles boolean DEFAULT true NOT NULL,
    creador character varying NOT NULL
);


ALTER TABLE public.otro_grupo_de_recursos_para_actividad OWNER TO rafa;

--
-- Name: otro_recurso_para_actividad; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE otro_recurso_para_actividad (
    grupo_de_recursos character varying NOT NULL,
    prioridad integer DEFAULT 1 NOT NULL,
    otro_recurso character varying NOT NULL
);


ALTER TABLE public.otro_recurso_para_actividad OWNER TO rafa;

--
-- Name: otros_recursos_usados; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE otros_recursos_usados (
    otro_recurso character varying NOT NULL,
    actividad character varying NOT NULL,
    creador character varying NOT NULL
);


ALTER TABLE public.otros_recursos_usados OWNER TO rafa;

--
-- Name: periodicidad; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE periodicidad (
    id character varying DEFAULT crear_id_de_replica('ancoragoh'::character varying, 'periodicidad'::character varying, 'id'::character varying, 'periodicidad'::character varying) NOT NULL,
    periodo character varying NOT NULL,
    dia integer,
    CONSTRAINT periodicidad_dia_check CHECK ((dia > 0))
);


ALTER TABLE public.periodicidad OWNER TO rafa;

--
-- Name: planificacion; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE planificacion (
    id character varying DEFAULT crear_id_de_replica('ancoragoh'::character varying, 'planificacion'::character varying, 'id'::character varying, 'planificacion'::character varying) NOT NULL,
    descripcion character varying NOT NULL,
    fecha_inicial bigint,
    cant_dias bigint,
    activa boolean DEFAULT true,
    creador character varying NOT NULL
);


ALTER TABLE public.planificacion OWNER TO rafa;

--
-- Name: plantilla_de_actividad; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE plantilla_de_actividad (
    id character varying DEFAULT crear_id_de_replica('ancoragoh'::character varying, 'plantilla_de_actividad'::character varying, 'id'::character varying, 'plantilla_de_actividad'::character varying) NOT NULL,
    desglose character varying NOT NULL,
    orden integer,
    clasificacion character varying NOT NULL,
    exige_profesor boolean DEFAULT true,
    exige_lugar boolean DEFAULT true,
    actualizacion_interna boolean DEFAULT false
);


ALTER TABLE public.plantilla_de_actividad OWNER TO rafa;

--
-- Name: profesor; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE profesor (
    id character varying DEFAULT crear_id_de_replica('ancoragoh'::character varying, 'profesor'::character varying, 'id'::character varying, 'profesor'::character varying) NOT NULL,
    nombre character varying,
    creador character varying NOT NULL
);


ALTER TABLE public.profesor OWNER TO rafa;

--
-- Name: profesor_para_actividad; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE profesor_para_actividad (
    id character varying DEFAULT crear_id_de_replica('ancoragoh'::character varying, 'profesor_para_actividad'::character varying, 'id'::character varying, 'profesor_para_actividad'::character varying) NOT NULL,
    plantilla character varying NOT NULL,
    profesor character varying NOT NULL,
    prioridad integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.profesor_para_actividad OWNER TO rafa;

--
-- Name: profesor_para_grupo; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE profesor_para_grupo (
    profesor_para_actividad character varying NOT NULL,
    grupo character varying NOT NULL
);


ALTER TABLE public.profesor_para_grupo OWNER TO rafa;

--
-- Name: receso; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE receso (
    periodo character varying NOT NULL,
    despues_del_turno integer NOT NULL,
    duracion double precision
);


ALTER TABLE public.receso OWNER TO rafa;

--
-- Name: restriccion_de_asignatura; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE restriccion_de_asignatura (
    id character varying NOT NULL,
    asignatura character varying NOT NULL,
    periodo character varying,
    dia integer,
    turno integer,
    valor integer DEFAULT 1,
    CONSTRAINT restriccion_de_asignatura_valor_check CHECK ((valor > 0))
);


ALTER TABLE public.restriccion_de_asignatura OWNER TO rafa;

--
-- Name: restriccion_de_brigada; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE restriccion_de_brigada (
    id character varying NOT NULL,
    brigada character varying NOT NULL,
    periodo character varying NOT NULL,
    dia integer,
    turno integer,
    valor integer DEFAULT 1,
    por_actividad boolean DEFAULT false,
    actividad character varying,
    CONSTRAINT restriccion_de_brigada_valor_check CHECK ((valor > 0))
);


ALTER TABLE public.restriccion_de_brigada OWNER TO rafa;

--
-- Name: restriccion_de_clasif_act; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE restriccion_de_clasif_act (
    id character varying NOT NULL,
    clasificacion character varying NOT NULL,
    periodo character varying,
    dia integer,
    turno integer,
    valor integer DEFAULT 1,
    CONSTRAINT restriccion_de_clasif_act_valor_check CHECK ((valor > 0))
);


ALTER TABLE public.restriccion_de_clasif_act OWNER TO rafa;

--
-- Name: restriccion_de_especialidad; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE restriccion_de_especialidad (
    id character varying NOT NULL,
    especialidad character varying NOT NULL,
    periodo character varying NOT NULL,
    dia integer,
    turno integer,
    valor integer DEFAULT 1,
    CONSTRAINT restriccion_de_especialidad_valor_check CHECK ((valor > 0))
);


ALTER TABLE public.restriccion_de_especialidad OWNER TO rafa;

--
-- Name: restriccion_de_lugar; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE restriccion_de_lugar (
    id character varying NOT NULL,
    lugar character varying NOT NULL,
    periodo character varying,
    dia integer,
    turno integer,
    valor integer DEFAULT 1,
    por_actividad boolean DEFAULT false,
    actividad character varying,
    CONSTRAINT restriccion_de_lugar_valor_check CHECK ((valor > 0))
);


ALTER TABLE public.restriccion_de_lugar OWNER TO rafa;

--
-- Name: restriccion_de_otro_recurso; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE restriccion_de_otro_recurso (
    id character varying NOT NULL,
    otro_recurso character varying NOT NULL,
    periodo character varying,
    dia integer,
    turno integer,
    valor integer DEFAULT 1,
    por_actividad boolean DEFAULT false,
    actividad character varying,
    CONSTRAINT restriccion_de_otro_recurso_valor_check CHECK ((valor > 0))
);


ALTER TABLE public.restriccion_de_otro_recurso OWNER TO rafa;

--
-- Name: restriccion_de_periodo; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE restriccion_de_periodo (
    id character varying NOT NULL,
    periodo character varying NOT NULL,
    dia integer,
    turno integer,
    valor integer DEFAULT 1,
    CONSTRAINT restriccion_de_periodo_valor_check CHECK ((valor > 0))
);


ALTER TABLE public.restriccion_de_periodo OWNER TO rafa;

--
-- Name: restriccion_de_profesor; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE restriccion_de_profesor (
    id character varying NOT NULL,
    profesor character varying NOT NULL,
    periodo character varying,
    dia integer,
    turno integer,
    valor integer DEFAULT 1,
    por_actividad boolean DEFAULT false,
    actividad character varying,
    CONSTRAINT restriccion_de_profesor_valor_check CHECK ((valor > 0))
);


ALTER TABLE public.restriccion_de_profesor OWNER TO rafa;

--
-- Name: restriccion_por_actividad; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE restriccion_por_actividad (
    restriccion_nominal character varying NOT NULL,
    actividad character varying NOT NULL
);


ALTER TABLE public.restriccion_por_actividad OWNER TO rafa;

--
-- Name: restriccion_por_actividad_de_brigada; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE restriccion_por_actividad_de_brigada (
)
INHERITS (restriccion_por_actividad);


ALTER TABLE public.restriccion_por_actividad_de_brigada OWNER TO rafa;

--
-- Name: restriccion_por_actividad_de_lugar; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE restriccion_por_actividad_de_lugar (
)
INHERITS (restriccion_por_actividad);


ALTER TABLE public.restriccion_por_actividad_de_lugar OWNER TO rafa;

--
-- Name: restriccion_por_actividad_de_otro_recurso; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE restriccion_por_actividad_de_otro_recurso (
)
INHERITS (restriccion_por_actividad);


ALTER TABLE public.restriccion_por_actividad_de_otro_recurso OWNER TO rafa;

--
-- Name: restriccion_por_actividad_de_profesor; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE restriccion_por_actividad_de_profesor (
)
INHERITS (restriccion_por_actividad);


ALTER TABLE public.restriccion_por_actividad_de_profesor OWNER TO rafa;

--
-- Name: restriccion_real; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE restriccion_real (
    restriccion_nominal character varying NOT NULL,
    periodicidad character varying NOT NULL,
    fecha bigint,
    hora_inicial double precision,
    hora_final double precision,
    por_actividad boolean NOT NULL,
    actividad character varying,
    objeto character varying NOT NULL,
    CONSTRAINT restriccion_real_check CHECK ((hora_final > hora_inicial))
);


ALTER TABLE public.restriccion_real OWNER TO rafa;

--
-- Name: restriccion_real_de_asignatura; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE restriccion_real_de_asignatura (
)
INHERITS (restriccion_real);


ALTER TABLE public.restriccion_real_de_asignatura OWNER TO rafa;

--
-- Name: restriccion_real_de_brigada; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE restriccion_real_de_brigada (
)
INHERITS (restriccion_real);


ALTER TABLE public.restriccion_real_de_brigada OWNER TO rafa;

--
-- Name: restriccion_real_de_clasif_act; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE restriccion_real_de_clasif_act (
)
INHERITS (restriccion_real);


ALTER TABLE public.restriccion_real_de_clasif_act OWNER TO rafa;

--
-- Name: restriccion_real_de_especialidad; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE restriccion_real_de_especialidad (
)
INHERITS (restriccion_real);


ALTER TABLE public.restriccion_real_de_especialidad OWNER TO rafa;

--
-- Name: restriccion_real_de_lugar; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE restriccion_real_de_lugar (
)
INHERITS (restriccion_real);


ALTER TABLE public.restriccion_real_de_lugar OWNER TO rafa;

--
-- Name: restriccion_real_de_otro_recurso; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE restriccion_real_de_otro_recurso (
)
INHERITS (restriccion_real);


ALTER TABLE public.restriccion_real_de_otro_recurso OWNER TO rafa;

--
-- Name: restriccion_real_de_periodo; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE restriccion_real_de_periodo (
)
INHERITS (restriccion_real);


ALTER TABLE public.restriccion_real_de_periodo OWNER TO rafa;

--
-- Name: restriccion_real_de_profesor; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE restriccion_real_de_profesor (
)
INHERITS (restriccion_real);


ALTER TABLE public.restriccion_real_de_profesor OWNER TO rafa;

--
-- Name: uso_de_otros_recursos; Type: VIEW; Schema: public; Owner: rafa
--

CREATE VIEW uso_de_otros_recursos AS
    SELECT otros_recursos_usados.otro_recurso, count(otros_recursos_usados.actividad) AS count FROM otros_recursos_usados GROUP BY otros_recursos_usados.otro_recurso;


ALTER TABLE public.uso_de_otros_recursos OWNER TO rafa;

--
-- Name: zpriori; Type: TABLE; Schema: public; Owner: rafa; Tablespace: 
--

CREATE TABLE zpriori (
    clasificacion character varying NOT NULL,
    periodo character varying NOT NULL,
    dia integer NOT NULL,
    turno integer NOT NULL,
    valor integer DEFAULT 1,
    CONSTRAINT zpriori_valor_check CHECK ((valor > 0))
);


ALTER TABLE public.zpriori OWNER TO rafa;

SET search_path = seguridad, pg_catalog;

--
-- Name: host; Type: TABLE; Schema: seguridad; Owner: rafa; Tablespace: 
--

CREATE TABLE host (
    ip character varying DEFAULT '*'::character varying NOT NULL,
    usuario character varying NOT NULL
);


ALTER TABLE seguridad.host OWNER TO rafa;

--
-- Name: permiso; Type: TABLE; Schema: seguridad; Owner: rafa; Tablespace: 
--

CREATE TABLE permiso (
    permiso character varying NOT NULL,
    rol character varying NOT NULL
);


ALTER TABLE seguridad.permiso OWNER TO rafa;

--
-- Name: rol; Type: TABLE; Schema: seguridad; Owner: rafa; Tablespace: 
--

CREATE TABLE rol (
    nombre character varying NOT NULL,
    descripcion character varying
);


ALTER TABLE seguridad.rol OWNER TO rafa;

--
-- Name: rol_de_usuario; Type: TABLE; Schema: seguridad; Owner: rafa; Tablespace: 
--

CREATE TABLE rol_de_usuario (
    usuario character varying NOT NULL,
    rol character varying NOT NULL
);


ALTER TABLE seguridad.rol_de_usuario OWNER TO rafa;

--
-- Name: traza; Type: TABLE; Schema: seguridad; Owner: rafa; Tablespace: 
--

CREATE TABLE traza (
    fecha timestamp without time zone DEFAULT now(),
    usuario character varying NOT NULL,
    accion character varying,
    ip character varying
);


ALTER TABLE seguridad.traza OWNER TO rafa;

--
-- Name: usuario; Type: TABLE; Schema: seguridad; Owner: rafa; Tablespace: 
--

CREATE TABLE usuario (
    id character varying DEFAULT public.crear_id_de_replica('ancoragoh'::character varying, 'seguridad.usuario'::character varying, 'id'::character varying, 'seguridad.usuario'::character varying) NOT NULL,
    nombre character varying NOT NULL,
    info character varying NOT NULL,
    correo character varying NOT NULL,
    momento_ingreso double precision DEFAULT tiempo.moment_now() NOT NULL,
    nick character varying NOT NULL,
    contrasena character varying NOT NULL
);


ALTER TABLE seguridad.usuario OWNER TO rafa;

SET search_path = generador, pg_catalog;

--
-- Data for Name: cancelar; Type: TABLE DATA; Schema: generador; Owner: postgres
--

COPY cancelar (especialidad, nivel, periodo) FROM stdin;
\.
copy cancelar (especialidad, nivel, periodo)  from '$$PATH$$/2765.dat' ;
SET search_path = public, pg_catalog;

--
-- Data for Name: acceso_prohibido; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY acceso_prohibido (grupo, lugar) FROM stdin;
\.
copy acceso_prohibido (grupo, lugar)  from '$$PATH$$/2711.dat' ;
--
-- Data for Name: actividad; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY actividad (id, plantilla, grupo, profesor, lugar, dia, turno, momento_de_colocacion, creador) FROM stdin;
\.
copy actividad (id, plantilla, grupo, profesor, lugar, dia, turno, momento_de_colocacion, creador)  from '$$PATH$$/2708.dat' ;
--
-- Data for Name: asignatura; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY asignatura (id, descripcion, especialidad, nivel, creador) FROM stdin;
\.
copy asignatura (id, descripcion, especialidad, nivel, creador)  from '$$PATH$$/2712.dat' ;
--
-- Data for Name: brigada; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY brigada (id, descripcion, especialidad, nivel, matricula, creador) FROM stdin;
\.
copy brigada (id, descripcion, especialidad, nivel, matricula, creador)  from '$$PATH$$/2705.dat' ;
--
-- Data for Name: brigada_de_grupo; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY brigada_de_grupo (brigada, grupo) FROM stdin;
\.
copy brigada_de_grupo (brigada, grupo)  from '$$PATH$$/2714.dat' ;
--
-- Data for Name: clasificacion_de_actividad; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY clasificacion_de_actividad (id, descripcion, duracion, creador, prioridad, gasto) FROM stdin;
\.
copy clasificacion_de_actividad (id, descripcion, duracion, creador, prioridad, gasto)  from '$$PATH$$/2715.dat' ;
--
-- Data for Name: costo_de_traslado; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY costo_de_traslado (origen, destino, costo) FROM stdin;
\.
copy costo_de_traslado (origen, destino, costo)  from '$$PATH$$/2716.dat' ;
--
-- Data for Name: desglose; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY desglose (id, asignatura, periodo, min_dias, max_dias, respetar_orden, mismo_dia) FROM stdin;
\.
copy desglose (id, asignatura, periodo, min_dias, max_dias, respetar_orden, mismo_dia)  from '$$PATH$$/2713.dat' ;
--
-- Data for Name: especialidad; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY especialidad (id, descripcion, creador) FROM stdin;
\.
copy especialidad (id, descripcion, creador)  from '$$PATH$$/2717.dat' ;
--
-- Data for Name: excepcion_de_hrt; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY excepcion_de_hrt (herencia, periodo, dia, turno) FROM stdin;
\.
copy excepcion_de_hrt (herencia, periodo, dia, turno)  from '$$PATH$$/2718.dat' ;
--
-- Data for Name: grupo; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY grupo (id, clasificacion, descripcion, especialidad, nivel, planificacion) FROM stdin;
\.
copy grupo (id, clasificacion, descripcion, especialidad, nivel, planificacion)  from '$$PATH$$/2706.dat' ;
--
-- Data for Name: herencia_de_restricciones; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY herencia_de_restricciones (id, planificacion, activa, hijo_brigada, hijo_profesor, hijo_lugar, hijo_otro_recurso, padre_brigada, padre_profesor, padre_lugar, padre_otro_recurso) FROM stdin;
\.
copy herencia_de_restricciones (id, planificacion, activa, hijo_brigada, hijo_profesor, hijo_lugar, hijo_otro_recurso, padre_brigada, padre_profesor, padre_lugar, padre_otro_recurso)  from '$$PATH$$/2719.dat' ;
--
-- Data for Name: higiene_para_brigada; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY higiene_para_brigada (periodo, brigada, gasto_maximo_diario) FROM stdin;
\.
copy higiene_para_brigada (periodo, brigada, gasto_maximo_diario)  from '$$PATH$$/2720.dat' ;
--
-- Data for Name: higiene_para_profesor; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY higiene_para_profesor (periodo, profesor, gasto_maximo_diario) FROM stdin;
\.
copy higiene_para_profesor (periodo, profesor, gasto_maximo_diario)  from '$$PATH$$/2721.dat' ;
--
-- Data for Name: lugar; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY lugar (id, nombre, capacidad, creador) FROM stdin;
\.
copy lugar (id, nombre, capacidad, creador)  from '$$PATH$$/2707.dat' ;
--
-- Data for Name: lugar_fijo; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY lugar_fijo (grupo, lugar) FROM stdin;
\.
copy lugar_fijo (grupo, lugar)  from '$$PATH$$/2722.dat' ;
--
-- Data for Name: lugar_para_actividad; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY lugar_para_actividad (plantilla, lugar, prioridad, actualizacion_interna) FROM stdin;
\.
copy lugar_para_actividad (plantilla, lugar, prioridad, actualizacion_interna)  from '$$PATH$$/2723.dat' ;
--
-- Data for Name: nivel; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY nivel (id, descripcion, creador) FROM stdin;
\.
copy nivel (id, descripcion, creador)  from '$$PATH$$/2724.dat' ;
--
-- Data for Name: otro_grupo_de_recursos_para_actividad; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY otro_grupo_de_recursos_para_actividad (id, plantilla, prioridad, necesarios, imprescindibles, creador) FROM stdin;
\.
copy otro_grupo_de_recursos_para_actividad (id, plantilla, prioridad, necesarios, imprescindibles, creador)  from '$$PATH$$/2725.dat' ;
--
-- Data for Name: otro_recurso; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY otro_recurso (id, nombre, creador) FROM stdin;
\.
copy otro_recurso (id, nombre, creador)  from '$$PATH$$/2726.dat' ;
--
-- Data for Name: otro_recurso_para_actividad; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY otro_recurso_para_actividad (grupo_de_recursos, prioridad, otro_recurso) FROM stdin;
\.
copy otro_recurso_para_actividad (grupo_de_recursos, prioridad, otro_recurso)  from '$$PATH$$/2727.dat' ;
--
-- Data for Name: otros_recursos_usados; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY otros_recursos_usados (otro_recurso, actividad, creador) FROM stdin;
\.
copy otros_recursos_usados (otro_recurso, actividad, creador)  from '$$PATH$$/2728.dat' ;
--
-- Data for Name: periodicidad; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY periodicidad (id, periodo, dia) FROM stdin;
\.
copy periodicidad (id, periodo, dia)  from '$$PATH$$/2729.dat' ;
--
-- Data for Name: periodo; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY periodo (id, descripcion, cant_dias, cant_turnos, hora_inicial, duracion_del_turno, planificacion) FROM stdin;
\.
copy periodo (id, descripcion, cant_dias, cant_turnos, hora_inicial, duracion_del_turno, planificacion)  from '$$PATH$$/2710.dat' ;
--
-- Data for Name: planificacion; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY planificacion (id, descripcion, fecha_inicial, cant_dias, activa, creador) FROM stdin;
\.
copy planificacion (id, descripcion, fecha_inicial, cant_dias, activa, creador)  from '$$PATH$$/2730.dat' ;
--
-- Data for Name: plantilla_de_actividad; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY plantilla_de_actividad (id, desglose, orden, clasificacion, exige_profesor, exige_lugar, actualizacion_interna) FROM stdin;
\.
copy plantilla_de_actividad (id, desglose, orden, clasificacion, exige_profesor, exige_lugar, actualizacion_interna)  from '$$PATH$$/2731.dat' ;
--
-- Data for Name: profesor; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY profesor (id, nombre, creador) FROM stdin;
\.
copy profesor (id, nombre, creador)  from '$$PATH$$/2732.dat' ;
--
-- Data for Name: profesor_para_actividad; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY profesor_para_actividad (id, plantilla, profesor, prioridad) FROM stdin;
\.
copy profesor_para_actividad (id, plantilla, profesor, prioridad)  from '$$PATH$$/2733.dat' ;
--
-- Data for Name: profesor_para_grupo; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY profesor_para_grupo (profesor_para_actividad, grupo) FROM stdin;
\.
copy profesor_para_grupo (profesor_para_actividad, grupo)  from '$$PATH$$/2734.dat' ;
--
-- Data for Name: receso; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY receso (periodo, despues_del_turno, duracion) FROM stdin;
\.
copy receso (periodo, despues_del_turno, duracion)  from '$$PATH$$/2735.dat' ;
--
-- Data for Name: restriccion_condicional; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY restriccion_condicional (id, planificacion, activa, clasif_act, asig, brigada, profesor, lugar, otro_recurso, especialidad, nivel, fecha_ini, fecha_fin, hora_ini, hora_fin, discreto_exacto, dia_ini_planif, dia_fin_planif, hora_ini_planif, hora_fin_planif, discreto_exacto_planif, periodo, dia_ini, dia_fin, turno_ini, turno_fin, discreto, hoy, ahora, dia_relativo_anterior, cant_dias_relativo_anterior, dia_relativo_posterior, cant_dias_relativo_posterior, rango_tiempo_relativo_anterior_ini, rango_tiempo_relativo_anterior_tamano, turno_relativo_anterior, cant_turnos_relativo_anterior, turno_relativo_posterior, cant_turnos_relativo_posterior, rango_tiempo_relativo_posterior_ini, rango_tiempo_relativo_posterior_tamano, entre_dias_antes, entre_dias_despues, entre_turnos_antes, entre_turnos_despues, entre_tiempo_antes, entre_tiempo_despues, cant_exa, cant_min, cant_max, consec_brigada, consec_profesor, consec_lugar, consec_otro_recurso, consec_periodo, consec_dia_ini, consec_dia_fin, consec_turno_ini, consec_turno_fin, consec_discreto, siempre, valor) FROM stdin;
\.
copy restriccion_condicional (id, planificacion, activa, clasif_act, asig, brigada, profesor, lugar, otro_recurso, especialidad, nivel, fecha_ini, fecha_fin, hora_ini, hora_fin, discreto_exacto, dia_ini_planif, dia_fin_planif, hora_ini_planif, hora_fin_planif, discreto_exacto_planif, periodo, dia_ini, dia_fin, turno_ini, turno_fin, discreto, hoy, ahora, dia_relativo_anterior, cant_dias_relativo_anterior, dia_relativo_posterior, cant_dias_relativo_posterior, rango_tiempo_relativo_anterior_ini, rango_tiempo_relativo_anterior_tamano, turno_relativo_anterior, cant_turnos_relativo_anterior, turno_relativo_posterior, cant_turnos_relativo_posterior, rango_tiempo_relativo_posterior_ini, rango_tiempo_relativo_posterior_tamano, entre_dias_antes, entre_dias_despues, entre_turnos_antes, entre_turnos_despues, entre_tiempo_antes, entre_tiempo_despues, cant_exa, cant_min, cant_max, consec_brigada, consec_profesor, consec_lugar, consec_otro_recurso, consec_periodo, consec_dia_ini, consec_dia_fin, consec_turno_ini, consec_turno_fin, consec_discreto, siempre, valor)  from '$$PATH$$/2709.dat' ;
--
-- Data for Name: restriccion_de_asignatura; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY restriccion_de_asignatura (id, asignatura, periodo, dia, turno, valor) FROM stdin;
\.
copy restriccion_de_asignatura (id, asignatura, periodo, dia, turno, valor)  from '$$PATH$$/2736.dat' ;
--
-- Data for Name: restriccion_de_brigada; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY restriccion_de_brigada (id, brigada, periodo, dia, turno, valor, por_actividad, actividad) FROM stdin;
\.
copy restriccion_de_brigada (id, brigada, periodo, dia, turno, valor, por_actividad, actividad)  from '$$PATH$$/2737.dat' ;
--
-- Data for Name: restriccion_de_clasif_act; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY restriccion_de_clasif_act (id, clasificacion, periodo, dia, turno, valor) FROM stdin;
\.
copy restriccion_de_clasif_act (id, clasificacion, periodo, dia, turno, valor)  from '$$PATH$$/2738.dat' ;
--
-- Data for Name: restriccion_de_especialidad; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY restriccion_de_especialidad (id, especialidad, periodo, dia, turno, valor) FROM stdin;
\.
copy restriccion_de_especialidad (id, especialidad, periodo, dia, turno, valor)  from '$$PATH$$/2739.dat' ;
--
-- Data for Name: restriccion_de_lugar; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY restriccion_de_lugar (id, lugar, periodo, dia, turno, valor, por_actividad, actividad) FROM stdin;
\.
copy restriccion_de_lugar (id, lugar, periodo, dia, turno, valor, por_actividad, actividad)  from '$$PATH$$/2740.dat' ;
--
-- Data for Name: restriccion_de_otro_recurso; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY restriccion_de_otro_recurso (id, otro_recurso, periodo, dia, turno, valor, por_actividad, actividad) FROM stdin;
\.
copy restriccion_de_otro_recurso (id, otro_recurso, periodo, dia, turno, valor, por_actividad, actividad)  from '$$PATH$$/2741.dat' ;
--
-- Data for Name: restriccion_de_periodo; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY restriccion_de_periodo (id, periodo, dia, turno, valor) FROM stdin;
\.
copy restriccion_de_periodo (id, periodo, dia, turno, valor)  from '$$PATH$$/2742.dat' ;
--
-- Data for Name: restriccion_de_profesor; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY restriccion_de_profesor (id, profesor, periodo, dia, turno, valor, por_actividad, actividad) FROM stdin;
\.
copy restriccion_de_profesor (id, profesor, periodo, dia, turno, valor, por_actividad, actividad)  from '$$PATH$$/2743.dat' ;
--
-- Data for Name: restriccion_por_actividad; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY restriccion_por_actividad (restriccion_nominal, actividad) FROM stdin;
\.
copy restriccion_por_actividad (restriccion_nominal, actividad)  from '$$PATH$$/2744.dat' ;
--
-- Data for Name: restriccion_por_actividad_de_brigada; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY restriccion_por_actividad_de_brigada (restriccion_nominal, actividad) FROM stdin;
\.
copy restriccion_por_actividad_de_brigada (restriccion_nominal, actividad)  from '$$PATH$$/2745.dat' ;
--
-- Data for Name: restriccion_por_actividad_de_lugar; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY restriccion_por_actividad_de_lugar (restriccion_nominal, actividad) FROM stdin;
\.
copy restriccion_por_actividad_de_lugar (restriccion_nominal, actividad)  from '$$PATH$$/2746.dat' ;
--
-- Data for Name: restriccion_por_actividad_de_otro_recurso; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY restriccion_por_actividad_de_otro_recurso (restriccion_nominal, actividad) FROM stdin;
\.
copy restriccion_por_actividad_de_otro_recurso (restriccion_nominal, actividad)  from '$$PATH$$/2747.dat' ;
--
-- Data for Name: restriccion_por_actividad_de_profesor; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY restriccion_por_actividad_de_profesor (restriccion_nominal, actividad) FROM stdin;
\.
copy restriccion_por_actividad_de_profesor (restriccion_nominal, actividad)  from '$$PATH$$/2748.dat' ;
--
-- Data for Name: restriccion_real; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY restriccion_real (restriccion_nominal, periodicidad, fecha, hora_inicial, hora_final, por_actividad, actividad, objeto) FROM stdin;
\.
copy restriccion_real (restriccion_nominal, periodicidad, fecha, hora_inicial, hora_final, por_actividad, actividad, objeto)  from '$$PATH$$/2749.dat' ;
--
-- Data for Name: restriccion_real_de_asignatura; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY restriccion_real_de_asignatura (restriccion_nominal, periodicidad, fecha, hora_inicial, hora_final, por_actividad, actividad, objeto) FROM stdin;
\.
copy restriccion_real_de_asignatura (restriccion_nominal, periodicidad, fecha, hora_inicial, hora_final, por_actividad, actividad, objeto)  from '$$PATH$$/2750.dat' ;
--
-- Data for Name: restriccion_real_de_brigada; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY restriccion_real_de_brigada (restriccion_nominal, periodicidad, fecha, hora_inicial, hora_final, por_actividad, actividad, objeto) FROM stdin;
\.
copy restriccion_real_de_brigada (restriccion_nominal, periodicidad, fecha, hora_inicial, hora_final, por_actividad, actividad, objeto)  from '$$PATH$$/2751.dat' ;
--
-- Data for Name: restriccion_real_de_clasif_act; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY restriccion_real_de_clasif_act (restriccion_nominal, periodicidad, fecha, hora_inicial, hora_final, por_actividad, actividad, objeto) FROM stdin;
\.
copy restriccion_real_de_clasif_act (restriccion_nominal, periodicidad, fecha, hora_inicial, hora_final, por_actividad, actividad, objeto)  from '$$PATH$$/2752.dat' ;
--
-- Data for Name: restriccion_real_de_especialidad; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY restriccion_real_de_especialidad (restriccion_nominal, periodicidad, fecha, hora_inicial, hora_final, por_actividad, actividad, objeto) FROM stdin;
\.
copy restriccion_real_de_especialidad (restriccion_nominal, periodicidad, fecha, hora_inicial, hora_final, por_actividad, actividad, objeto)  from '$$PATH$$/2753.dat' ;
--
-- Data for Name: restriccion_real_de_lugar; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY restriccion_real_de_lugar (restriccion_nominal, periodicidad, fecha, hora_inicial, hora_final, por_actividad, actividad, objeto) FROM stdin;
\.
copy restriccion_real_de_lugar (restriccion_nominal, periodicidad, fecha, hora_inicial, hora_final, por_actividad, actividad, objeto)  from '$$PATH$$/2754.dat' ;
--
-- Data for Name: restriccion_real_de_otro_recurso; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY restriccion_real_de_otro_recurso (restriccion_nominal, periodicidad, fecha, hora_inicial, hora_final, por_actividad, actividad, objeto) FROM stdin;
\.
copy restriccion_real_de_otro_recurso (restriccion_nominal, periodicidad, fecha, hora_inicial, hora_final, por_actividad, actividad, objeto)  from '$$PATH$$/2755.dat' ;
--
-- Data for Name: restriccion_real_de_periodo; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY restriccion_real_de_periodo (restriccion_nominal, periodicidad, fecha, hora_inicial, hora_final, por_actividad, actividad, objeto) FROM stdin;
\.
copy restriccion_real_de_periodo (restriccion_nominal, periodicidad, fecha, hora_inicial, hora_final, por_actividad, actividad, objeto)  from '$$PATH$$/2756.dat' ;
--
-- Data for Name: restriccion_real_de_profesor; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY restriccion_real_de_profesor (restriccion_nominal, periodicidad, fecha, hora_inicial, hora_final, por_actividad, actividad, objeto) FROM stdin;
\.
copy restriccion_real_de_profesor (restriccion_nominal, periodicidad, fecha, hora_inicial, hora_final, por_actividad, actividad, objeto)  from '$$PATH$$/2757.dat' ;
--
-- Data for Name: zpriori; Type: TABLE DATA; Schema: public; Owner: rafa
--

COPY zpriori (clasificacion, periodo, dia, turno, valor) FROM stdin;
\.
copy zpriori (clasificacion, periodo, dia, turno, valor)  from '$$PATH$$/2758.dat' ;
SET search_path = seguridad, pg_catalog;

--
-- Data for Name: host; Type: TABLE DATA; Schema: seguridad; Owner: rafa
--

COPY host (ip, usuario) FROM stdin;
\.
copy host (ip, usuario)  from '$$PATH$$/2759.dat' ;
--
-- Data for Name: permiso; Type: TABLE DATA; Schema: seguridad; Owner: rafa
--

COPY permiso (permiso, rol) FROM stdin;
\.
copy permiso (permiso, rol)  from '$$PATH$$/2760.dat' ;
--
-- Data for Name: rol; Type: TABLE DATA; Schema: seguridad; Owner: rafa
--

COPY rol (nombre, descripcion) FROM stdin;
\.
copy rol (nombre, descripcion)  from '$$PATH$$/2761.dat' ;
--
-- Data for Name: rol_de_usuario; Type: TABLE DATA; Schema: seguridad; Owner: rafa
--

COPY rol_de_usuario (usuario, rol) FROM stdin;
\.
copy rol_de_usuario (usuario, rol)  from '$$PATH$$/2762.dat' ;
--
-- Data for Name: traza; Type: TABLE DATA; Schema: seguridad; Owner: rafa
--

COPY traza (fecha, usuario, accion, ip) FROM stdin;
\.
copy traza (fecha, usuario, accion, ip)  from '$$PATH$$/2763.dat' ;
--
-- Data for Name: usuario; Type: TABLE DATA; Schema: seguridad; Owner: rafa
--

COPY usuario (id, nombre, info, correo, momento_ingreso, nick, contrasena) FROM stdin;
\.
copy usuario (id, nombre, info, correo, momento_ingreso, nick, contrasena)  from '$$PATH$$/2764.dat' ;
SET search_path = generador, pg_catalog;

--
-- Name: cancelar_pkey; Type: CONSTRAINT; Schema: generador; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cancelar
    ADD CONSTRAINT cancelar_pkey PRIMARY KEY (especialidad, nivel, periodo);


SET search_path = public, pg_catalog;

--
-- Name: acceso_prohibido_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY acceso_prohibido
    ADD CONSTRAINT acceso_prohibido_pkey PRIMARY KEY (grupo, lugar);


--
-- Name: actividad_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY actividad
    ADD CONSTRAINT actividad_pkey PRIMARY KEY (id);


--
-- Name: actividad_plantilla_key; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY actividad
    ADD CONSTRAINT actividad_plantilla_key UNIQUE (plantilla, grupo);


--
-- Name: asignatura_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY asignatura
    ADD CONSTRAINT asignatura_pkey PRIMARY KEY (id);


--
-- Name: brigada_de_grupo_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY brigada_de_grupo
    ADD CONSTRAINT brigada_de_grupo_pkey PRIMARY KEY (brigada, grupo);


--
-- Name: brigada_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY brigada
    ADD CONSTRAINT brigada_pkey PRIMARY KEY (id);


--
-- Name: clasificacion_de_actividad_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY clasificacion_de_actividad
    ADD CONSTRAINT clasificacion_de_actividad_pkey PRIMARY KEY (id);


--
-- Name: costo_de_traslado_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY costo_de_traslado
    ADD CONSTRAINT costo_de_traslado_pkey PRIMARY KEY (origen, destino);


--
-- Name: desglose_asignatura_key; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY desglose
    ADD CONSTRAINT desglose_asignatura_key UNIQUE (asignatura, periodo);


--
-- Name: desglose_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY desglose
    ADD CONSTRAINT desglose_pkey PRIMARY KEY (id);


--
-- Name: especialidad_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY especialidad
    ADD CONSTRAINT especialidad_pkey PRIMARY KEY (id);


--
-- Name: excepcion_de_hrt_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY excepcion_de_hrt
    ADD CONSTRAINT excepcion_de_hrt_pkey PRIMARY KEY (herencia, periodo, dia, turno);


--
-- Name: grupo_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY grupo
    ADD CONSTRAINT grupo_pkey PRIMARY KEY (id);


--
-- Name: herencia_de_restricciones_hijo_brigada_key; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY herencia_de_restricciones
    ADD CONSTRAINT herencia_de_restricciones_hijo_brigada_key UNIQUE (hijo_brigada, hijo_profesor, hijo_lugar, hijo_otro_recurso, padre_brigada, padre_profesor, padre_lugar, padre_otro_recurso);


--
-- Name: herencia_de_restricciones_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY herencia_de_restricciones
    ADD CONSTRAINT herencia_de_restricciones_pkey PRIMARY KEY (id);


--
-- Name: higiene_para_brigada_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY higiene_para_brigada
    ADD CONSTRAINT higiene_para_brigada_pkey PRIMARY KEY (periodo, brigada, gasto_maximo_diario);


--
-- Name: higiene_para_profesor_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY higiene_para_profesor
    ADD CONSTRAINT higiene_para_profesor_pkey PRIMARY KEY (periodo, profesor, gasto_maximo_diario);


--
-- Name: lugar_fijo_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY lugar_fijo
    ADD CONSTRAINT lugar_fijo_pkey PRIMARY KEY (grupo, lugar);


--
-- Name: lugar_para_actividad_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY lugar_para_actividad
    ADD CONSTRAINT lugar_para_actividad_pkey PRIMARY KEY (plantilla, lugar);


--
-- Name: lugar_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY lugar
    ADD CONSTRAINT lugar_pkey PRIMARY KEY (id);


--
-- Name: nivel_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY nivel
    ADD CONSTRAINT nivel_pkey PRIMARY KEY (id);


--
-- Name: otro_grupo_de_recursos_para_actividad_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY otro_grupo_de_recursos_para_actividad
    ADD CONSTRAINT otro_grupo_de_recursos_para_actividad_pkey PRIMARY KEY (id);


--
-- Name: otro_recurso_para_actividad_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY otro_recurso_para_actividad
    ADD CONSTRAINT otro_recurso_para_actividad_pkey PRIMARY KEY (grupo_de_recursos, otro_recurso);


--
-- Name: otro_recurso_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY otro_recurso
    ADD CONSTRAINT otro_recurso_pkey PRIMARY KEY (id);


--
-- Name: otros_recursos_usados_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY otros_recursos_usados
    ADD CONSTRAINT otros_recursos_usados_pkey PRIMARY KEY (otro_recurso, actividad);


--
-- Name: periodicidad_periodo_key; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY periodicidad
    ADD CONSTRAINT periodicidad_periodo_key UNIQUE (periodo, dia);


--
-- Name: periodicidad_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY periodicidad
    ADD CONSTRAINT periodicidad_pkey PRIMARY KEY (id);


--
-- Name: periodo_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY periodo
    ADD CONSTRAINT periodo_pkey PRIMARY KEY (id);


--
-- Name: planificacion_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY planificacion
    ADD CONSTRAINT planificacion_pkey PRIMARY KEY (id);


--
-- Name: plantilla_de_actividad_desglose_key; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY plantilla_de_actividad
    ADD CONSTRAINT plantilla_de_actividad_desglose_key UNIQUE (desglose, orden);


--
-- Name: plantilla_de_actividad_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY plantilla_de_actividad
    ADD CONSTRAINT plantilla_de_actividad_pkey PRIMARY KEY (id);


--
-- Name: profesor_para_actividad_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY profesor_para_actividad
    ADD CONSTRAINT profesor_para_actividad_pkey PRIMARY KEY (id);


--
-- Name: profesor_para_actividad_plantilla_key; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY profesor_para_actividad
    ADD CONSTRAINT profesor_para_actividad_plantilla_key UNIQUE (plantilla, profesor);


--
-- Name: profesor_para_grupo_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY profesor_para_grupo
    ADD CONSTRAINT profesor_para_grupo_pkey PRIMARY KEY (profesor_para_actividad, grupo);


--
-- Name: profesor_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY profesor
    ADD CONSTRAINT profesor_pkey PRIMARY KEY (id);


--
-- Name: receso_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY receso
    ADD CONSTRAINT receso_pkey PRIMARY KEY (periodo, despues_del_turno);


--
-- Name: restriccion_condicional_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY restriccion_condicional
    ADD CONSTRAINT restriccion_condicional_pkey PRIMARY KEY (id);


--
-- Name: restriccion_de_asignatura_asignatura_key; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY restriccion_de_asignatura
    ADD CONSTRAINT restriccion_de_asignatura_asignatura_key UNIQUE (asignatura, periodo, dia, turno);


--
-- Name: restriccion_de_asignatura_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY restriccion_de_asignatura
    ADD CONSTRAINT restriccion_de_asignatura_pkey PRIMARY KEY (id);


--
-- Name: restriccion_de_brigada_brigada_key; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY restriccion_de_brigada
    ADD CONSTRAINT restriccion_de_brigada_brigada_key UNIQUE (brigada, periodo, dia, turno);


--
-- Name: restriccion_de_brigada_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY restriccion_de_brigada
    ADD CONSTRAINT restriccion_de_brigada_pkey PRIMARY KEY (id);


--
-- Name: restriccion_de_clasif_act_clasificacion_key; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY restriccion_de_clasif_act
    ADD CONSTRAINT restriccion_de_clasif_act_clasificacion_key UNIQUE (clasificacion, periodo, dia, turno);


--
-- Name: restriccion_de_clasif_act_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY restriccion_de_clasif_act
    ADD CONSTRAINT restriccion_de_clasif_act_pkey PRIMARY KEY (id);


--
-- Name: restriccion_de_especialidad_especialidad_key; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY restriccion_de_especialidad
    ADD CONSTRAINT restriccion_de_especialidad_especialidad_key UNIQUE (especialidad, periodo, dia, turno);


--
-- Name: restriccion_de_especialidad_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY restriccion_de_especialidad
    ADD CONSTRAINT restriccion_de_especialidad_pkey PRIMARY KEY (id);


--
-- Name: restriccion_de_lugar_lugar_key; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY restriccion_de_lugar
    ADD CONSTRAINT restriccion_de_lugar_lugar_key UNIQUE (lugar, periodo, dia, turno);


--
-- Name: restriccion_de_lugar_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY restriccion_de_lugar
    ADD CONSTRAINT restriccion_de_lugar_pkey PRIMARY KEY (id);


--
-- Name: restriccion_de_otro_recurso_otro_recurso_key; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY restriccion_de_otro_recurso
    ADD CONSTRAINT restriccion_de_otro_recurso_otro_recurso_key UNIQUE (otro_recurso, periodo, dia, turno);


--
-- Name: restriccion_de_otro_recurso_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY restriccion_de_otro_recurso
    ADD CONSTRAINT restriccion_de_otro_recurso_pkey PRIMARY KEY (id);


--
-- Name: restriccion_de_periodo_periodo_key; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY restriccion_de_periodo
    ADD CONSTRAINT restriccion_de_periodo_periodo_key UNIQUE (periodo, dia, turno);


--
-- Name: restriccion_de_periodo_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY restriccion_de_periodo
    ADD CONSTRAINT restriccion_de_periodo_pkey PRIMARY KEY (id);


--
-- Name: restriccion_de_profesor_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY restriccion_de_profesor
    ADD CONSTRAINT restriccion_de_profesor_pkey PRIMARY KEY (id);


--
-- Name: restriccion_de_profesor_profesor_key; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY restriccion_de_profesor
    ADD CONSTRAINT restriccion_de_profesor_profesor_key UNIQUE (profesor, periodo, dia, turno);


--
-- Name: restriccion_por_actividad_de_brigada_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY restriccion_por_actividad_de_brigada
    ADD CONSTRAINT restriccion_por_actividad_de_brigada_pkey PRIMARY KEY (restriccion_nominal);


--
-- Name: restriccion_por_actividad_de_lugar_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY restriccion_por_actividad_de_lugar
    ADD CONSTRAINT restriccion_por_actividad_de_lugar_pkey PRIMARY KEY (restriccion_nominal);


--
-- Name: restriccion_por_actividad_de_otro_recurso_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY restriccion_por_actividad_de_otro_recurso
    ADD CONSTRAINT restriccion_por_actividad_de_otro_recurso_pkey PRIMARY KEY (restriccion_nominal);


--
-- Name: restriccion_por_actividad_de_profesor_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY restriccion_por_actividad_de_profesor
    ADD CONSTRAINT restriccion_por_actividad_de_profesor_pkey PRIMARY KEY (restriccion_nominal);


--
-- Name: restriccion_por_actividad_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY restriccion_por_actividad
    ADD CONSTRAINT restriccion_por_actividad_pkey PRIMARY KEY (restriccion_nominal, actividad);


--
-- Name: restriccion_real_de_asignatura_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY restriccion_real_de_asignatura
    ADD CONSTRAINT restriccion_real_de_asignatura_pkey PRIMARY KEY (restriccion_nominal, periodicidad);


--
-- Name: restriccion_real_de_brigada_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY restriccion_real_de_brigada
    ADD CONSTRAINT restriccion_real_de_brigada_pkey PRIMARY KEY (restriccion_nominal, periodicidad);


--
-- Name: restriccion_real_de_clasif_act_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY restriccion_real_de_clasif_act
    ADD CONSTRAINT restriccion_real_de_clasif_act_pkey PRIMARY KEY (restriccion_nominal, periodicidad);


--
-- Name: restriccion_real_de_especialidad_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY restriccion_real_de_especialidad
    ADD CONSTRAINT restriccion_real_de_especialidad_pkey PRIMARY KEY (restriccion_nominal, periodicidad);


--
-- Name: restriccion_real_de_lugar_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY restriccion_real_de_lugar
    ADD CONSTRAINT restriccion_real_de_lugar_pkey PRIMARY KEY (restriccion_nominal, periodicidad);


--
-- Name: restriccion_real_de_otro_recurso_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY restriccion_real_de_otro_recurso
    ADD CONSTRAINT restriccion_real_de_otro_recurso_pkey PRIMARY KEY (restriccion_nominal, periodicidad);


--
-- Name: restriccion_real_de_periodo_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY restriccion_real_de_periodo
    ADD CONSTRAINT restriccion_real_de_periodo_pkey PRIMARY KEY (restriccion_nominal, periodicidad);


--
-- Name: restriccion_real_de_profesor_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY restriccion_real_de_profesor
    ADD CONSTRAINT restriccion_real_de_profesor_pkey PRIMARY KEY (restriccion_nominal, periodicidad);


--
-- Name: restriccion_real_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY restriccion_real
    ADD CONSTRAINT restriccion_real_pkey PRIMARY KEY (restriccion_nominal, periodicidad);


--
-- Name: zpriori_pkey; Type: CONSTRAINT; Schema: public; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY zpriori
    ADD CONSTRAINT zpriori_pkey PRIMARY KEY (clasificacion, periodo, dia, turno);


SET search_path = seguridad, pg_catalog;

--
-- Name: host_pkey; Type: CONSTRAINT; Schema: seguridad; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY host
    ADD CONSTRAINT host_pkey PRIMARY KEY (ip, usuario);


--
-- Name: permiso_pkey; Type: CONSTRAINT; Schema: seguridad; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY permiso
    ADD CONSTRAINT permiso_pkey PRIMARY KEY (permiso, rol);


--
-- Name: rol_de_usuario_pkey; Type: CONSTRAINT; Schema: seguridad; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY rol_de_usuario
    ADD CONSTRAINT rol_de_usuario_pkey PRIMARY KEY (usuario, rol);


--
-- Name: rol_pkey; Type: CONSTRAINT; Schema: seguridad; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY rol
    ADD CONSTRAINT rol_pkey PRIMARY KEY (nombre);


--
-- Name: usuario_nick_key; Type: CONSTRAINT; Schema: seguridad; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY usuario
    ADD CONSTRAINT usuario_nick_key UNIQUE (nick);


--
-- Name: usuario_pkey; Type: CONSTRAINT; Schema: seguridad; Owner: rafa; Tablespace: 
--

ALTER TABLE ONLY usuario
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (id);


SET search_path = public, pg_catalog;

--
-- Name: actualiza_por_actividad_en_nueva_restriccion_de_brigada; Type: RULE; Schema: public; Owner: rafa
--

CREATE RULE actualiza_por_actividad_en_nueva_restriccion_de_brigada AS ON INSERT TO restriccion_por_actividad_de_brigada DO UPDATE restriccion_de_brigada SET por_actividad = true WHERE ((restriccion_de_brigada.id)::text = (new.restriccion_nominal)::text);


--
-- Name: actualiza_por_actividad_en_nueva_restriccion_de_lugar; Type: RULE; Schema: public; Owner: rafa
--

CREATE RULE actualiza_por_actividad_en_nueva_restriccion_de_lugar AS ON INSERT TO restriccion_por_actividad_de_lugar DO UPDATE restriccion_de_lugar SET por_actividad = true WHERE ((restriccion_de_lugar.id)::text = (new.restriccion_nominal)::text);


--
-- Name: actualiza_por_actividad_en_nueva_restriccion_de_otro_recurso; Type: RULE; Schema: public; Owner: rafa
--

CREATE RULE actualiza_por_actividad_en_nueva_restriccion_de_otro_recurso AS ON INSERT TO restriccion_por_actividad_de_otro_recurso DO UPDATE restriccion_de_otro_recurso SET por_actividad = true WHERE ((restriccion_de_otro_recurso.id)::text = (new.restriccion_nominal)::text);


--
-- Name: actualiza_por_actividad_en_nueva_restriccion_de_profesor; Type: RULE; Schema: public; Owner: rafa
--

CREATE RULE actualiza_por_actividad_en_nueva_restriccion_de_profesor AS ON INSERT TO restriccion_por_actividad_de_profesor DO UPDATE restriccion_de_profesor SET por_actividad = true WHERE ((restriccion_de_profesor.id)::text = (new.restriccion_nominal)::text);


--
-- Name: actualiza_por_actividad_en_restriccion_de_brigada; Type: RULE; Schema: public; Owner: rafa
--

CREATE RULE actualiza_por_actividad_en_restriccion_de_brigada AS ON UPDATE TO restriccion_por_actividad_de_brigada DO (UPDATE restriccion_de_brigada SET por_actividad = false WHERE ((restriccion_de_brigada.id)::text = (old.restriccion_nominal)::text); UPDATE restriccion_de_brigada SET por_actividad = true WHERE ((restriccion_de_brigada.id)::text = (new.restriccion_nominal)::text); );


--
-- Name: actualiza_por_actividad_en_restriccion_de_lugar; Type: RULE; Schema: public; Owner: rafa
--

CREATE RULE actualiza_por_actividad_en_restriccion_de_lugar AS ON UPDATE TO restriccion_por_actividad_de_lugar DO (UPDATE restriccion_de_lugar SET por_actividad = false WHERE ((restriccion_de_lugar.id)::text = (old.restriccion_nominal)::text); UPDATE restriccion_de_lugar SET por_actividad = true WHERE ((restriccion_de_lugar.id)::text = (new.restriccion_nominal)::text); );


--
-- Name: actualiza_por_actividad_en_restriccion_de_otro_recurso; Type: RULE; Schema: public; Owner: rafa
--

CREATE RULE actualiza_por_actividad_en_restriccion_de_otro_recurso AS ON UPDATE TO restriccion_por_actividad_de_otro_recurso DO (UPDATE restriccion_de_otro_recurso SET por_actividad = false WHERE ((restriccion_de_otro_recurso.id)::text = (old.restriccion_nominal)::text); UPDATE restriccion_de_otro_recurso SET por_actividad = true WHERE ((restriccion_de_otro_recurso.id)::text = (new.restriccion_nominal)::text); );


--
-- Name: actualiza_por_actividad_en_restriccion_de_profesor; Type: RULE; Schema: public; Owner: rafa
--

CREATE RULE actualiza_por_actividad_en_restriccion_de_profesor AS ON UPDATE TO restriccion_por_actividad_de_profesor DO (UPDATE restriccion_de_profesor SET por_actividad = false WHERE ((restriccion_de_profesor.id)::text = (old.restriccion_nominal)::text); UPDATE restriccion_de_profesor SET por_actividad = true WHERE ((restriccion_de_profesor.id)::text = (new.restriccion_nominal)::text); );


--
-- Name: actualiza_restriccion_real_de_asignatura; Type: RULE; Schema: public; Owner: rafa
--

CREATE RULE actualiza_restriccion_real_de_asignatura AS ON UPDATE TO restriccion_de_asignatura DO SELECT actualiza_restriccion_real(new.asignatura, NULL::character varying, new.id, new.periodo, new.dia, new.turno, false, 'restriccion_real_de_asignatura'::character varying) AS actualiza_restriccion_real;


--
-- Name: actualiza_restriccion_real_de_brigada; Type: RULE; Schema: public; Owner: rafa
--

CREATE RULE actualiza_restriccion_real_de_brigada AS ON UPDATE TO restriccion_de_brigada DO SELECT actualiza_restriccion_real(new.brigada, new.actividad, new.id, new.periodo, new.dia, new.turno, new.por_actividad, 'restriccion_real_de_brigada'::character varying) AS actualiza_restriccion_real;


--
-- Name: actualiza_restriccion_real_de_clasif_act; Type: RULE; Schema: public; Owner: rafa
--

CREATE RULE actualiza_restriccion_real_de_clasif_act AS ON UPDATE TO restriccion_de_clasif_act DO SELECT actualiza_restriccion_real(new.clasificacion, NULL::character varying, new.id, new.periodo, new.dia, new.turno, false, 'restriccion_real_de_clasif_act'::character varying) AS actualiza_restriccion_real;


--
-- Name: actualiza_restriccion_real_de_especialidad; Type: RULE; Schema: public; Owner: rafa
--

CREATE RULE actualiza_restriccion_real_de_especialidad AS ON UPDATE TO restriccion_de_especialidad DO SELECT actualiza_restriccion_real(new.especialidad, NULL::character varying, new.id, new.periodo, new.dia, new.turno, false, 'restriccion_real_de_especialidad'::character varying) AS actualiza_restriccion_real;


--
-- Name: actualiza_restriccion_real_de_lugar; Type: RULE; Schema: public; Owner: rafa
--

CREATE RULE actualiza_restriccion_real_de_lugar AS ON UPDATE TO restriccion_de_lugar DO SELECT actualiza_restriccion_real(new.lugar, new.actividad, new.id, new.periodo, new.dia, new.turno, new.por_actividad, 'restriccion_real_de_lugar'::character varying) AS actualiza_restriccion_real;


--
-- Name: actualiza_restriccion_real_de_otro_recurso; Type: RULE; Schema: public; Owner: rafa
--

CREATE RULE actualiza_restriccion_real_de_otro_recurso AS ON UPDATE TO restriccion_de_otro_recurso DO SELECT actualiza_restriccion_real(new.otro_recurso, new.actividad, new.id, new.periodo, new.dia, new.turno, new.por_actividad, 'restriccion_real_de_otro_recurso'::character varying) AS actualiza_restriccion_real;


--
-- Name: actualiza_restriccion_real_de_periodo; Type: RULE; Schema: public; Owner: rafa
--

CREATE RULE actualiza_restriccion_real_de_periodo AS ON UPDATE TO restriccion_de_periodo DO SELECT actualiza_restriccion_real(new.periodo, NULL::character varying, new.id, new.periodo, new.dia, new.turno, false, 'restriccion_real_de_periodo'::character varying) AS actualiza_restriccion_real;


--
-- Name: actualiza_restriccion_real_de_profesor; Type: RULE; Schema: public; Owner: rafa
--

CREATE RULE actualiza_restriccion_real_de_profesor AS ON UPDATE TO restriccion_de_profesor DO SELECT actualiza_restriccion_real(new.profesor, new.actividad, new.id, new.periodo, new.dia, new.turno, new.por_actividad, 'restriccion_real_de_profesor'::character varying) AS actualiza_restriccion_real;


--
-- Name: actualiza_restricciones_por_actividad; Type: RULE; Schema: public; Owner: rafa
--

CREATE RULE actualiza_restricciones_por_actividad AS ON INSERT TO actividad DO SELECT restringe_segun_actividad(new.id, new.plantilla, new.profesor, new.lugar, new.dia, new.turno, new.grupo) AS restringe_segun_actividad;


--
-- Name: actualiza_restricciones_por_uso_de_otro_recurso; Type: RULE; Schema: public; Owner: rafa
--

CREATE RULE actualiza_restricciones_por_uso_de_otro_recurso AS ON INSERT TO otros_recursos_usados DO SELECT restringe_por_uso_de_otro_recurso(new.actividad, new.otro_recurso) AS restringe_por_uso_de_otro_recurso;


--
-- Name: crea_restriccion_real_de_asignatura; Type: RULE; Schema: public; Owner: rafa
--

CREATE RULE crea_restriccion_real_de_asignatura AS ON INSERT TO restriccion_de_asignatura DO SELECT actualiza_restriccion_real(new.asignatura, NULL::character varying, new.id, new.periodo, new.dia, new.turno, false, 'restriccion_real_de_asignatura'::character varying) AS actualiza_restriccion_real;


--
-- Name: crea_restriccion_real_de_brigada; Type: RULE; Schema: public; Owner: rafa
--

CREATE RULE crea_restriccion_real_de_brigada AS ON INSERT TO restriccion_de_brigada DO SELECT actualiza_restriccion_real(new.brigada, new.actividad, new.id, new.periodo, new.dia, new.turno, new.por_actividad, 'restriccion_real_de_brigada'::character varying) AS actualiza_restriccion_real;


--
-- Name: crea_restriccion_real_de_clasif_act; Type: RULE; Schema: public; Owner: rafa
--

CREATE RULE crea_restriccion_real_de_clasif_act AS ON INSERT TO restriccion_de_clasif_act DO SELECT actualiza_restriccion_real(new.clasificacion, NULL::character varying, new.id, new.periodo, new.dia, new.turno, false, 'restriccion_real_de_clasif_act'::character varying) AS actualiza_restriccion_real;


--
-- Name: crea_restriccion_real_de_especialidad; Type: RULE; Schema: public; Owner: rafa
--

CREATE RULE crea_restriccion_real_de_especialidad AS ON INSERT TO restriccion_de_especialidad DO SELECT actualiza_restriccion_real(new.especialidad, NULL::character varying, new.id, new.periodo, new.dia, new.turno, false, 'restriccion_real_de_especialidad'::character varying) AS actualiza_restriccion_real;


--
-- Name: crea_restriccion_real_de_lugar; Type: RULE; Schema: public; Owner: rafa
--

CREATE RULE crea_restriccion_real_de_lugar AS ON INSERT TO restriccion_de_lugar DO SELECT actualiza_restriccion_real(new.lugar, new.actividad, new.id, new.periodo, new.dia, new.turno, new.por_actividad, 'restriccion_real_de_lugar'::character varying) AS actualiza_restriccion_real;


--
-- Name: crea_restriccion_real_de_otro_recurso; Type: RULE; Schema: public; Owner: rafa
--

CREATE RULE crea_restriccion_real_de_otro_recurso AS ON INSERT TO restriccion_de_otro_recurso DO SELECT actualiza_restriccion_real(new.otro_recurso, new.actividad, new.id, new.periodo, new.dia, new.turno, new.por_actividad, 'restriccion_real_de_otro_recurso'::character varying) AS actualiza_restriccion_real;


--
-- Name: crea_restriccion_real_de_periodo; Type: RULE; Schema: public; Owner: rafa
--

CREATE RULE crea_restriccion_real_de_periodo AS ON INSERT TO restriccion_de_periodo DO SELECT actualiza_restriccion_real(new.periodo, NULL::character varying, new.id, new.periodo, new.dia, new.turno, false, 'restriccion_real_de_periodo'::character varying) AS actualiza_restriccion_real;


--
-- Name: crea_restriccion_real_de_profesor; Type: RULE; Schema: public; Owner: rafa
--

CREATE RULE crea_restriccion_real_de_profesor AS ON INSERT TO restriccion_de_profesor DO SELECT actualiza_restriccion_real(new.profesor, new.actividad, new.id, new.periodo, new.dia, new.turno, new.por_actividad, 'restriccion_real_de_profesor'::character varying) AS actualiza_restriccion_real;


--
-- Name: nuevo_desglose_si_nueva_asignatura; Type: TRIGGER; Schema: public; Owner: rafa
--

CREATE TRIGGER nuevo_desglose_si_nueva_asignatura
    AFTER INSERT ON asignatura
    FOR EACH ROW
    EXECUTE PROCEDURE nuevo_desglose_cuando_nueva_asignatura();


--
-- Name: nuevo_desglose_si_nuevo_periodo; Type: TRIGGER; Schema: public; Owner: rafa
--

CREATE TRIGGER nuevo_desglose_si_nuevo_periodo
    AFTER INSERT ON periodo
    FOR EACH ROW
    EXECUTE PROCEDURE nuevo_desglose_cuando_nuevo_periodo();


--
-- Name: trigger_actualiza_orden_act_after_delete; Type: TRIGGER; Schema: public; Owner: rafa
--

CREATE TRIGGER trigger_actualiza_orden_act_after_delete
    AFTER DELETE ON plantilla_de_actividad
    FOR EACH ROW
    EXECUTE PROCEDURE actualiza_orden_act_after_delete();


--
-- Name: trigger_actualiza_orden_act_after_insert; Type: TRIGGER; Schema: public; Owner: rafa
--

CREATE TRIGGER trigger_actualiza_orden_act_after_insert
    AFTER INSERT ON plantilla_de_actividad
    FOR EACH ROW
    EXECUTE PROCEDURE actualiza_orden_act_after_insert();


--
-- Name: trigger_actualiza_orden_act_after_update; Type: TRIGGER; Schema: public; Owner: rafa
--

CREATE TRIGGER trigger_actualiza_orden_act_after_update
    AFTER UPDATE ON plantilla_de_actividad
    FOR EACH ROW
    EXECUTE PROCEDURE actualiza_orden_act_after_update();


--
-- Name: trigger_actualiza_orden_act_before_insert; Type: TRIGGER; Schema: public; Owner: rafa
--

CREATE TRIGGER trigger_actualiza_orden_act_before_insert
    BEFORE INSERT ON plantilla_de_actividad
    FOR EACH ROW
    EXECUTE PROCEDURE actualiza_orden_act_before_insert();


--
-- Name: trigger_actualiza_orden_act_before_update; Type: TRIGGER; Schema: public; Owner: rafa
--

CREATE TRIGGER trigger_actualiza_orden_act_before_update
    BEFORE UPDATE ON plantilla_de_actividad
    FOR EACH ROW
    EXECUTE PROCEDURE actualiza_orden_act_before_update();


--
-- Name: trigger_actualiza_profesor_para_grupo; Type: TRIGGER; Schema: public; Owner: rafa
--

CREATE TRIGGER trigger_actualiza_profesor_para_grupo
    BEFORE UPDATE ON profesor_para_grupo
    FOR EACH ROW
    EXECUTE PROCEDURE actualiza_profesor_para_grupo();


--
-- Name: trigger_arregla_prioridades_clasif_after_delete; Type: TRIGGER; Schema: public; Owner: rafa
--

CREATE TRIGGER trigger_arregla_prioridades_clasif_after_delete
    AFTER DELETE ON clasificacion_de_actividad
    FOR EACH ROW
    EXECUTE PROCEDURE arregla_prioridades_clasif_after_delete();


--
-- Name: trigger_nivela_prioridad_lxact_after_delete; Type: TRIGGER; Schema: public; Owner: rafa
--

CREATE TRIGGER trigger_nivela_prioridad_lxact_after_delete
    AFTER DELETE ON lugar_para_actividad
    FOR EACH ROW
    EXECUTE PROCEDURE nivela_prioridad_lxact_after_delete();


--
-- Name: trigger_nivela_prioridad_lxact_after_update; Type: TRIGGER; Schema: public; Owner: rafa
--

CREATE TRIGGER trigger_nivela_prioridad_lxact_after_update
    AFTER UPDATE ON lugar_para_actividad
    FOR EACH ROW
    EXECUTE PROCEDURE nivela_prioridad_lxact_after_update();


--
-- Name: trigger_nivela_prioridad_rxact_after_delete; Type: TRIGGER; Schema: public; Owner: rafa
--

CREATE TRIGGER trigger_nivela_prioridad_rxact_after_delete
    AFTER DELETE ON otro_grupo_de_recursos_para_actividad
    FOR EACH ROW
    EXECUTE PROCEDURE nivela_prioridad_rxact_after_delete();


--
-- Name: acceso_prohibido_grupo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY acceso_prohibido
    ADD CONSTRAINT acceso_prohibido_grupo_fkey FOREIGN KEY (grupo) REFERENCES grupo(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: acceso_prohibido_lugar_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY acceso_prohibido
    ADD CONSTRAINT acceso_prohibido_lugar_fkey FOREIGN KEY (lugar) REFERENCES lugar(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: actividad_creador_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY actividad
    ADD CONSTRAINT actividad_creador_fkey FOREIGN KEY (creador) REFERENCES seguridad.usuario(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: actividad_grupo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY actividad
    ADD CONSTRAINT actividad_grupo_fkey FOREIGN KEY (grupo) REFERENCES grupo(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: actividad_lugar_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY actividad
    ADD CONSTRAINT actividad_lugar_fkey FOREIGN KEY (lugar) REFERENCES lugar(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: actividad_plantilla_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY actividad
    ADD CONSTRAINT actividad_plantilla_fkey FOREIGN KEY (plantilla) REFERENCES plantilla_de_actividad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: actividad_profesor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY actividad
    ADD CONSTRAINT actividad_profesor_fkey FOREIGN KEY (profesor) REFERENCES profesor(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: asignatura_creador_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY asignatura
    ADD CONSTRAINT asignatura_creador_fkey FOREIGN KEY (creador) REFERENCES seguridad.usuario(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: asignatura_especialidad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY asignatura
    ADD CONSTRAINT asignatura_especialidad_fkey FOREIGN KEY (especialidad) REFERENCES especialidad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: asignatura_nivel_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY asignatura
    ADD CONSTRAINT asignatura_nivel_fkey FOREIGN KEY (nivel) REFERENCES nivel(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: brigada_creador_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY brigada
    ADD CONSTRAINT brigada_creador_fkey FOREIGN KEY (creador) REFERENCES seguridad.usuario(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: brigada_de_grupo_brigada_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY brigada_de_grupo
    ADD CONSTRAINT brigada_de_grupo_brigada_fkey FOREIGN KEY (brigada) REFERENCES brigada(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: brigada_de_grupo_grupo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY brigada_de_grupo
    ADD CONSTRAINT brigada_de_grupo_grupo_fkey FOREIGN KEY (grupo) REFERENCES grupo(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: brigada_especialidad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY brigada
    ADD CONSTRAINT brigada_especialidad_fkey FOREIGN KEY (especialidad) REFERENCES especialidad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: brigada_nivel_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY brigada
    ADD CONSTRAINT brigada_nivel_fkey FOREIGN KEY (nivel) REFERENCES nivel(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: clasificacion_de_actividad_creador_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY clasificacion_de_actividad
    ADD CONSTRAINT clasificacion_de_actividad_creador_fkey FOREIGN KEY (creador) REFERENCES seguridad.usuario(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: costo_de_traslado_destino_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY costo_de_traslado
    ADD CONSTRAINT costo_de_traslado_destino_fkey FOREIGN KEY (destino) REFERENCES lugar(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: costo_de_traslado_origen_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY costo_de_traslado
    ADD CONSTRAINT costo_de_traslado_origen_fkey FOREIGN KEY (origen) REFERENCES lugar(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: desglose_asignatura_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY desglose
    ADD CONSTRAINT desglose_asignatura_fkey FOREIGN KEY (asignatura) REFERENCES asignatura(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: desglose_periodo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY desglose
    ADD CONSTRAINT desglose_periodo_fkey FOREIGN KEY (periodo) REFERENCES periodo(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: especialidad_creador_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY especialidad
    ADD CONSTRAINT especialidad_creador_fkey FOREIGN KEY (creador) REFERENCES seguridad.usuario(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: excepcion_de_hrt_herencia_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY excepcion_de_hrt
    ADD CONSTRAINT excepcion_de_hrt_herencia_fkey FOREIGN KEY (herencia) REFERENCES herencia_de_restricciones(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: excepcion_de_hrt_periodo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY excepcion_de_hrt
    ADD CONSTRAINT excepcion_de_hrt_periodo_fkey FOREIGN KEY (periodo) REFERENCES periodo(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: grupo_clasificacion_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY grupo
    ADD CONSTRAINT grupo_clasificacion_fkey FOREIGN KEY (clasificacion) REFERENCES clasificacion_de_actividad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: grupo_especialidad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY grupo
    ADD CONSTRAINT grupo_especialidad_fkey FOREIGN KEY (especialidad) REFERENCES especialidad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: grupo_nivel_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY grupo
    ADD CONSTRAINT grupo_nivel_fkey FOREIGN KEY (nivel) REFERENCES nivel(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: grupo_planificacion_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY grupo
    ADD CONSTRAINT grupo_planificacion_fkey FOREIGN KEY (planificacion) REFERENCES planificacion(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: herencia_de_restricciones_hijo_brigada_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY herencia_de_restricciones
    ADD CONSTRAINT herencia_de_restricciones_hijo_brigada_fkey FOREIGN KEY (hijo_brigada) REFERENCES brigada(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: herencia_de_restricciones_hijo_lugar_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY herencia_de_restricciones
    ADD CONSTRAINT herencia_de_restricciones_hijo_lugar_fkey FOREIGN KEY (hijo_lugar) REFERENCES lugar(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: herencia_de_restricciones_hijo_otro_recurso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY herencia_de_restricciones
    ADD CONSTRAINT herencia_de_restricciones_hijo_otro_recurso_fkey FOREIGN KEY (hijo_otro_recurso) REFERENCES otro_recurso(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: herencia_de_restricciones_hijo_profesor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY herencia_de_restricciones
    ADD CONSTRAINT herencia_de_restricciones_hijo_profesor_fkey FOREIGN KEY (hijo_profesor) REFERENCES profesor(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: herencia_de_restricciones_padre_brigada_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY herencia_de_restricciones
    ADD CONSTRAINT herencia_de_restricciones_padre_brigada_fkey FOREIGN KEY (padre_brigada) REFERENCES brigada(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: herencia_de_restricciones_padre_lugar_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY herencia_de_restricciones
    ADD CONSTRAINT herencia_de_restricciones_padre_lugar_fkey FOREIGN KEY (padre_lugar) REFERENCES lugar(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: herencia_de_restricciones_padre_otro_recurso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY herencia_de_restricciones
    ADD CONSTRAINT herencia_de_restricciones_padre_otro_recurso_fkey FOREIGN KEY (padre_otro_recurso) REFERENCES otro_recurso(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: herencia_de_restricciones_padre_profesor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY herencia_de_restricciones
    ADD CONSTRAINT herencia_de_restricciones_padre_profesor_fkey FOREIGN KEY (padre_profesor) REFERENCES profesor(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: herencia_de_restricciones_planificacion_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY herencia_de_restricciones
    ADD CONSTRAINT herencia_de_restricciones_planificacion_fkey FOREIGN KEY (planificacion) REFERENCES planificacion(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: higiene_para_brigada_brigada_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY higiene_para_brigada
    ADD CONSTRAINT higiene_para_brigada_brigada_fkey FOREIGN KEY (brigada) REFERENCES brigada(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: higiene_para_brigada_periodo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY higiene_para_brigada
    ADD CONSTRAINT higiene_para_brigada_periodo_fkey FOREIGN KEY (periodo) REFERENCES periodo(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: higiene_para_profesor_periodo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY higiene_para_profesor
    ADD CONSTRAINT higiene_para_profesor_periodo_fkey FOREIGN KEY (periodo) REFERENCES periodo(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: higiene_para_profesor_profesor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY higiene_para_profesor
    ADD CONSTRAINT higiene_para_profesor_profesor_fkey FOREIGN KEY (profesor) REFERENCES profesor(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lugar_creador_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY lugar
    ADD CONSTRAINT lugar_creador_fkey FOREIGN KEY (creador) REFERENCES seguridad.usuario(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lugar_fijo_grupo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY lugar_fijo
    ADD CONSTRAINT lugar_fijo_grupo_fkey FOREIGN KEY (grupo) REFERENCES grupo(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lugar_fijo_lugar_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY lugar_fijo
    ADD CONSTRAINT lugar_fijo_lugar_fkey FOREIGN KEY (lugar) REFERENCES lugar(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lugar_para_actividad_lugar_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY lugar_para_actividad
    ADD CONSTRAINT lugar_para_actividad_lugar_fkey FOREIGN KEY (lugar) REFERENCES lugar(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lugar_para_actividad_plantilla_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY lugar_para_actividad
    ADD CONSTRAINT lugar_para_actividad_plantilla_fkey FOREIGN KEY (plantilla) REFERENCES plantilla_de_actividad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: nivel_creador_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY nivel
    ADD CONSTRAINT nivel_creador_fkey FOREIGN KEY (creador) REFERENCES seguridad.usuario(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: otro_grupo_de_recursos_para_actividad_creador_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY otro_grupo_de_recursos_para_actividad
    ADD CONSTRAINT otro_grupo_de_recursos_para_actividad_creador_fkey FOREIGN KEY (creador) REFERENCES seguridad.usuario(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: otro_grupo_de_recursos_para_actividad_plantilla_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY otro_grupo_de_recursos_para_actividad
    ADD CONSTRAINT otro_grupo_de_recursos_para_actividad_plantilla_fkey FOREIGN KEY (plantilla) REFERENCES plantilla_de_actividad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: otro_recurso_creador_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY otro_recurso
    ADD CONSTRAINT otro_recurso_creador_fkey FOREIGN KEY (creador) REFERENCES seguridad.usuario(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: otro_recurso_para_actividad_grupo_de_recursos_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY otro_recurso_para_actividad
    ADD CONSTRAINT otro_recurso_para_actividad_grupo_de_recursos_fkey FOREIGN KEY (grupo_de_recursos) REFERENCES otro_grupo_de_recursos_para_actividad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: otro_recurso_para_actividad_otro_recurso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY otro_recurso_para_actividad
    ADD CONSTRAINT otro_recurso_para_actividad_otro_recurso_fkey FOREIGN KEY (otro_recurso) REFERENCES otro_recurso(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: otros_recursos_usados_actividad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY otros_recursos_usados
    ADD CONSTRAINT otros_recursos_usados_actividad_fkey FOREIGN KEY (actividad) REFERENCES actividad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: otros_recursos_usados_creador_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY otros_recursos_usados
    ADD CONSTRAINT otros_recursos_usados_creador_fkey FOREIGN KEY (creador) REFERENCES seguridad.usuario(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: otros_recursos_usados_otro_recurso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY otros_recursos_usados
    ADD CONSTRAINT otros_recursos_usados_otro_recurso_fkey FOREIGN KEY (otro_recurso) REFERENCES otro_recurso(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: periodicidad_periodo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY periodicidad
    ADD CONSTRAINT periodicidad_periodo_fkey FOREIGN KEY (periodo) REFERENCES periodo(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: periodo_planificacion_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY periodo
    ADD CONSTRAINT periodo_planificacion_fkey FOREIGN KEY (planificacion) REFERENCES planificacion(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: planificacion_creador_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY planificacion
    ADD CONSTRAINT planificacion_creador_fkey FOREIGN KEY (creador) REFERENCES seguridad.usuario(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: plantilla_de_actividad_clasificacion_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY plantilla_de_actividad
    ADD CONSTRAINT plantilla_de_actividad_clasificacion_fkey FOREIGN KEY (clasificacion) REFERENCES clasificacion_de_actividad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: plantilla_de_actividad_desglose_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY plantilla_de_actividad
    ADD CONSTRAINT plantilla_de_actividad_desglose_fkey FOREIGN KEY (desglose) REFERENCES desglose(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: profesor_creador_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY profesor
    ADD CONSTRAINT profesor_creador_fkey FOREIGN KEY (creador) REFERENCES seguridad.usuario(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: profesor_para_actividad_plantilla_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY profesor_para_actividad
    ADD CONSTRAINT profesor_para_actividad_plantilla_fkey FOREIGN KEY (plantilla) REFERENCES plantilla_de_actividad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: profesor_para_actividad_profesor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY profesor_para_actividad
    ADD CONSTRAINT profesor_para_actividad_profesor_fkey FOREIGN KEY (profesor) REFERENCES profesor(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: profesor_para_grupo_grupo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY profesor_para_grupo
    ADD CONSTRAINT profesor_para_grupo_grupo_fkey FOREIGN KEY (grupo) REFERENCES grupo(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: profesor_para_grupo_profesor_para_actividad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY profesor_para_grupo
    ADD CONSTRAINT profesor_para_grupo_profesor_para_actividad_fkey FOREIGN KEY (profesor_para_actividad) REFERENCES profesor_para_actividad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: receso_periodo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY receso
    ADD CONSTRAINT receso_periodo_fkey FOREIGN KEY (periodo) REFERENCES periodo(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_condicional_asig_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_condicional
    ADD CONSTRAINT restriccion_condicional_asig_fkey FOREIGN KEY (asig) REFERENCES asignatura(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_condicional_brigada_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_condicional
    ADD CONSTRAINT restriccion_condicional_brigada_fkey FOREIGN KEY (brigada) REFERENCES brigada(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_condicional_clasif_act_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_condicional
    ADD CONSTRAINT restriccion_condicional_clasif_act_fkey FOREIGN KEY (clasif_act) REFERENCES clasificacion_de_actividad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_condicional_consec_brigada_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_condicional
    ADD CONSTRAINT restriccion_condicional_consec_brigada_fkey FOREIGN KEY (consec_brigada) REFERENCES brigada(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_condicional_consec_lugar_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_condicional
    ADD CONSTRAINT restriccion_condicional_consec_lugar_fkey FOREIGN KEY (consec_lugar) REFERENCES lugar(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_condicional_consec_otro_recurso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_condicional
    ADD CONSTRAINT restriccion_condicional_consec_otro_recurso_fkey FOREIGN KEY (consec_otro_recurso) REFERENCES otro_recurso(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_condicional_consec_periodo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_condicional
    ADD CONSTRAINT restriccion_condicional_consec_periodo_fkey FOREIGN KEY (consec_periodo) REFERENCES periodo(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_condicional_consec_profesor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_condicional
    ADD CONSTRAINT restriccion_condicional_consec_profesor_fkey FOREIGN KEY (consec_profesor) REFERENCES profesor(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_condicional_especialidad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_condicional
    ADD CONSTRAINT restriccion_condicional_especialidad_fkey FOREIGN KEY (especialidad) REFERENCES especialidad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_condicional_lugar_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_condicional
    ADD CONSTRAINT restriccion_condicional_lugar_fkey FOREIGN KEY (lugar) REFERENCES lugar(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_condicional_nivel_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_condicional
    ADD CONSTRAINT restriccion_condicional_nivel_fkey FOREIGN KEY (nivel) REFERENCES nivel(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_condicional_otro_recurso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_condicional
    ADD CONSTRAINT restriccion_condicional_otro_recurso_fkey FOREIGN KEY (otro_recurso) REFERENCES otro_recurso(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_condicional_periodo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_condicional
    ADD CONSTRAINT restriccion_condicional_periodo_fkey FOREIGN KEY (periodo) REFERENCES periodo(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_condicional_planificacion_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_condicional
    ADD CONSTRAINT restriccion_condicional_planificacion_fkey FOREIGN KEY (planificacion) REFERENCES planificacion(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_condicional_profesor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_condicional
    ADD CONSTRAINT restriccion_condicional_profesor_fkey FOREIGN KEY (profesor) REFERENCES profesor(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_de_asignatura_asignatura_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_de_asignatura
    ADD CONSTRAINT restriccion_de_asignatura_asignatura_fkey FOREIGN KEY (asignatura) REFERENCES asignatura(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_de_asignatura_periodo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_de_asignatura
    ADD CONSTRAINT restriccion_de_asignatura_periodo_fkey FOREIGN KEY (periodo) REFERENCES periodo(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_de_brigada_actividad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_de_brigada
    ADD CONSTRAINT restriccion_de_brigada_actividad_fkey FOREIGN KEY (actividad) REFERENCES actividad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_de_brigada_brigada_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_de_brigada
    ADD CONSTRAINT restriccion_de_brigada_brigada_fkey FOREIGN KEY (brigada) REFERENCES brigada(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_de_brigada_periodo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_de_brigada
    ADD CONSTRAINT restriccion_de_brigada_periodo_fkey FOREIGN KEY (periodo) REFERENCES periodo(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_de_clasif_act_clasificacion_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_de_clasif_act
    ADD CONSTRAINT restriccion_de_clasif_act_clasificacion_fkey FOREIGN KEY (clasificacion) REFERENCES clasificacion_de_actividad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_de_clasif_act_periodo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_de_clasif_act
    ADD CONSTRAINT restriccion_de_clasif_act_periodo_fkey FOREIGN KEY (periodo) REFERENCES periodo(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_de_especialidad_especialidad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_de_especialidad
    ADD CONSTRAINT restriccion_de_especialidad_especialidad_fkey FOREIGN KEY (especialidad) REFERENCES especialidad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_de_especialidad_periodo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_de_especialidad
    ADD CONSTRAINT restriccion_de_especialidad_periodo_fkey FOREIGN KEY (periodo) REFERENCES periodo(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_de_lugar_actividad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_de_lugar
    ADD CONSTRAINT restriccion_de_lugar_actividad_fkey FOREIGN KEY (actividad) REFERENCES actividad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_de_lugar_lugar_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_de_lugar
    ADD CONSTRAINT restriccion_de_lugar_lugar_fkey FOREIGN KEY (lugar) REFERENCES lugar(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_de_lugar_periodo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_de_lugar
    ADD CONSTRAINT restriccion_de_lugar_periodo_fkey FOREIGN KEY (periodo) REFERENCES periodo(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_de_otro_recurso_actividad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_de_otro_recurso
    ADD CONSTRAINT restriccion_de_otro_recurso_actividad_fkey FOREIGN KEY (actividad) REFERENCES actividad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_de_otro_recurso_otro_recurso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_de_otro_recurso
    ADD CONSTRAINT restriccion_de_otro_recurso_otro_recurso_fkey FOREIGN KEY (otro_recurso) REFERENCES otro_recurso(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_de_otro_recurso_periodo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_de_otro_recurso
    ADD CONSTRAINT restriccion_de_otro_recurso_periodo_fkey FOREIGN KEY (periodo) REFERENCES periodo(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_de_periodo_periodo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_de_periodo
    ADD CONSTRAINT restriccion_de_periodo_periodo_fkey FOREIGN KEY (periodo) REFERENCES periodo(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_de_profesor_actividad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_de_profesor
    ADD CONSTRAINT restriccion_de_profesor_actividad_fkey FOREIGN KEY (actividad) REFERENCES actividad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_de_profesor_periodo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_de_profesor
    ADD CONSTRAINT restriccion_de_profesor_periodo_fkey FOREIGN KEY (periodo) REFERENCES periodo(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_de_profesor_profesor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_de_profesor
    ADD CONSTRAINT restriccion_de_profesor_profesor_fkey FOREIGN KEY (profesor) REFERENCES profesor(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_por_actividad_de_brigada_actividad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_por_actividad_de_brigada
    ADD CONSTRAINT restriccion_por_actividad_de_brigada_actividad_fkey FOREIGN KEY (actividad) REFERENCES actividad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_por_actividad_de_brigada_restriccion_nominal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_por_actividad_de_brigada
    ADD CONSTRAINT restriccion_por_actividad_de_brigada_restriccion_nominal_fkey FOREIGN KEY (restriccion_nominal) REFERENCES restriccion_de_brigada(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_por_actividad_de_lugar_actividad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_por_actividad_de_lugar
    ADD CONSTRAINT restriccion_por_actividad_de_lugar_actividad_fkey FOREIGN KEY (actividad) REFERENCES actividad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_por_actividad_de_lugar_restriccion_nominal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_por_actividad_de_lugar
    ADD CONSTRAINT restriccion_por_actividad_de_lugar_restriccion_nominal_fkey FOREIGN KEY (restriccion_nominal) REFERENCES restriccion_de_lugar(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_por_actividad_de_otro_recu_restriccion_nominal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_por_actividad_de_otro_recurso
    ADD CONSTRAINT restriccion_por_actividad_de_otro_recu_restriccion_nominal_fkey FOREIGN KEY (restriccion_nominal) REFERENCES restriccion_de_otro_recurso(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_por_actividad_de_otro_recurso_actividad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_por_actividad_de_otro_recurso
    ADD CONSTRAINT restriccion_por_actividad_de_otro_recurso_actividad_fkey FOREIGN KEY (actividad) REFERENCES actividad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_por_actividad_de_profesor_actividad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_por_actividad_de_profesor
    ADD CONSTRAINT restriccion_por_actividad_de_profesor_actividad_fkey FOREIGN KEY (actividad) REFERENCES actividad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_por_actividad_de_profesor_restriccion_nominal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_por_actividad_de_profesor
    ADD CONSTRAINT restriccion_por_actividad_de_profesor_restriccion_nominal_fkey FOREIGN KEY (restriccion_nominal) REFERENCES restriccion_de_profesor(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_real_de_asignatura_objeto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_real_de_asignatura
    ADD CONSTRAINT restriccion_real_de_asignatura_objeto_fkey FOREIGN KEY (objeto) REFERENCES asignatura(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_real_de_asignatura_periodicidad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_real_de_asignatura
    ADD CONSTRAINT restriccion_real_de_asignatura_periodicidad_fkey FOREIGN KEY (periodicidad) REFERENCES periodicidad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_real_de_asignatura_restriccion_nominal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_real_de_asignatura
    ADD CONSTRAINT restriccion_real_de_asignatura_restriccion_nominal_fkey FOREIGN KEY (restriccion_nominal) REFERENCES restriccion_de_asignatura(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_real_de_brigada_actividad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_real_de_brigada
    ADD CONSTRAINT restriccion_real_de_brigada_actividad_fkey FOREIGN KEY (actividad) REFERENCES actividad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_real_de_brigada_objeto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_real_de_brigada
    ADD CONSTRAINT restriccion_real_de_brigada_objeto_fkey FOREIGN KEY (objeto) REFERENCES brigada(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_real_de_brigada_periodicidad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_real_de_brigada
    ADD CONSTRAINT restriccion_real_de_brigada_periodicidad_fkey FOREIGN KEY (periodicidad) REFERENCES periodicidad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_real_de_brigada_restriccion_nominal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_real_de_brigada
    ADD CONSTRAINT restriccion_real_de_brigada_restriccion_nominal_fkey FOREIGN KEY (restriccion_nominal) REFERENCES restriccion_de_brigada(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_real_de_clasif_act_objeto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_real_de_clasif_act
    ADD CONSTRAINT restriccion_real_de_clasif_act_objeto_fkey FOREIGN KEY (objeto) REFERENCES clasificacion_de_actividad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_real_de_clasif_act_periodicidad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_real_de_clasif_act
    ADD CONSTRAINT restriccion_real_de_clasif_act_periodicidad_fkey FOREIGN KEY (periodicidad) REFERENCES periodicidad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_real_de_clasif_act_restriccion_nominal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_real_de_clasif_act
    ADD CONSTRAINT restriccion_real_de_clasif_act_restriccion_nominal_fkey FOREIGN KEY (restriccion_nominal) REFERENCES restriccion_de_clasif_act(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_real_de_especialidad_objeto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_real_de_especialidad
    ADD CONSTRAINT restriccion_real_de_especialidad_objeto_fkey FOREIGN KEY (objeto) REFERENCES especialidad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_real_de_especialidad_periodicidad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_real_de_especialidad
    ADD CONSTRAINT restriccion_real_de_especialidad_periodicidad_fkey FOREIGN KEY (periodicidad) REFERENCES periodicidad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_real_de_especialidad_restriccion_nominal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_real_de_especialidad
    ADD CONSTRAINT restriccion_real_de_especialidad_restriccion_nominal_fkey FOREIGN KEY (restriccion_nominal) REFERENCES restriccion_de_especialidad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_real_de_lugar_objeto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_real_de_lugar
    ADD CONSTRAINT restriccion_real_de_lugar_objeto_fkey FOREIGN KEY (objeto) REFERENCES lugar(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_real_de_lugar_periodicidad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_real_de_lugar
    ADD CONSTRAINT restriccion_real_de_lugar_periodicidad_fkey FOREIGN KEY (periodicidad) REFERENCES periodicidad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_real_de_lugar_restriccion_nominal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_real_de_lugar
    ADD CONSTRAINT restriccion_real_de_lugar_restriccion_nominal_fkey FOREIGN KEY (restriccion_nominal) REFERENCES restriccion_de_lugar(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_real_de_otro_recurso_objeto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_real_de_otro_recurso
    ADD CONSTRAINT restriccion_real_de_otro_recurso_objeto_fkey FOREIGN KEY (objeto) REFERENCES otro_recurso(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_real_de_otro_recurso_periodicidad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_real_de_otro_recurso
    ADD CONSTRAINT restriccion_real_de_otro_recurso_periodicidad_fkey FOREIGN KEY (periodicidad) REFERENCES periodicidad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_real_de_otro_recurso_restriccion_nominal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_real_de_otro_recurso
    ADD CONSTRAINT restriccion_real_de_otro_recurso_restriccion_nominal_fkey FOREIGN KEY (restriccion_nominal) REFERENCES restriccion_de_otro_recurso(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_real_de_periodo_objeto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_real_de_periodo
    ADD CONSTRAINT restriccion_real_de_periodo_objeto_fkey FOREIGN KEY (objeto) REFERENCES periodo(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_real_de_periodo_periodicidad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_real_de_periodo
    ADD CONSTRAINT restriccion_real_de_periodo_periodicidad_fkey FOREIGN KEY (periodicidad) REFERENCES periodicidad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_real_de_periodo_restriccion_nominal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_real_de_periodo
    ADD CONSTRAINT restriccion_real_de_periodo_restriccion_nominal_fkey FOREIGN KEY (restriccion_nominal) REFERENCES restriccion_de_periodo(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_real_de_profesor_objeto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_real_de_profesor
    ADD CONSTRAINT restriccion_real_de_profesor_objeto_fkey FOREIGN KEY (objeto) REFERENCES profesor(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_real_de_profesor_periodicidad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_real_de_profesor
    ADD CONSTRAINT restriccion_real_de_profesor_periodicidad_fkey FOREIGN KEY (periodicidad) REFERENCES periodicidad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restriccion_real_de_profesor_restriccion_nominal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY restriccion_real_de_profesor
    ADD CONSTRAINT restriccion_real_de_profesor_restriccion_nominal_fkey FOREIGN KEY (restriccion_nominal) REFERENCES restriccion_de_profesor(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: zpriori_clasificacion_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY zpriori
    ADD CONSTRAINT zpriori_clasificacion_fkey FOREIGN KEY (clasificacion) REFERENCES clasificacion_de_actividad(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: zpriori_periodo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rafa
--

ALTER TABLE ONLY zpriori
    ADD CONSTRAINT zpriori_periodo_fkey FOREIGN KEY (periodo) REFERENCES periodo(id) ON UPDATE CASCADE ON DELETE CASCADE;


SET search_path = seguridad, pg_catalog;

--
-- Name: host_usuario_fkey; Type: FK CONSTRAINT; Schema: seguridad; Owner: rafa
--

ALTER TABLE ONLY host
    ADD CONSTRAINT host_usuario_fkey FOREIGN KEY (usuario) REFERENCES usuario(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: permiso_rol_fkey; Type: FK CONSTRAINT; Schema: seguridad; Owner: rafa
--

ALTER TABLE ONLY permiso
    ADD CONSTRAINT permiso_rol_fkey FOREIGN KEY (rol) REFERENCES rol(nombre) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rol_de_usuario_rol_fkey; Type: FK CONSTRAINT; Schema: seguridad; Owner: rafa
--

ALTER TABLE ONLY rol_de_usuario
    ADD CONSTRAINT rol_de_usuario_rol_fkey FOREIGN KEY (rol) REFERENCES rol(nombre) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rol_de_usuario_usuario_fkey; Type: FK CONSTRAINT; Schema: seguridad; Owner: rafa
--

ALTER TABLE ONLY rol_de_usuario
    ADD CONSTRAINT rol_de_usuario_usuario_fkey FOREIGN KEY (usuario) REFERENCES usuario(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: traza_usuario_fkey; Type: FK CONSTRAINT; Schema: seguridad; Owner: rafa
--

ALTER TABLE ONLY traza
    ADD CONSTRAINT traza_usuario_fkey FOREIGN KEY (usuario) REFERENCES usuario(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

